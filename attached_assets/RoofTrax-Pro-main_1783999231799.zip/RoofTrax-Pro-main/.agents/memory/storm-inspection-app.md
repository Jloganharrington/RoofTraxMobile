---
name: Storm Damage Inspection App
description: Expo mobile app — inspection profiles, Phase 1 guided flow, PDF report generation with branding.
---

## Key Decisions

**Package versions** — Expo SDK 54 compatible pins:
- expo-camera: ~17.0.10, expo-file-system: ~19.0.23, expo-print: ~15.0.8, expo-sharing: ~14.0.8
- **Why:** `pnpm add` without pins pulled wrong major versions. Always pin to SDK-expected versions shown in Expo startup warnings.

**PDF generation flow**: `Print.printToFileAsync({ html })` → local URI → `Print.printAsync({ uri })` for in-app viewing (native print preview) → `Sharing.shareAsync(uri)` for export. All guarded with `Platform.OS !== 'web'` checks. Use dynamic `require()` at call site for expo-print/expo-sharing/expo-camera to avoid web bundler crashes.

**State hydration**: `reportUri` state initialised via lazy init `useState(() => getProfileNow(id)?.reportUri ?? null)` so returning to the report screen shows existing report without regenerating.

**Navigation**: Inspection flow uses a nested Stack at `app/inspection/_layout.tsx`. Root `_layout.tsx` needs `<Stack.Screen name="inspection" options={{ headerShown: false }} />`.

**Theme**: Primary navy #1E3A5F, accent orange #F97316, background #F4F5F7. Dark mode supported via `colors.dark`.

**Tablet**: `useWindowDimensions()` + `isTablet = width >= 768` → 2-col FlatList on dashboard, 4-col photo grids on drone/report screens.

**Photo persistence rule** — any camera/picker URI must be copied into the app documents directory *immediately at capture/pick time*, never deferred to a later Save step, and copy destinations must be keyed by a hash of the source URI (basenames collide). Copy failures must surface a visible warning, not fall back silently.
- **Why:** picker/camera output lives in OS cache and is lost on force-close; deferred copying created a data-loss window during long damage-documentation sessions, and a raw picker URI stored for the company logo silently broke report branding.
- **How to apply:** route every new photo entry point through the shared photo-copy utility's detailed variants and warn on failures; never store a raw `ImagePicker`/`CameraView` URI in persisted state.

## Known Gotchas

**Race condition: navigate-after-updateProfile** — `updateProfile` calls `setProfiles` (async batch), then `router.push` fires immediately. The destination screen can mount before the state batch commits, so `getProfile(id)` returns stale data. Fix: add `profilesRef` to InspectionContext, updated synchronously inside the `setProfiles` callback. Expose `getProfileNow(id)` that reads from the ref. Use `getProfileNow` inside any async handler that runs after navigation (e.g. `handleGenerateReport`), not the closure `profile` from render.

**expo-print can't render file:// URIs in its webview** — `expo-file-system.readAsStringAsync` must succeed and return base64 data URIs for images to appear in the PDF. If it fails and falls back to a raw `file://` path, the webview silently drops the image. Fix: use `FileSystem.copyAsync` to copy the photo to `FileSystem.documentDirectory` first (idempotent — check `getInfoAsync` before copying), then read from there. Return `""` (not the raw URI) on failure, and `.filter(Boolean)` the results.
