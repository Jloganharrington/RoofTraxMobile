---
name: Expo web testing quirks
description: Limitations when verifying the Expo app on web instead of a real device
---

- Playwright e2e via `runTest()` repeatedly fails with "self-signed certificate in certificate chain" (infra issue, not app code). **How to apply:** fall back to typecheck (`cd artifacts/mobile && pnpm exec tsc --noEmit`), screenshots of routes, and architect review; explicitly tell the user which flows remain untested.
- `Alert.alert` with buttons is a no-op on react-native-web. **How to apply:** use inline banners/state for user feedback so behavior is consistent on web previews.
- Native-only expo-location APIs (e.g. `reverseGeocodeAsync`) fail on web — always wrap in try/catch with a manual-entry fallback; real verification requires the user's device via Expo Go.
