---
name: API proxy routing
description: How the shared proxy routes the API server and the correct mobile API base URL
---

The API server artifact is proxied at path prefix `/api` (see its `.replit-artifact/artifact.toml` service `paths`), and the Express app also mounts its routes under `/api` internally — the proxy does NOT strip the prefix, so external URLs are `https://$DOMAIN/api/...` with no extra segment.

**Why:** The mobile app's `API_BASE_URL` originally appended `/api-server`, which silently fell through to the Expo web server's SPA catch-all (returning HTML with no CORS headers, surfacing as a misleading CORS error in the browser).

**How to apply:** In the mobile app, `API_BASE_URL` must be just `https://${EXPO_PUBLIC_DOMAIN}` (callers append `/api/...`). When a fetch from expo web shows a CORS error, first check whether the request actually reached the API server (an HTML content-type response means it hit the wrong upstream). For ad hoc testing, the API server also listens directly on localhost:8080.
