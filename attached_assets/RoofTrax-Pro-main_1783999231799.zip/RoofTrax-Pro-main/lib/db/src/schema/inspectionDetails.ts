import { jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// Normalized VisualCrossing severe-weather event (see weather.ts normalize()).
export const weatherEventSchema = z.object({
  type: z.enum(["hail", "wind", "tornado"]),
  date: z.string(),
  size: z.number().nullable(),
  distance: z.number().nullable(),
  magnitude: z.number().nullable(),
  description: z.string().nullable(),
});

// Persisted shape of a weather pull: the normalized result plus the pull timestamp.
export const weatherEventsResultSchema = z.object({
  location: z.string(),
  rangeStart: z.string(),
  rangeEnd: z.string(),
  totalEvents: z.number(),
  counts: z.object({
    hail: z.number(),
    wind: z.number(),
    tornado: z.number(),
  }),
  events: z.array(weatherEventSchema),
  cachedAt: z.string(),
});

// Inspector-confirmed cause-of-loss storm event.
export const selectedStormSchema = z.object({
  date: z.string(),
  hailSize: z.number().nullable(),
  windSpeed: z.number().nullable(),
  distance: z.number().nullable(),
  probability: z.number().nullable(),
  reason: z.string().nullable(),
  description: z.string().nullable().optional(),
});

export type WeatherEventsResult = z.infer<typeof weatherEventsResultSchema>;
export type SelectedStorm = z.infer<typeof selectedStormSchema>;

// One row per inspection. `id` matches the inspection id the mobile client
// already generates locally (see mobile/context/InspectionContext.tsx) — this
// app has no separate server-side "inspections" table/creation flow, so rows
// here are upserted on first PUT rather than created ahead of time.
export const inspectionDetailsTable = pgTable("inspection_details", {
  id: text("id").primaryKey(),
  weatherEvents: jsonb("weather_events").$type<WeatherEventsResult>(),
  selectedStorm: jsonb("selected_storm").$type<SelectedStorm | null>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertInspectionDetailsSchema = createInsertSchema(inspectionDetailsTable);
export type InsertInspectionDetails = z.infer<typeof insertInspectionDetailsSchema>;
export type InspectionDetails = typeof inspectionDetailsTable.$inferSelect;
