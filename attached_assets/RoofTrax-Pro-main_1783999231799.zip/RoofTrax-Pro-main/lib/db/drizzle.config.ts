import { defineConfig } from "drizzle-kit";
import path from "path";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL, ensure the database is provisioned");
}

// drizzle-kit's schema glob resolver breaks on Windows backslash-separated
// paths (path.join's default separator) — normalize to forward slashes so
// `drizzle-kit push` finds the schema on Windows as well as POSIX.
const schemaPath = path.join(__dirname, "./src/schema/index.ts").split(path.sep).join("/");

export default defineConfig({
  schema: schemaPath,
  dialect: "postgresql",
  dbCredentials: {
    url: process.env.DATABASE_URL,
  },
});
