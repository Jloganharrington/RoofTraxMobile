import { Router, type IRouter } from "express";
import Anthropic from "@anthropic-ai/sdk";
import {
  AnalyzeWeatherEventsBody,
  GetWeatherEventsQueryParams,
} from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// ---------------------------------------------------------------------------
// GET /weather/events — VisualCrossing pull, normalization, 12h cache with
// stale-forever fallback (system reference §2).
// ---------------------------------------------------------------------------

const VISUALCROSSING_BASE =
  "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline";
const LOOKBACK_MONTHS = 24;
const FRESH_TTL_MS = 12 * 60 * 60 * 1000;

type WeatherEventType = "hail" | "wind" | "tornado";

interface NormalizedWeatherEvent {
  type: WeatherEventType;
  date: string;
  size: number | null;
  distance: number | null;
  magnitude: number | null;
  description: string | null;
}

interface WeatherEventsResult {
  location: string;
  rangeStart: string;
  rangeEnd: string;
  totalEvents: number;
  counts: { hail: number; wind: number; tornado: number };
  events: NormalizedWeatherEvent[];
  cachedAt: string;
}

interface CacheEntry {
  data: WeatherEventsResult;
  cachedAtMs: number;
}

// In-memory, per-process cache. Fresh for FRESH_TTL_MS; stale entries are kept
// forever and served whenever the provider call fails (quota exhaustion or
// otherwise) — a 24-month Timeline query burns hundreds of VisualCrossing
// "result records" against the daily free-tier budget, so every avoidable
// call matters.
const weatherCache = new Map<string, CacheEntry>();

function toYMD(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function numOrNull(v: unknown): number | null {
  if (v == null) return null;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : null;
}

function classifyType(rawType: unknown): WeatherEventType | "other" {
  const t = String(rawType ?? "").toLowerCase();
  if (t.includes("hail")) return "hail";
  if (t.includes("tornado")) return "tornado";
  if (t.includes("wind")) return "wind";
  return "other";
}

interface RawVisualCrossingResponse {
  resolvedAddress?: string;
  days?: Array<{
    datetime?: string;
    events?: Array<{
      type?: string;
      datetime?: string;
      size?: unknown;
      distance?: unknown;
      magnitude?: unknown;
      speed?: unknown;
      windspeed?: unknown;
      description?: string;
    }>;
  }>;
}

function normalize(
  raw: RawVisualCrossingResponse,
  queryLocation: string,
  rangeStart: string,
  rangeEnd: string,
): Omit<WeatherEventsResult, "cachedAt"> {
  const events: NormalizedWeatherEvent[] = [];

  for (const day of raw.days ?? []) {
    for (const ev of day.events ?? []) {
      const type = classifyType(ev.type);
      if (type === "other") continue;

      const date = (ev.datetime ?? day.datetime ?? "").slice(0, 10);
      events.push({
        type,
        date,
        size: numOrNull(ev.size),
        distance: numOrNull(ev.distance),
        magnitude: numOrNull(ev.magnitude ?? ev.speed ?? ev.windspeed),
        description: ev.description ?? null,
      });
    }
  }

  events.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));

  const counts = { hail: 0, wind: 0, tornado: 0 };
  for (const e of events) counts[e.type]++;

  return {
    location: raw.resolvedAddress ?? queryLocation,
    rangeStart,
    rangeEnd,
    totalEvents: events.length,
    counts,
    events,
  };
}

router.get("/weather/events", async (req, res) => {
  const parsed = GetWeatherEventsQueryParams.safeParse(req.query);
  if (!parsed.success || !parsed.data.city?.trim()) {
    res.status(400).json({ message: "city is required" });
    return;
  }
  const { city, state } = parsed.data;

  const apiKey = process.env.VISUALCROSSING_API_KEY;
  if (!apiKey) {
    res.status(503).json({ message: "Weather data provider is not configured." });
    return;
  }

  const location = state ? `${city}, ${state}` : city;
  const cacheKey = location.toLowerCase();
  const cached = weatherCache.get(cacheKey);

  if (cached && Date.now() - cached.cachedAtMs < FRESH_TTL_MS) {
    logger.info({ cacheKey }, "[weather] cache hit (fresh)");
    res.json(cached.data);
    return;
  }

  const end = new Date();
  const start = new Date(end);
  start.setMonth(start.getMonth() - LOOKBACK_MONTHS);
  const rangeStart = toYMD(start);
  const rangeEnd = toYMD(end);

  const url =
    `${VISUALCROSSING_BASE}/${encodeURIComponent(location)}/${rangeStart}/${rangeEnd}` +
    `?unitGroup=us&include=events&elements=datetime&contentType=json&key=${apiKey}`;

  try {
    logger.info({ cacheKey }, "[weather] calling VisualCrossing (cache miss or stale)");
    const response = await fetch(url, { signal: AbortSignal.timeout(20000) });

    if (!response.ok) {
      const bodyText = await response.text().catch(() => "");
      logger.error(
        { status: response.status, body: bodyText.slice(0, 500) },
        "[weather] VisualCrossing request failed",
      );

      if (cached) {
        logger.info({ cacheKey }, "[weather] serving stale cache after provider failure");
        res.json(cached.data);
        return;
      }
      if (response.status === 429) {
        res.status(429).json({
          message: "Daily weather data limit reached. Please try again later.",
        });
        return;
      }
      res.status(502).json({ message: "Failed to retrieve weather data." });
      return;
    }

    const raw = (await response.json()) as RawVisualCrossingResponse;
    const normalized = normalize(raw, location, rangeStart, rangeEnd);
    const result: WeatherEventsResult = { ...normalized, cachedAt: new Date().toISOString() };

    weatherCache.set(cacheKey, { data: result, cachedAtMs: Date.now() });
    res.json(result);
  } catch (err) {
    logger.error({ err }, "[weather] VisualCrossing request threw");

    if (cached) {
      logger.info({ cacheKey }, "[weather] serving stale cache after provider error");
      res.json(cached.data);
      return;
    }
    res.status(502).json({ message: "Failed to retrieve weather data." });
  }
});

// ---------------------------------------------------------------------------
// POST /weather/analyze — deterministic aggregation + Claude cause-of-loss
// probability estimate (system reference §3).
// ---------------------------------------------------------------------------

interface AggregatedDay {
  date: string;
  hailSize: number | null;
  windSpeed: number | null;
  distance: number | null;
  types: Set<WeatherEventType>;
  description: string | null;
}

function aggregateByDate(events: NormalizedWeatherEvent[]): Map<string, AggregatedDay> {
  const byDate = new Map<string, AggregatedDay>();

  for (const ev of events) {
    let day = byDate.get(ev.date);
    if (!day) {
      day = { date: ev.date, hailSize: null, windSpeed: null, distance: null, types: new Set(), description: null };
      byDate.set(ev.date, day);
    }

    day.types.add(ev.type);

    if (ev.type === "hail" && ev.size != null) {
      day.hailSize = day.hailSize == null ? ev.size : Math.max(day.hailSize, ev.size);
    }
    if ((ev.type === "wind" || ev.type === "tornado") && ev.magnitude != null) {
      day.windSpeed = day.windSpeed == null ? ev.magnitude : Math.max(day.windSpeed, ev.magnitude);
    }
    if (ev.distance != null) {
      day.distance = day.distance == null ? ev.distance : Math.min(day.distance, ev.distance);
    }
    if (ev.description) {
      day.description = day.description ? `${day.description}\n\n${ev.description}` : ev.description;
    }
  }

  // Dedupe distinct descriptions per day (multiple identical reports on the
  // same day shouldn't repeat the same official text).
  for (const day of byDate.values()) {
    if (!day.description) continue;
    const parts = day.description.split("\n\n");
    day.description = Array.from(new Set(parts)).join("\n\n");
  }

  return byDate;
}

// ---------------------------------------------------------------------------
// Hard eligibility gates applied BEFORE events reach the model.
// An event must pass ALL of these to be sent for AI scoring:
//   1. Storm date within the last 2 years
//   2. Hail size > 1.0 inch, OR wind speed > 60 mph, OR tornado
// ---------------------------------------------------------------------------
const TWO_YEARS_MS = 2 * 365.25 * 24 * 60 * 60 * 1000;

function passesHardGates(day: AggregatedDay): boolean {
  // Gate 1 — recency: must be within 2 years of today
  const dayMs = new Date(day.date).getTime();
  if (Date.now() - dayMs > TWO_YEARS_MS) return false;

  // Gate 2+3 — severity: qualifying hail OR qualifying wind OR tornado
  const hasQualifyingHail = day.hailSize != null && day.hailSize > 1.0;
  const hasQualifyingWind = day.windSpeed != null && day.windSpeed > 60;
  const hasTornado = day.types.has("tornado");

  return hasQualifyingHail || hasQualifyingWind || hasTornado;
}

function severityScore(day: AggregatedDay): number {
  const hail = day.hailSize ?? 0;
  const wind = day.windSpeed ?? 0;
  // Unknown distance gets no proximity bonus (conservative: not specified by
  // the spec's formula for the null case).
  const distance = day.distance ?? Infinity;
  return hail * 30 + wind * 0.5 + Math.max(0, 25 - distance);
}

function renderStormTable(days: AggregatedDay[]): string {
  return days
    .map((d, i) => {
      const hail = d.hailSize != null ? d.hailSize.toFixed(2) : "0.00";
      const wind = d.windSpeed != null ? Math.round(d.windSpeed).toString() : "0";
      const dist = d.distance != null ? d.distance.toFixed(1) : "?";
      const types = Array.from(d.types).join("/");
      return `${i + 1}. ${d.date} | Hail: ${hail}" | Wind: ${wind} mph | Distance: ${dist} mi | Types: ${types}.`;
    })
    .join("\n");
}

function buildPrompt(findings: string[], days: AggregatedDay[]): string {
  const findingsList = findings.map((f) => `- ${f}`).join("\n");
  const table = renderStormTable(days);

  return `You are a licensed roofing inspector's AI assistant. The inspector identified the following damage type for this property:

${findingsList}

These severe-weather events have already been pre-filtered to only include events that meet hard minimum thresholds (storm within 2 years AND hail > 1.0" or wind > 60 mph or tornado). They are aggregated by day, sorted most-recent first:

${table}

For each event, estimate an independent probability (0–100) that it is the primary cause of the inspector's damage. Use these benchmarks:
- Hail ≥ 1.5" causes dents on soft metals (gutters, vents, flashing); ≥ 1.0" causes granule loss on shingles.
- Wind ≥ 75 mph typically causes significant shingle lift or structural damage; 60–75 mph can still cause damage on older or weathered roofs.
- Tornadoes are high-probability causes regardless of recorded hail size.
- More recent events are generally more likely causes when damage appears fresh.
- Closer distance increases probability.

Judge whether each event is actually relevant to the specific damage type identified (true/false). Be selective — only mark relevant: true when the event plausibly explains the observed damage. Most events should be relevant: false.

Respond with JSON only — no explanation, no markdown fences. Return an array in the same order as the table:
[{"date": "YYYY-MM-DD", "probability": 0, "relevant": false, "reason": "short reason"}]`;
}

interface ModelJudgement {
  date?: string;
  probability?: number;
  relevant?: boolean;
  reason?: string;
}

function parseModelResponse(text: string): ModelJudgement[] {
  const match = text.match(/\[[\s\S]*\]/);
  if (!match) {
    logger.error({ text: text.slice(0, 500) }, "[weather] analyze: no JSON array found in model output");
    return [];
  }
  try {
    const parsed = JSON.parse(match[0]);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    logger.error({ err, text: text.slice(0, 500) }, "[weather] analyze: failed to parse model JSON");
    return [];
  }
}

router.post("/weather/analyze", async (req, res) => {
  const parsed = AnalyzeWeatherEventsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "findings (non-empty) and events are required" });
    return;
  }
  const { findings, events } = parsed.data;

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    res.status(503).json({ message: "AI storm analysis is not configured." });
    return;
  }

  try {
    // Apply hard gates before scoring — events that fail these thresholds are
    // dropped entirely and never sent to the model.
    const aggregated = Array.from(aggregateByDate(events as NormalizedWeatherEvent[]).values())
      .filter(passesHardGates);
    aggregated.sort((a, b) => severityScore(b) - severityScore(a));
    const topDays = aggregated.slice(0, 15);
    topDays.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));

    const client = new Anthropic({ apiKey });
    const message = await client.messages.create({
      model: "claude-opus-4-8",
      max_tokens: 1024,
      messages: [{ role: "user", content: buildPrompt(findings, topDays) }],
    });

    const textBlock = message.content.find((b) => b.type === "text");
    const judgements = textBlock && "text" in textBlock ? parseModelResponse(textBlock.text) : [];

    const byDate = new Map(judgements.filter((j) => j.date).map((j) => [j.date as string, j]));

    const analyzed = topDays.map((day, i) => {
      // Prefer matching by date; fall back to positional match since the
      // model is instructed to preserve table order.
      const judgement = byDate.get(day.date) ?? judgements[i] ?? {};
      const probability = Math.max(0, Math.min(100, Math.round(judgement.probability ?? 0)));
      const relevant = judgement.relevant === true;

      return {
        date: day.date,
        hailSize: day.hailSize,
        windSpeed: day.windSpeed,
        distance: day.distance,
        types: Array.from(day.types),
        description: day.description,
        probability,
        reason: judgement.reason ?? null,
        relevant,
      };
    });

    analyzed.sort((a, b) => b.probability - a.probability);
    let relevantEvents = analyzed.filter((e) => e.relevant);

    // Fallback: if the model marked nothing relevant, surface the single
    // most-probable event so the inspector always has a candidate.
    if (relevantEvents.length === 0 && analyzed.length > 0) {
      relevantEvents = [analyzed[0]];
    }

    res.json({
      events: relevantEvents,
      topPickDate: relevantEvents[0]?.date ?? null,
    });
  } catch (err) {
    logger.error({ err }, "[weather] AI storm analysis failed");
    res.status(502).json({ message: "AI storm analysis failed." });
  }
});

export default router;
