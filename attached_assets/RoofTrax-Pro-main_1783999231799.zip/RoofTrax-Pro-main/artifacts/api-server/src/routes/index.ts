import { Router, type IRouter } from "express";
import healthRouter from "./health";
import weatherRouter from "./weather";
import inspectionsRouter from "./inspections";
import hailRouter from "./hail";

const router: IRouter = Router();

router.use(healthRouter);
router.use(weatherRouter);
router.use(inspectionsRouter);
router.use(hailRouter);

export default router;
