import { Router, type IRouter } from "express";
import Anthropic from "@anthropic-ai/sdk";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { AddHailReferenceBody, AnalyzeHailIndicatorsBody } from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// ---------------------------------------------------------------------------
// Standalone BETA feature: hail reference library + AI hail-indicator
// analysis. Deliberately NOT connected to inspections, damage instances, or
// report generation. Reference photos are stored on disk under data/ and
// analysis results are never persisted server-side.
// ---------------------------------------------------------------------------

const DATA_DIR = path.join(process.cwd(), "data", "hail-reference");
const INDEX_FILE = path.join(DATA_DIR, "index.json");

type AllowedMime = "image/jpeg" | "image/png" | "image/webp";

interface HailReferenceRecord {
  id: string;
  status: "confirmed" | "denied";
  notes: string;
  mimeType: AllowedMime;
  createdAt: string;
  fileName: string;
}

const EXT_BY_MIME: Record<AllowedMime, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

const MAX_LIBRARY_SIZE = 50;

function looksLikeImage(buffer: Buffer, mimeType: AllowedMime): boolean {
  if (buffer.length < 12) return false;
  switch (mimeType) {
    case "image/jpeg":
      return buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
    case "image/png":
      return buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
    case "image/webp":
      return buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP";
    default:
      return false;
  }
}

function ensureDataDir(): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function readIndex(): HailReferenceRecord[] {
  try {
    const raw = fs.readFileSync(INDEX_FILE, "utf-8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as HailReferenceRecord[]) : [];
  } catch {
    return [];
  }
}

function writeIndex(records: HailReferenceRecord[]): void {
  ensureDataDir();
  const tmp = `${INDEX_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(records, null, 2));
  fs.renameSync(tmp, INDEX_FILE);
}

function toItem(record: HailReferenceRecord) {
  return {
    id: record.id,
    status: record.status,
    notes: record.notes,
    mimeType: record.mimeType,
    createdAt: record.createdAt,
    imageUrl: `/api/hail-reference/image/${record.id}`,
  };
}

// ---------------------------------------------------------------------------
// POST /hail-reference/add
// ---------------------------------------------------------------------------
router.post("/hail-reference/add", (req, res) => {
  const parsed = AddHailReferenceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "imageBase64 and status (confirmed|denied) are required" });
    return;
  }
  const { imageBase64, mimeType, status, notes } = parsed.data;

  let buffer: Buffer;
  try {
    buffer = Buffer.from(imageBase64, "base64");
    if (buffer.length === 0) throw new Error("empty image");
  } catch {
    res.status(400).json({ message: "imageBase64 is not valid base64 image data" });
    return;
  }

  if (!looksLikeImage(buffer, mimeType as AllowedMime)) {
    res.status(400).json({ message: "Uploaded data is not a valid image of the declared type." });
    return;
  }

  const existing = readIndex();
  if (existing.length >= MAX_LIBRARY_SIZE) {
    res.status(409).json({
      message: `Reference library is full (max ${MAX_LIBRARY_SIZE} photos). Remove entries before adding more.`,
    });
    return;
  }

  const id = randomUUID();
  const fileName = `${id}.${EXT_BY_MIME[mimeType as AllowedMime]}`;

  try {
    ensureDataDir();
    fs.writeFileSync(path.join(DATA_DIR, fileName), buffer);
    const record: HailReferenceRecord = {
      id,
      status: status as "confirmed" | "denied",
      notes,
      mimeType: mimeType as AllowedMime,
      createdAt: new Date().toISOString(),
      fileName,
    };
    const records = readIndex();
    records.push(record);
    writeIndex(records);
    res.json(toItem(record));
  } catch (err) {
    logger.error({ err }, "[hail] failed to store reference photo");
    res.status(500).json({ message: "Failed to store reference photo." });
  }
});

// ---------------------------------------------------------------------------
// GET /hail-reference/list — newest first
// ---------------------------------------------------------------------------
router.get("/hail-reference/list", (_req, res) => {
  const records = readIndex();
  records.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  res.json({ items: records.map(toItem) });
});

// ---------------------------------------------------------------------------
// DELETE /hail-reference/:id — remove index entry + image file
// ---------------------------------------------------------------------------
router.delete("/hail-reference/:id", (req, res) => {
  const records = readIndex();
  const record = records.find((r) => r.id === req.params.id);
  if (!record) {
    res.status(404).json({ message: "Unknown reference id" });
    return;
  }
  try {
    writeIndex(records.filter((r) => r.id !== record.id));
    fs.rmSync(path.join(DATA_DIR, record.fileName), { force: true });
    res.json({ id: record.id, deleted: true });
  } catch (err) {
    logger.error({ err }, "[hail] failed to delete reference photo");
    res.status(500).json({ message: "Failed to delete reference photo." });
  }
});

// ---------------------------------------------------------------------------
// GET /hail-reference/image/:id — raw image bytes
// ---------------------------------------------------------------------------
router.get("/hail-reference/image/:id", (req, res) => {
  const record = readIndex().find((r) => r.id === req.params.id);
  if (!record) {
    res.status(404).json({ message: "Unknown reference id" });
    return;
  }
  const filePath = path.join(DATA_DIR, record.fileName);
  if (!fs.existsSync(filePath)) {
    res.status(404).json({ message: "Reference image file missing" });
    return;
  }
  res.setHeader("Content-Type", record.mimeType);
  res.setHeader("Cache-Control", "public, max-age=86400");
  fs.createReadStream(filePath).pipe(res);
});

// ---------------------------------------------------------------------------
// POST /hail-analysis/analyze — Claude vision comparison. Result is returned
// to the caller only; nothing is written to disk or any inspection record.
// ---------------------------------------------------------------------------

const DISCLAIMER =
  "BETA FEATURE — This AI analysis is experimental and for internal reference only. " +
  "It is not a substitute for a licensed inspector's judgment and must not be used " +
  "as evidence in insurance claims or included in customer-facing reports.";

const MAX_REFERENCES = 5;

interface AnalysisJudgement {
  probability?: number;
  reasoning?: string;
  indicators?: unknown;
  confounders?: unknown;
}

function parseAnalysis(text: string): AnalysisJudgement | null {
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) {
    logger.error({ text: text.slice(0, 500) }, "[hail] analyze: no JSON object in model output");
    return null;
  }
  try {
    return JSON.parse(match[0]) as AnalysisJudgement;
  } catch (err) {
    logger.error({ err, text: text.slice(0, 500) }, "[hail] analyze: failed to parse model JSON");
    return null;
  }
}

function toStringArray(v: unknown): string[] {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
}

function buildAnalysisPrompt(references: HailReferenceRecord[]): string {
  const refLines = references
    .map(
      (r, i) =>
        `Reference ${i + 1}: ${r.status.toUpperCase()} hail damage${r.notes ? ` — notes: ${r.notes}` : ""}`,
    )
    .join("\n");

  return `You are an assistant helping a licensed storm-damage inspector evaluate whether a roof/siding damage photo shows indicators consistent with hail impact.

The FIRST image is the damage photo under evaluation.
The remaining images are reference photos from the inspector's own library, each previously adjudicated:
${refLines}

"CONFIRMED" references were verified as genuine hail damage. "DENIED" references were determined NOT to be hail damage (e.g. blistering, mechanical damage, foot traffic, manufacturing defects).

Compare the damage photo against the references. Consider classic hail indicators (random distribution, circular/elliptical impacts, granule displacement with exposed substrate, soft-metal dents, spatter marks) and common confounders (blistering, scuffing, nail pops, thermal cracking, wear).

Respond with JSON only — no explanation, no markdown fences:
{"probability": 0-100, "reasoning": "2-4 sentence explanation", "indicators": ["observed hail-consistent indicators"], "confounders": ["observed features suggesting non-hail causes"]}`;
}

router.post("/hail-analysis/analyze", async (req, res) => {
  const parsed = AnalyzeHailIndicatorsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "photoBase64 and referenceIds (non-empty) are required" });
    return;
  }
  const { photoBase64, mimeType, referenceIds } = parsed.data;

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    res.status(503).json({ message: "AI hail analysis is not configured." });
    return;
  }

  const records = readIndex();
  const selected = referenceIds
    .map((id) => records.find((r) => r.id === id))
    .filter((r): r is HailReferenceRecord => Boolean(r))
    .slice(0, MAX_REFERENCES);

  if (selected.length === 0) {
    res.status(400).json({ message: "No valid reference photos found for the given ids." });
    return;
  }

  try {
    const referenceImages = selected.map((r) => {
      const data = fs.readFileSync(path.join(DATA_DIR, r.fileName)).toString("base64");
      return {
        type: "image" as const,
        source: { type: "base64" as const, media_type: r.mimeType, data },
      };
    });

    const client = new Anthropic({ apiKey });
    const message = await client.messages.create({
      model: "claude-opus-4-8",
      max_tokens: 1024,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image",
              source: {
                type: "base64",
                media_type: mimeType as AllowedMime,
                data: photoBase64,
              },
            },
            ...referenceImages,
            { type: "text", text: buildAnalysisPrompt(selected) },
          ],
        },
      ],
    });

    const textBlock = message.content.find((b) => b.type === "text");
    const judgement =
      textBlock && "text" in textBlock ? parseAnalysis(textBlock.text) : null;

    if (!judgement) {
      res.status(502).json({ message: "AI hail analysis returned an unreadable result." });
      return;
    }

    res.json({
      probability: Math.max(0, Math.min(100, Math.round(judgement.probability ?? 0))),
      reasoning: typeof judgement.reasoning === "string" ? judgement.reasoning : "",
      indicators: toStringArray(judgement.indicators),
      confounders: toStringArray(judgement.confounders),
      disclaimer: DISCLAIMER,
    });
  } catch (err) {
    logger.error({ err }, "[hail] AI hail analysis failed");
    res.status(502).json({ message: "AI hail analysis failed." });
  }
});

export default router;
