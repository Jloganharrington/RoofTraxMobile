import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, inspectionDetailsTable } from "@workspace/db";
import {
  PutInspectionSelectedStormBody,
  PutInspectionWeatherEventsBody,
} from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// This app has no separate "create inspection" server flow (inspections are
// created client-side, see mobile/context/InspectionContext.tsx) — so these
// PUTs upsert the inspection_details row on first write, keyed by the same
// id the mobile client already generates locally.

router.put("/inspections/:id/weather-events", async (req, res) => {
  const parsed = PutInspectionWeatherEventsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "weatherEvents is required" });
    return;
  }
  const { id } = req.params;

  try {
    const [row] = await db
      .insert(inspectionDetailsTable)
      .values({ id, weatherEvents: parsed.data.weatherEvents })
      .onConflictDoUpdate({
        target: inspectionDetailsTable.id,
        set: { weatherEvents: parsed.data.weatherEvents, updatedAt: sql`now()` },
      })
      .returning();

    res.json(row);
  } catch (err) {
    logger.error({ err, id }, "[inspections] failed to persist weather-events");
    res.status(502).json({ message: "Failed to persist weather events." });
  }
});

router.put("/inspections/:id/selected-storm", async (req, res) => {
  const parsed = PutInspectionSelectedStormBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "selectedStorm is required (may be null to clear)" });
    return;
  }
  const { id } = req.params;

  try {
    const [row] = await db
      .insert(inspectionDetailsTable)
      .values({ id, selectedStorm: parsed.data.selectedStorm })
      .onConflictDoUpdate({
        target: inspectionDetailsTable.id,
        set: { selectedStorm: parsed.data.selectedStorm, updatedAt: sql`now()` },
      })
      .returning();

    res.json(row);
  } catch (err) {
    logger.error({ err, id }, "[inspections] failed to persist selected-storm");
    res.status(502).json({ message: "Failed to persist selected storm." });
  }
});

// Convenience GET so the server-side row can be inspected/tested directly
// (not in the system reference — the mobile client's local persisted profile
// is the read path there — but useful for verifying PUTs land correctly).
router.get("/inspections/:id/weather-details", async (req, res) => {
  const { id } = req.params;
  const [row] = await db
    .select()
    .from(inspectionDetailsTable)
    .where(eq(inspectionDetailsTable.id, id));

  if (!row) {
    res.status(404).json({ message: "No inspection_details row for this id." });
    return;
  }
  res.json(row);
});

export default router;
