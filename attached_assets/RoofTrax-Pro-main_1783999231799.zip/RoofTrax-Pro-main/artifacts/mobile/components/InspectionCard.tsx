import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React from "react";
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { useColors } from "@/hooks/useColors";
import type { InspectionProfile } from "@/context/InspectionContext";
import { StatusBadge } from "./StatusBadge";

interface InspectionCardProps {
  profile: InspectionProfile;
}

export function InspectionCard({ profile }: InspectionCardProps) {
  const colors = useColors();

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({ pathname: "/inspection/[id]", params: { id: profile.id } });
  };

  const formattedDate = new Date(profile.createdAt).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });

  return (
    <TouchableOpacity
      onPress={handlePress}
      activeOpacity={0.85}
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderRadius: colors.radius,
          borderColor: colors.border,
        },
      ]}
    >
      <View style={styles.iconWrapper}>
        <Feather name="home" size={24} color={colors.accent} />
      </View>
      <View style={styles.content}>
        <Text
          style={[styles.address, { color: colors.foreground }]}
          numberOfLines={2}
        >
          {profile.address}
        </Text>
        <View style={styles.meta}>
          <StatusBadge status={profile.status} />
          <Text style={[styles.date, { color: colors.mutedForeground }]}>
            {formattedDate}
          </Text>
        </View>
      </View>
      <Feather name="chevron-right" size={20} color={colors.mutedForeground} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  iconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 10,
    backgroundColor: "#FFF7ED",
    alignItems: "center",
    justifyContent: "center",
  },
  content: {
    flex: 1,
    gap: 8,
  },
  address: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    lineHeight: 20,
  },
  meta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  date: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
});
