import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useColors } from "@/hooks/useColors";

/**
 * Blocking view shown when a Phase 2 (forensic inspection) screen is opened
 * before the required customer profile & claim details have been completed.
 */
export function ForensicIntakeGuard({ inspectionId }: { inspectionId: string }) {
  const colors = useColors();

  const handleGoToIntake = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.replace({ pathname: "/inspection/customer-claim", params: { id: inspectionId } });
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.iconCircle, { backgroundColor: colors.secondary }]}>
        <Feather name="lock" size={30} color={colors.accent} />
      </View>
      <Text style={[styles.title, { color: colors.foreground }]}>
        Customer & Claim Details Required
      </Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        Complete the customer profile and claim details before continuing with
        the forensic inspection.
      </Text>
      <TouchableOpacity
        onPress={handleGoToIntake}
        activeOpacity={0.85}
        style={[
          styles.button,
          { backgroundColor: colors.accent, borderRadius: colors.radius },
        ]}
      >
        <Feather name="user-check" size={18} color="#FFFFFF" />
        <Text style={styles.buttonText}>Enter Customer & Claim Details</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
    gap: 14,
  },
  iconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  title: {
    fontSize: 19,
    fontFamily: "Inter_700Bold",
    textAlign: "center",
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    lineHeight: 21,
    textAlign: "center",
  },
  button: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 14,
    paddingHorizontal: 20,
    gap: 8,
    marginTop: 8,
  },
  buttonText: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    color: "#FFFFFF",
  },
});
