import { Feather } from "@expo/vector-icons";
import { useMutation, useQuery } from "@tanstack/react-query";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { API_BASE_URL } from "@/config/apiUrl";
import type { DamageType, InspectionProfile } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";
import { parseCityState } from "@/utils/parseAddress";
import type {
  AnalyzedStormEvent,
  SelectedStorm,
  WeatherEventsResult,
} from "@/utils/weatherTypes";

const DAMAGE_TYPE_LABELS: Record<DamageType, string> = {
  wind: "Wind",
  wind_hail: "Wind & Hail",
  hail: "Hail",
  tree: "Tree Impact",
  water_ice: "Water/Ice Damming",
};

const DAMAGE_TYPE_FINDINGS: Record<DamageType, string[]> = {
  wind: ["Wind damage observed"],
  wind_hail: ["Wind damage observed", "Hail damage observed"],
  hail: ["Hail damage observed"],
  tree: ["Tree impact damage observed"],
  water_ice: ["Water or ice damming damage observed"],
};

interface WeatherEventsCardProps {
  profile: InspectionProfile;
  onWeatherEventsPersisted: (result: WeatherEventsResult) => void;
  onSelectedStormPersisted: (storm: SelectedStorm | null) => void;
}

interface DayRow {
  date: string;
  maxHail: number | null;
  maxWind: number | null;
  minDistance: number | null;
}

function groupByDay(events: WeatherEventsResult["events"]): DayRow[] {
  const byDate = new Map<string, DayRow>();
  for (const ev of events) {
    let day = byDate.get(ev.date);
    if (!day) {
      day = { date: ev.date, maxHail: null, maxWind: null, minDistance: null };
      byDate.set(ev.date, day);
    }
    if (ev.type === "hail" && ev.size != null) {
      day.maxHail = day.maxHail == null ? ev.size : Math.max(day.maxHail, ev.size);
    }
    if ((ev.type === "wind" || ev.type === "tornado") && ev.magnitude != null) {
      day.maxWind =
        day.maxWind == null ? ev.magnitude : Math.max(day.maxWind, ev.magnitude);
    }
    if (ev.distance != null) {
      day.minDistance =
        day.minDistance == null ? ev.distance : Math.min(day.minDistance, ev.distance);
    }
  }
  return Array.from(byDate.values()).sort((a, b) =>
    a.date < b.date ? 1 : a.date > b.date ? -1 : 0,
  );
}

export function WeatherEventsCard({
  profile,
  onWeatherEventsPersisted,
  onSelectedStormPersisted,
}: WeatherEventsCardProps) {
  const colors = useColors();
  const cityState = parseCityState(profile.address);
  const hasPersisted = !!profile.weatherEvents;
  const weather = profile.weatherEvents ?? undefined;

  // Prevents double-persisting within a single session if the query resolves
  // while hasPersisted is still stale in a parent re-render cycle.
  const persistedRef = useRef(hasPersisted);

  const [expanded, setExpanded] = useState(false);
  const [analyzed, setAnalyzed] = useState<AnalyzedStormEvent[] | null>(null);

  const weatherParams = {
    city: cityState?.city ?? "",
    state: cityState?.state,
  };

  // All hooks must be called unconditionally before any conditional returns.
  const query = useQuery({
    queryKey: ["weatherEvents", weatherParams],
    queryFn: async () => {
      const params = new URLSearchParams({ city: weatherParams.city });
      if (weatherParams.state) params.set("state", weatherParams.state);
      const res = await fetch(`${API_BASE_URL}/api/weather/events?${params}`);
      const body = await res.json();
      if (!res.ok) throw body as { message?: string };
      return body as WeatherEventsResult;
    },
    // Only auto-pull when: address has city+state, damage type was selected
    // in the flow, and we don't already have a persisted copy.
    enabled: !!cityState && !hasPersisted && !!profile.damageType,
    staleTime: Infinity,
    gcTime: Infinity,
    retry: 1,
  });

  const analyzeMutation = useMutation({
    mutationFn: async (args: {
      findings: string[];
      events: WeatherEventsResult["events"];
    }) => {
      const res = await fetch(`${API_BASE_URL}/api/weather/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(args),
      });
      const body = await res.json();
      if (!res.ok) throw body as { message?: string };
      return body as { events: AnalyzedStormEvent[] };
    },
  });

  useEffect(() => {
    if (query.data && !persistedRef.current) {
      persistedRef.current = true;
      onWeatherEventsPersisted(query.data);
    }
  }, [query.data, onWeatherEventsPersisted]);

  const cardStyle = [
    styles.card,
    {
      backgroundColor: colors.card,
      borderColor: colors.border,
      borderRadius: colors.radius,
    },
  ];

  // --- Gate: no city/state in address ---
  if (!cityState) {
    return (
      <View style={cardStyle}>
        <View style={styles.headerRow}>
          <Feather name="cloud-lightning" size={18} color={colors.accent} />
          <Text style={[styles.title, { color: colors.foreground }]}>
            Storm & Weather History
          </Text>
        </View>
        <Text style={[styles.muted, { color: colors.mutedForeground }]}>
          Add a full address with city and state to look up severe-weather
          history for this property.
        </Text>
      </View>
    );
  }

  // --- Gate: damage type not yet selected in the inspection flow ---
  if (!profile.damageType) {
    return (
      <View style={cardStyle}>
        <View style={styles.headerRow}>
          <Feather name="cloud-lightning" size={18} color={colors.accent} />
          <Text style={[styles.title, { color: colors.foreground }]}>
            Storm & Weather History
          </Text>
        </View>
        <View style={styles.lockedRow}>
          <Feather name="lock" size={14} color={colors.mutedForeground} />
          <Text style={[styles.lockedText, { color: colors.mutedForeground }]}>
            Complete the preliminary inspection and select a damage type to
            unlock weather pull and storm analysis.
          </Text>
        </View>
      </View>
    );
  }

  const findings = DAMAGE_TYPE_FINDINGS[profile.damageType];
  const damageLabel = DAMAGE_TYPE_LABELS[profile.damageType];

  // --- Loading: fetching weather for the first time ---
  if (!weather && query.isLoading) {
    return (
      <View style={cardStyle}>
        <View style={styles.headerRow}>
          <ActivityIndicator size="small" color={colors.accent} />
          <Text style={[styles.title, { color: colors.foreground }]}>
            Pulling weather history…
          </Text>
        </View>
      </View>
    );
  }

  // --- Error: fetch failed and nothing persisted ---
  if (!weather && query.isError) {
    const message =
      (query.error as { message?: string } | undefined)?.message ??
      "Could not retrieve weather history right now.";
    return (
      <View style={cardStyle}>
        <View style={styles.headerRow}>
          <Feather name="alert-triangle" size={18} color={colors.destructive} />
          <Text style={[styles.title, { color: colors.foreground }]}>
            Weather lookup unavailable
          </Text>
        </View>
        <Text style={[styles.muted, { color: colors.mutedForeground }]}>
          {message}
        </Text>
      </View>
    );
  }

  if (!weather) return null;

  const days = groupByDay(weather.events);

  const handleAnalyze = () => {
    analyzeMutation.mutate(
      { findings, events: weather.events },
      {
        onSuccess: (res) => setAnalyzed(res.events),
        onError: (err) => {
          const msg =
            (err as { message?: string } | undefined)?.message ??
            "Could not analyze storm events. Please try again.";
          Alert.alert("Analysis failed", msg);
        },
      },
    );
  };

  const handleSelectStorm = (ev: AnalyzedStormEvent) => {
    const storm: SelectedStorm = {
      date: ev.date,
      hailSize: ev.hailSize,
      windSpeed: ev.windSpeed,
      distance: ev.distance,
      probability: ev.probability,
      reason: ev.reason,
      description: ev.description,
    };
    onSelectedStormPersisted(storm);
  };

  const handleClearStorm = () => {
    onSelectedStormPersisted(null);
  };

  return (
    <View style={cardStyle}>
      <View style={styles.headerRow}>
        <Feather name="cloud-lightning" size={18} color={colors.accent} />
        <Text style={[styles.title, { color: colors.foreground }]}>
          Storm & Weather History
        </Text>
      </View>

      {/* Damage type badge — shows what the analysis is scoped to */}
      <View
        style={[
          styles.damageTypeBadge,
          {
            backgroundColor: colors.secondary,
            borderRadius: colors.radius / 2,
          },
        ]}
      >
        <Feather name="tag" size={12} color={colors.accent} />
        <Text style={[styles.damageTypeBadgeText, { color: colors.foreground }]}>
          Damage type:{" "}
          <Text style={{ color: colors.accent, fontFamily: "Inter_600SemiBold" }}>
            {damageLabel}
          </Text>
        </Text>
      </View>

      <View style={styles.chipRow}>
        <CountChip label="Hail" count={weather.counts.hail} color="#F97316" />
        <CountChip label="Wind" count={weather.counts.wind} color="#3B82F6" />
        <CountChip
          label="Tornado"
          count={weather.counts.tornado}
          color="#EF4444"
        />
      </View>

      <TouchableOpacity
        onPress={() => setExpanded((e) => !e)}
        style={styles.expandRow}
        activeOpacity={0.7}
      >
        <Text style={[styles.expandText, { color: colors.accent }]}>
          {expanded ? "Hide" : "Show"} day-by-day detail ({days.length} days)
        </Text>
        <Feather
          name={expanded ? "chevron-up" : "chevron-down"}
          size={16}
          color={colors.accent}
        />
      </TouchableOpacity>

      {expanded && (
        <View style={styles.table}>
          {days.map((d) => (
            <View
              key={d.date}
              style={[styles.tableRow, { borderTopColor: colors.border }]}
            >
              <Text
                style={[
                  styles.tableCell,
                  styles.tableCellDate,
                  { color: colors.foreground },
                ]}
              >
                {d.date}
              </Text>
              <Text style={[styles.tableCell, { color: colors.mutedForeground }]}>
                {d.maxHail != null ? `${d.maxHail.toFixed(2)}"` : "—"}
              </Text>
              <Text style={[styles.tableCell, { color: colors.mutedForeground }]}>
                {d.maxWind != null ? `${Math.round(d.maxWind)} mph` : "—"}
              </Text>
              <Text style={[styles.tableCell, { color: colors.mutedForeground }]}>
                {d.minDistance != null ? `${d.minDistance.toFixed(1)} mi` : "—"}
              </Text>
            </View>
          ))}
        </View>
      )}

      <Text style={[styles.attribution, { color: colors.mutedForeground }]}>
        Powered by VisualCrossing
      </Text>

      <View style={[styles.divider, { borderTopColor: colors.border }]} />

      <TouchableOpacity
        onPress={handleAnalyze}
        disabled={analyzeMutation.isPending}
        activeOpacity={0.85}
        style={[
          styles.analyzeButton,
          {
            backgroundColor: analyzeMutation.isPending
              ? colors.muted
              : colors.accent,
            borderRadius: colors.radius,
          },
        ]}
      >
        {analyzeMutation.isPending ? (
          <ActivityIndicator size="small" color="#FFFFFF" />
        ) : (
          <Feather name="zap" size={16} color="#FFFFFF" />
        )}
        <Text style={styles.analyzeButtonText}>
          {analyzeMutation.isPending ? "Analyzing…" : "Analyze Cause of Loss"}
        </Text>
      </TouchableOpacity>

      {analyzed && analyzed.length > 0 && (
        <View style={styles.analyzedList}>
          {analyzed.map((ev) => {
            const isSelected = profile.selectedStorm?.date === ev.date;
            return (
              <TouchableOpacity
                key={ev.date}
                onPress={() => handleSelectStorm(ev)}
                activeOpacity={0.85}
                style={[
                  styles.analyzedRow,
                  {
                    borderColor: isSelected ? colors.accent : colors.border,
                    backgroundColor: isSelected ? colors.secondary : "transparent",
                    borderRadius: colors.radius / 2,
                  },
                ]}
              >
                <View style={{ flex: 1 }}>
                  <Text
                    style={[styles.analyzedDate, { color: colors.foreground }]}
                  >
                    {ev.date}
                  </Text>
                  {ev.reason && (
                    <Text
                      style={[
                        styles.analyzedReason,
                        { color: colors.mutedForeground },
                      ]}
                      numberOfLines={2}
                    >
                      {ev.reason}
                    </Text>
                  )}
                </View>
                <Text
                  style={[
                    styles.analyzedProbability,
                    { color: colors.accent },
                  ]}
                >
                  {ev.probability}%
                </Text>
                {isSelected && (
                  <Feather name="check-circle" size={18} color={colors.accent} />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      )}

      {profile.selectedStorm && (
        <View
          style={[
            styles.selectedBanner,
            {
              backgroundColor: colors.secondary,
              borderRadius: colors.radius / 2,
            },
          ]}
        >
          <Feather name="check-circle" size={16} color={colors.success} />
          <Text
            style={[styles.selectedBannerText, { color: colors.foreground }]}
            numberOfLines={1}
          >
            Cause of loss: {profile.selectedStorm.date} (
            {profile.selectedStorm.probability}% match)
          </Text>
          <TouchableOpacity onPress={handleClearStorm}>
            <Feather name="x" size={16} color={colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

function CountChip({
  label,
  count,
  color,
}: {
  label: string;
  count: number;
  color: string;
}) {
  return (
    <View style={[styles.countChip, { borderColor: color }]}>
      <Text style={[styles.countChipCount, { color }]}>{count}</Text>
      <Text style={[styles.countChipLabel, { color }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 16,
    borderWidth: 1,
    gap: 12,
  },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  title: { fontSize: 15, fontFamily: "Inter_700Bold" },
  muted: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 18 },
  lockedRow: { flexDirection: "row", gap: 8, alignItems: "flex-start" },
  lockedText: {
    flex: 1,
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    lineHeight: 18,
  },
  damageTypeBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    alignSelf: "flex-start",
  },
  damageTypeBadgeText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  chipRow: { flexDirection: "row", gap: 8 },
  countChip: {
    flex: 1,
    borderWidth: 1.5,
    borderRadius: 10,
    paddingVertical: 8,
    alignItems: "center",
    gap: 2,
  },
  countChipCount: { fontSize: 18, fontFamily: "Inter_700Bold" },
  countChipLabel: { fontSize: 11, fontFamily: "Inter_500Medium" },
  expandRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  expandText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  table: { gap: 0 },
  tableRow: {
    flexDirection: "row",
    paddingVertical: 8,
    borderTopWidth: 1,
  },
  tableCell: { flex: 1, fontSize: 12, fontFamily: "Inter_400Regular" },
  tableCellDate: { flex: 1.2, fontFamily: "Inter_500Medium" },
  attribution: { fontSize: 10, fontFamily: "Inter_400Regular" },
  divider: { borderTopWidth: 1, marginVertical: 2 },
  analyzeButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 14,
  },
  analyzeButtonText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  analyzedList: { gap: 8 },
  analyzedRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 12,
    borderWidth: 1,
  },
  analyzedDate: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  analyzedReason: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  analyzedProbability: { fontSize: 14, fontFamily: "Inter_700Bold" },
  selectedBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 10,
  },
  selectedBannerText: {
    flex: 1,
    fontSize: 12,
    fontFamily: "Inter_500Medium",
  },
});
