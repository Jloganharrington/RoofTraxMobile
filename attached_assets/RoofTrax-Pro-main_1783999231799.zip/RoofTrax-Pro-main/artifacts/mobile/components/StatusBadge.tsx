import React from "react";
import { StyleSheet, Text, View } from "react-native";

import { useColors } from "@/hooks/useColors";
import type { InspectionStatus } from "@/context/InspectionContext";

interface StatusBadgeProps {
  status: InspectionStatus;
}

const STATUS_CONFIG: Record<
  InspectionStatus,
  { label: string; bg: string; text: string }
> = {
  not_started: { label: "Not Started", bg: "#F3F4F6", text: "#6B7280" },
  in_progress: { label: "In Progress", bg: "#FFF7ED", text: "#F97316" },
  report_ready: { label: "Report Ready", bg: "#F0FDF4", text: "#22C55E" },
};

export function StatusBadge({ status }: StatusBadgeProps) {
  const colors = useColors();
  const config = STATUS_CONFIG[status];

  return (
    <View
      style={[
        styles.badge,
        { backgroundColor: config.bg, borderRadius: colors.radius / 2 },
      ]}
    >
      <View
        style={[styles.dot, { backgroundColor: config.text }]}
      />
      <Text style={[styles.label, { color: config.text }]}>{config.label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 4,
    gap: 6,
    alignSelf: "flex-start",
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  label: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.2,
  },
});
