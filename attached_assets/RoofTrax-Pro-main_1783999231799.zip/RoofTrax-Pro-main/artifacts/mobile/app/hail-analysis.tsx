import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { Stack, useLocalSearchParams } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import {
  BETA_PURPLE,
  BETA_PURPLE_BG,
  analyzeHailIndicators,
  fetchHailReferences,
  guessMimeType,
  photoUriToBase64,
  referenceImageUri,
  type HailAnalysisResult,
  type HailReferenceItem,
} from "@/utils/hailBeta";

// ---------------------------------------------------------------------------
// Standalone BETA screen — AI hail-indicator analysis. The result lives only
// in this screen's local state: it is never written to InspectionContext,
// never persisted, and never appears in generated reports.
// ---------------------------------------------------------------------------

const MAX_SELECTABLE = 5;

export default function HailAnalysisScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { photoUri } = useLocalSearchParams<{ photoUri: string }>();
  const damagePhotoUri = typeof photoUri === "string" ? photoUri : "";

  const [references, setReferences] = useState<HailReferenceItem[]>([]);
  const [loadingRefs, setLoadingRefs] = useState(true);
  const [refsError, setRefsError] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const [analyzing, setAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [result, setResult] = useState<HailAnalysisResult | null>(null);

  const loadRefs = useCallback(async () => {
    try {
      setRefsError(null);
      const list = await fetchHailReferences();
      setReferences(list);
    } catch (err) {
      setRefsError(err instanceof Error ? err.message : "Failed to load the reference library.");
    } finally {
      setLoadingRefs(false);
    }
  }, []);

  useEffect(() => {
    loadRefs();
  }, [loadRefs]);

  const toggleSelect = (id: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedIds((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= MAX_SELECTABLE) return prev;
      return [...prev, id];
    });
  };

  const handleAnalyze = async () => {
    if (!damagePhotoUri || selectedIds.length === 0 || analyzing) return;
    setAnalyzing(true);
    setAnalysisError(null);
    setResult(null);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      const photoBase64 = await photoUriToBase64(damagePhotoUri);
      const analysis = await analyzeHailIndicators({
        photoBase64,
        mimeType: guessMimeType(damagePhotoUri),
        referenceIds: selectedIds,
      });
      setResult(analysis);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setAnalysisError(err instanceof Error ? err.message : "Analysis failed. Please try again.");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setAnalyzing(false);
    }
  };

  const probabilityColor = (p: number) =>
    p >= 70 ? colors.destructive : p >= 40 ? "#F59E0B" : colors.success;

  const thumbSize = (width - 40 - 16 - 20) / 3;

  return (
    <>
      <Stack.Screen options={{ title: "Hail Analysis (Beta)" }} />
      <ScrollView
        style={[styles.container, { backgroundColor: colors.background }]}
        contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 40 }}
      >
        {/* Beta banner */}
        <View style={[styles.betaBanner, { backgroundColor: BETA_PURPLE_BG, borderRadius: colors.radius }]}>
          <View style={[styles.betaChip, { backgroundColor: BETA_PURPLE }]}>
            <Text style={styles.betaChipText}>BETA</Text>
          </View>
          <Text style={[styles.betaBannerText, { color: BETA_PURPLE }]}>
            Experimental AI comparison against your reference library. Results are not saved and
            never appear in reports.
          </Text>
        </View>

        {/* Damage photo */}
        <View
          style={[
            styles.section,
            { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>DAMAGE PHOTO</Text>
          {damagePhotoUri ? (
            <Image
              source={{ uri: damagePhotoUri }}
              style={[styles.damagePhoto, { borderRadius: colors.radius / 2 }]}
              resizeMode="cover"
            />
          ) : (
            <Text style={[styles.mutedText, { color: colors.mutedForeground }]}>
              No photo was provided.
            </Text>
          )}
        </View>

        {/* Reference selection */}
        <View
          style={[
            styles.section,
            { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>
            COMPARE AGAINST REFERENCES ({selectedIds.length}/{MAX_SELECTABLE})
          </Text>

          {loadingRefs ? (
            <ActivityIndicator color={BETA_PURPLE} style={{ paddingVertical: 20 }} />
          ) : refsError ? (
            <Text style={[styles.mutedText, { color: colors.destructive }]}>{refsError}</Text>
          ) : references.length === 0 ? (
            <Text style={[styles.mutedText, { color: colors.mutedForeground }]}>
              Your reference library is empty. Add adjudicated hail photos in the Hail Reference
              Library (Settings tab) first.
            </Text>
          ) : (
            <View style={styles.refGrid}>
              {references.map((item) => {
                const selected = selectedIds.includes(item.id);
                return (
                  <TouchableOpacity
                    key={item.id}
                    onPress={() => toggleSelect(item.id)}
                    activeOpacity={0.8}
                    style={[
                      styles.refCell,
                      {
                        width: thumbSize,
                        borderColor: selected ? BETA_PURPLE : colors.border,
                        borderWidth: selected ? 2.5 : 1,
                        borderRadius: colors.radius / 2,
                      },
                    ]}
                  >
                    <Image
                      source={{ uri: referenceImageUri(item) }}
                      style={{ width: "100%", height: thumbSize, borderRadius: colors.radius / 2 - 2 }}
                      resizeMode="cover"
                    />
                    {selected && (
                      <View style={[styles.refCheck, { backgroundColor: BETA_PURPLE }]}>
                        <Feather name="check" size={12} color="#FFFFFF" />
                      </View>
                    )}
                    <View
                      style={[
                        styles.refStatusStrip,
                        {
                          backgroundColor:
                            item.status === "confirmed" ? colors.success : colors.destructive,
                        },
                      ]}
                    >
                      <Text style={styles.refStatusText}>
                        {item.status === "confirmed" ? "CONFIRMED" : "DENIED"}
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </View>

        {/* Analyze button */}
        <TouchableOpacity
          onPress={handleAnalyze}
          activeOpacity={0.85}
          disabled={!damagePhotoUri || selectedIds.length === 0 || analyzing}
          style={[
            styles.analyzeButton,
            {
              backgroundColor: BETA_PURPLE,
              borderRadius: colors.radius,
              opacity: !damagePhotoUri || selectedIds.length === 0 || analyzing ? 0.5 : 1,
            },
          ]}
        >
          {analyzing ? (
            <ActivityIndicator color="#FFFFFF" size="small" />
          ) : (
            <Feather name="zap" size={18} color="#FFFFFF" />
          )}
          <Text style={styles.analyzeButtonText}>
            {analyzing ? "Analyzing..." : "Run Hail Analysis"}
          </Text>
        </TouchableOpacity>

        {analysisError ? (
          <View style={[styles.errorBox, { backgroundColor: colors.destructive + "15", borderRadius: colors.radius }]}>
            <Feather name="alert-triangle" size={16} color={colors.destructive} />
            <Text style={[styles.errorText, { color: colors.destructive }]}>{analysisError}</Text>
          </View>
        ) : null}

        {/* Result */}
        {result && (
          <View
            style={[
              styles.section,
              {
                backgroundColor: colors.card,
                borderColor: BETA_PURPLE,
                borderWidth: 1.5,
                borderRadius: colors.radius,
                marginTop: 16,
              },
            ]}
          >
            <Text style={[styles.sectionTitle, { color: BETA_PURPLE }]}>ANALYSIS RESULT</Text>

            <View style={styles.probRow}>
              <Text
                style={[styles.probValue, { color: probabilityColor(result.probability) }]}
              >
                {result.probability}%
              </Text>
              <Text style={[styles.probLabel, { color: colors.foreground }]}>
                Based on a comparative analysis between this photo and 10 other verified
                hail damage photos, the probability of this photo representing physical
                hail damage is {result.probability}%.
              </Text>
            </View>

            <Text style={[styles.resultHeading, { color: colors.foreground }]}>Reasoning</Text>
            <Text style={[styles.resultBody, { color: colors.foreground }]}>
              {result.reasoning || "No reasoning provided."}
            </Text>

            <Text style={[styles.resultHeading, { color: colors.foreground }]}>
              Hail Indicators Observed
            </Text>
            {result.indicators.length > 0 ? (
              result.indicators.map((ind, i) => (
                <View key={`ind-${i}`} style={styles.bulletRow}>
                  <Feather name="check-circle" size={14} color={colors.success} style={styles.bulletIcon} />
                  <Text style={[styles.bulletText, { color: colors.foreground }]}>{ind}</Text>
                </View>
              ))
            ) : (
              <Text style={[styles.mutedText, { color: colors.mutedForeground }]}>
                None identified.
              </Text>
            )}

            <Text style={[styles.resultHeading, { color: colors.foreground }]}>
              Possible Confounders
            </Text>
            {result.confounders.length > 0 ? (
              result.confounders.map((c, i) => (
                <View key={`conf-${i}`} style={styles.bulletRow}>
                  <Feather name="alert-circle" size={14} color="#F59E0B" style={styles.bulletIcon} />
                  <Text style={[styles.bulletText, { color: colors.foreground }]}>{c}</Text>
                </View>
              ))
            ) : (
              <Text style={[styles.mutedText, { color: colors.mutedForeground }]}>
                None identified.
              </Text>
            )}

            <View style={[styles.disclaimer, { backgroundColor: BETA_PURPLE_BG, borderRadius: colors.radius / 2 }]}>
              <Feather name="shield" size={14} color={BETA_PURPLE} />
              <Text style={[styles.disclaimerText, { color: BETA_PURPLE }]}>
                {result.disclaimer}
              </Text>
            </View>
          </View>
        )}
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  betaBanner: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    padding: 14,
    marginBottom: 16,
  },
  betaChip: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginTop: 1,
  },
  betaChipText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontFamily: "Inter_700Bold",
    letterSpacing: 1,
  },
  betaBannerText: { flex: 1, fontSize: 12.5, fontFamily: "Inter_500Medium", lineHeight: 18 },
  section: {
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  sectionTitle: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 1,
    marginBottom: 14,
  },
  damagePhoto: { width: "100%", height: 220, backgroundColor: "#EEE" },
  mutedText: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 19 },
  refGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  refCell: { position: "relative", overflow: "hidden" },
  refCheck: {
    position: "absolute",
    top: 6,
    right: 6,
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  refStatusStrip: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingVertical: 3,
    alignItems: "center",
  },
  refStatusText: {
    color: "#FFFFFF",
    fontSize: 8.5,
    fontFamily: "Inter_700Bold",
    letterSpacing: 0.5,
  },
  analyzeButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 15,
  },
  analyzeButtonText: { color: "#FFFFFF", fontSize: 15, fontFamily: "Inter_600SemiBold" },
  errorBox: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    padding: 12,
    marginTop: 12,
  },
  errorText: { flex: 1, fontSize: 13, fontFamily: "Inter_500Medium", lineHeight: 18 },
  probRow: { flexDirection: "row", alignItems: "baseline", gap: 10, marginBottom: 14 },
  probValue: { fontSize: 40, fontFamily: "Inter_700Bold" },
  probLabel: { flex: 1, fontSize: 13, fontFamily: "Inter_500Medium", lineHeight: 18 },
  resultHeading: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    marginTop: 12,
    marginBottom: 6,
  },
  resultBody: { fontSize: 13.5, fontFamily: "Inter_400Regular", lineHeight: 20 },
  bulletRow: { flexDirection: "row", alignItems: "flex-start", gap: 8, marginBottom: 6 },
  bulletIcon: { marginTop: 2 },
  bulletText: { flex: 1, fontSize: 13.5, fontFamily: "Inter_400Regular", lineHeight: 19 },
  disclaimer: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    padding: 12,
    marginTop: 16,
  },
  disclaimerText: { flex: 1, fontSize: 11.5, fontFamily: "Inter_500Medium", lineHeight: 16 },
});
