import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React from "react";
import {
  Alert,
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ForensicIntakeGuard } from "@/components/ForensicIntakeGuard";
import {
  isForensicIntakeComplete,
  REQUIRED_PHOTOS_PER_DAMAGE,
  useInspections,
  type DamageInstance,
  type DamageSeverity,
  type InstanceDamageType,
} from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";

const TYPE_LABELS: Record<InstanceDamageType, string> = {
  hail: "Hail",
  wind: "Wind",
  wind_hail: "Wind & Hail",
  tree: "Tree Impact",
  water_ice: "Water/Ice",
  other: "Other",
};

const TYPE_ICONS: Record<InstanceDamageType, string> = {
  hail: "cloud-snow",
  wind: "wind",
  wind_hail: "cloud-rain",
  tree: "git-merge",
  water_ice: "droplet",
  other: "alert-circle",
};

const SEVERITY_COLORS: Record<DamageSeverity, string> = {
  minor: "#3B82F6",
  moderate: "#F97316",
  severe: "#EF4444",
};

const SEVERITY_LABELS: Record<DamageSeverity, string> = {
  minor: "Minor",
  moderate: "Moderate",
  severe: "Severe",
};

export default function SlopeDamagesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id, slopeId, slopeLabel } = useLocalSearchParams<{
    id: string;
    slopeId: string;
    slopeLabel: string;
  }>();
  const { getProfile, deleteDamageInstance } = useInspections();

  const profile = getProfile(id);
  const slope = profile?.slopes?.find((s) => s.id === slopeId);
  const instances = slope?.damageInstances ?? [];

  // Phase 2 gate — customer profile & claim details must be complete first.
  if (profile && !isForensicIntakeComplete(profile)) {
    return <ForensicIntakeGuard inspectionId={id} />;
  }

  const handleAddDamage = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({
      pathname: "/inspection/damage-form",
      params: { id, slopeId },
    });
  };

  const handleEditDamage = (instance: DamageInstance) => {
    router.push({
      pathname: "/inspection/damage-form",
      params: { id, slopeId, damageId: instance.id },
    });
  };

  const handleDeleteDamage = (instance: DamageInstance) => {
    const label = TYPE_LABELS[instance.damageType] ?? "Damage";
    Alert.alert("Delete Damage Instance", `Delete this "${label}" instance?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          deleteDamageInstance(id, slopeId, instance.id);
        },
      },
    ]);
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={instances}
        keyExtractor={(d) => d.id}
        contentContainerStyle={[
          styles.listContent,
          instances.length === 0 && styles.listEmpty,
        ]}
        ListHeaderComponent={
          <View
            style={[
              styles.slopeHeader,
              { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
            ]}
          >
            <Feather name="layers" size={16} color={colors.accent} />
            <Text style={[styles.slopeHeaderText, { color: colors.foreground }]}>
              {slopeLabel ?? "Slope"}
            </Text>
            <Text style={[styles.slopeHeaderCount, { color: colors.mutedForeground }]}>
              {instances.length} instance{instances.length !== 1 ? "s" : ""}
            </Text>
          </View>
        }
        ListEmptyComponent={
          <View style={styles.emptyWrap}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="alert-triangle" size={36} color={colors.mutedForeground} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              No damage documented
            </Text>
            <Text style={[styles.emptySubtitle, { color: colors.mutedForeground }]}>
              Tap "+ Add Damage" to document the first damage instance on this slope.
            </Text>
          </View>
        }
        renderItem={({ item: instance }) => {
          const typeIcon = TYPE_ICONS[instance.damageType] ?? "alert-circle";
          const typeLabel = TYPE_LABELS[instance.damageType] ?? "Unknown";
          const severityColor = SEVERITY_COLORS[instance.severity] ?? "#6B7280";
          const severityLabel = SEVERITY_LABELS[instance.severity] ?? instance.severity;
          const photoCount = instance.photos.length;
          const photosOk = photoCount >= REQUIRED_PHOTOS_PER_DAMAGE;

          return (
            <TouchableOpacity
              onPress={() => handleEditDamage(instance)}
              activeOpacity={0.85}
              style={[
                styles.instanceCard,
                {
                  backgroundColor: colors.card,
                  borderColor: instance.isComplete ? colors.success : colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              {/* Type icon */}
              <View style={[styles.typeIcon, { backgroundColor: colors.secondary }]}>
                <Feather name={typeIcon as any} size={20} color={colors.accent} />
              </View>

              {/* Body */}
              <View style={styles.instanceBody}>
                <View style={styles.instanceTopRow}>
                  <Text style={[styles.instanceType, { color: colors.foreground }]}>
                    {typeLabel}
                  </Text>
                  <View
                    style={[
                      styles.severityBadge,
                      { backgroundColor: severityColor + "22" },
                    ]}
                  >
                    <Text style={[styles.severityText, { color: severityColor }]}>
                      {severityLabel}
                    </Text>
                  </View>
                </View>

                <View style={styles.instanceMeta}>
                  {/* Photo count */}
                  <View style={styles.metaItem}>
                    <Feather
                      name="camera"
                      size={12}
                      color={photosOk ? colors.success : colors.mutedForeground}
                    />
                    <Text
                      style={[
                        styles.metaText,
                        { color: photosOk ? colors.success : colors.mutedForeground },
                      ]}
                    >
                      {photoCount}/{REQUIRED_PHOTOS_PER_DAMAGE} photos
                    </Text>
                  </View>

                  {/* Citations */}
                  {instance.codeCitationIds.length > 0 && (
                    <View style={styles.metaItem}>
                      <Feather name="book-open" size={12} color={colors.mutedForeground} />
                      <Text style={[styles.metaText, { color: colors.mutedForeground }]}>
                        {instance.codeCitationIds.length} citation
                        {instance.codeCitationIds.length !== 1 ? "s" : ""}
                      </Text>
                    </View>
                  )}

                  {/* Discontinued product flag */}
                  {instance.discontinuedProduct && (
                    <View style={styles.metaItem}>
                      <Feather name="alert-circle" size={12} color="#F97316" />
                      <Text style={[styles.metaText, { color: "#F97316" }]}>Discontinued</Text>
                    </View>
                  )}
                </View>

                {instance.causationNote ? (
                  <Text
                    style={[styles.causationNote, { color: colors.mutedForeground }]}
                    numberOfLines={1}
                  >
                    {instance.causationNote}
                  </Text>
                ) : null}
              </View>

              {/* Right side */}
              <View style={styles.instanceRight}>
                {instance.isComplete ? (
                  <Feather name="check-circle" size={20} color={colors.success} />
                ) : (
                  <Feather name="circle" size={20} color={colors.muted} />
                )}
                <TouchableOpacity
                  onPress={() => handleDeleteDamage(instance)}
                  hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                >
                  <Feather name="trash-2" size={15} color={colors.destructive} />
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          );
        }}
      />

      <View style={[styles.footer, { paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity
          onPress={handleAddDamage}
          activeOpacity={0.85}
          style={[
            styles.addButton,
            { backgroundColor: colors.accent, borderRadius: colors.radius },
          ]}
        >
          <Feather name="plus" size={20} color="#FFFFFF" />
          <Text style={styles.addButtonText}>Add Damage</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  listContent: { padding: 16, gap: 12 },
  listEmpty: { flex: 1 },
  slopeHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderWidth: 1,
    marginBottom: 4,
  },
  slopeHeaderText: { flex: 1, fontSize: 15, fontFamily: "Inter_600SemiBold" },
  slopeHeaderCount: { fontSize: 12, fontFamily: "Inter_400Regular" },
  emptyWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 14,
    padding: 32,
    marginTop: 40,
  },
  emptyIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyTitle: { fontSize: 17, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  emptySubtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
  instanceCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    padding: 14,
    borderWidth: 1.5,
    gap: 12,
  },
  typeIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 2,
  },
  instanceBody: { flex: 1, gap: 6 },
  instanceTopRow: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" },
  instanceType: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  severityBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  severityText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  instanceMeta: { flexDirection: "row", gap: 12, flexWrap: "wrap" },
  metaItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  metaText: { fontSize: 11, fontFamily: "Inter_400Regular" },
  causationNote: { fontSize: 12, fontFamily: "Inter_400Regular", fontStyle: "italic" },
  instanceRight: { alignItems: "center", gap: 10, paddingTop: 2 },
  footer: { paddingHorizontal: 16, paddingTop: 8 },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 8,
  },
  addButtonText: { color: "#FFFFFF", fontSize: 16, fontFamily: "Inter_600SemiBold" },
});
