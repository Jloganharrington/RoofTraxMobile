import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as Location from "expo-location";
import { router } from "expo-router";
import React, { useRef, useState } from "react";
import {
  ActivityIndicator,
  Linking,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useInspections } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";

function formatGeocodedAddress(g: Location.LocationGeocodedAddress): string {
  const streetLine =
    [g.streetNumber, g.street].filter(Boolean).join(" ") || g.name || "";
  const cityLine = [g.city, g.region].filter(Boolean).join(", ");
  const parts = [streetLine, cityLine, g.postalCode].filter(
    (p) => p && p.length > 0,
  );
  return parts.join(", ");
}

export default function NewInspectionScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { createProfile } = useInspections();
  const [address, setAddress] = useState("");
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [showSettingsHint, setShowSettingsHint] = useState(false);
  const inputRef = useRef<TextInput>(null);
  const [permission, requestPermission] = Location.useForegroundPermissions();

  const canCreate = address.trim().length > 5;

  const handleCreate = () => {
    if (!canCreate) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const profile = createProfile(address.trim());
    router.replace({ pathname: "/inspection/[id]", params: { id: profile.id } });
  };

  const handleUseCurrentLocation = async () => {
    setLocationError(null);
    setShowSettingsHint(false);
    setLocating(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      // 1. Permission
      let granted = permission?.granted ?? false;
      if (!granted) {
        if (permission && !permission.granted && !permission.canAskAgain) {
          setLocationError(
            "Location permission is turned off. Enable it in Settings, or type the address manually.",
          );
          setShowSettingsHint(Platform.OS !== "web");
          setLocating(false);
          return;
        }
        const res = await requestPermission();
        granted = res.granted;
        if (!granted) {
          setLocationError(
            "Location permission was denied — no problem, just type the address manually.",
          );
          setShowSettingsHint(Platform.OS !== "web" && !res.canAskAgain);
          setLocating(false);
          return;
        }
      }

      // 2. Current position
      const position = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });

      // 3. Reverse geocode → street address
      const results = await Location.reverseGeocodeAsync({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      });

      const formatted = results.length > 0 ? formatGeocodedAddress(results[0]) : "";
      if (!formatted) {
        setLocationError(
          "Couldn't determine a street address for your location. Please type it manually.",
        );
        setLocating(false);
        return;
      }

      setAddress(formatted);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {
      setLocationError(
        "Couldn't get your location. Please type the address manually.",
      );
    } finally {
      setLocating(false);
    }
  };

  const handleOpenSettings = async () => {
    try {
      await Linking.openSettings();
    } catch {
      // Ignore — user can still type the address manually.
    }
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.inner}>
        <View
          style={[
            styles.iconCircle,
            { backgroundColor: colors.secondary },
          ]}
        >
          <Feather name="map-pin" size={32} color={colors.accent} />
        </View>

        <Text style={[styles.title, { color: colors.foreground }]}>
          Inspection Address
        </Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Enter the property address to begin a new inspection profile.
        </Text>

        <TextInput
          ref={inputRef}
          style={[
            styles.input,
            {
              backgroundColor: colors.card,
              color: colors.foreground,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
          value={address}
          onChangeText={(t) => {
            setAddress(t);
            setLocationError(null);
            setShowSettingsHint(false);
          }}
          placeholder="e.g. 123 Main St, Springfield, IL 62701"
          placeholderTextColor={colors.mutedForeground}
          multiline
          numberOfLines={3}
          textAlignVertical="top"
          returnKeyType="done"
          autoFocus
        />

        {/* Use current location */}
        <TouchableOpacity
          onPress={handleUseCurrentLocation}
          disabled={locating}
          activeOpacity={0.8}
          style={[
            styles.locationButton,
            {
              borderColor: colors.accent,
              borderRadius: colors.radius,
              backgroundColor: colors.card,
              opacity: locating ? 0.7 : 1,
            },
          ]}
        >
          {locating ? (
            <ActivityIndicator size="small" color={colors.accent} />
          ) : (
            <Feather name="navigation" size={17} color={colors.accent} />
          )}
          <Text style={[styles.locationButtonText, { color: colors.accent }]}>
            {locating ? "Finding your address…" : "Use current location"}
          </Text>
        </TouchableOpacity>

        {locationError && (
          <View
            style={[
              styles.locationErrorBanner,
              { backgroundColor: "#FFFBEB", borderRadius: colors.radius },
            ]}
          >
            <Feather name="alert-triangle" size={15} color="#F59E0B" />
            <View style={{ flex: 1, gap: 6 }}>
              <Text style={styles.locationErrorText}>{locationError}</Text>
              {showSettingsHint && (
                <TouchableOpacity onPress={handleOpenSettings} activeOpacity={0.7}>
                  <Text style={[styles.settingsLink, { color: colors.accent }]}>
                    Open Settings
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        )}

        <TouchableOpacity
          onPress={handleCreate}
          activeOpacity={0.85}
          disabled={!canCreate}
          style={[
            styles.createButton,
            {
              backgroundColor: canCreate ? colors.primary : colors.muted,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Feather
            name="plus-circle"
            size={20}
            color={canCreate ? colors.primaryForeground : colors.mutedForeground}
          />
          <Text
            style={[
              styles.createButtonText,
              {
                color: canCreate ? colors.primaryForeground : colors.mutedForeground,
              },
            ]}
          >
            Create Inspection Profile
          </Text>
        </TouchableOpacity>
      </View>

      <View style={{ height: bottomPad }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  inner: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 32,
    gap: 16,
  },
  iconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  title: {
    fontSize: 26,
    fontFamily: "Inter_700Bold",
    lineHeight: 32,
  },
  subtitle: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    lineHeight: 22,
  },
  input: {
    padding: 16,
    fontSize: 16,
    fontFamily: "Inter_400Regular",
    borderWidth: 1.5,
    minHeight: 90,
    marginTop: 8,
    lineHeight: 24,
  },
  locationButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 13,
    gap: 8,
    borderWidth: 1.5,
  },
  locationButtonText: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
  },
  locationErrorBanner: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    padding: 12,
  },
  locationErrorText: {
    fontSize: 13,
    color: "#92400E",
    fontFamily: "Inter_400Regular",
    lineHeight: 18,
  },
  settingsLink: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  createButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 10,
  },
  createButtonText: {
    fontSize: 17,
    fontFamily: "Inter_600SemiBold",
  },
});
