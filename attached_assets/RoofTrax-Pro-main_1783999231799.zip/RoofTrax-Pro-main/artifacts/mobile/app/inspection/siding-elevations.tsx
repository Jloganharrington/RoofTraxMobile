import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Modal,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ForensicIntakeGuard } from "@/components/ForensicIntakeGuard";
import {
  isForensicIntakeComplete,
  useInspections,
  type SidingElevation,
  type SidingElevationEntry,
} from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";

const ELEVATIONS: { value: SidingElevation; label: string; icon: string }[] = [
  { value: "front", label: "Front", icon: "home" },
  { value: "back", label: "Back", icon: "arrow-up" },
  { value: "left", label: "Left", icon: "arrow-left" },
  { value: "right", label: "Right", icon: "arrow-right" },
  { value: "other", label: "Other", icon: "more-horizontal" },
];

const ELEVATION_LABELS: Record<SidingElevation, string> = Object.fromEntries(
  ELEVATIONS.map((e) => [e.value, e.label]),
) as Record<SidingElevation, string>;

const ELEVATION_ICONS: Record<SidingElevation, string> = Object.fromEntries(
  ELEVATIONS.map((e) => [e.value, e.icon]),
) as Record<SidingElevation, string>;

export default function SidingElevationsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getProfile, addElevation, deleteElevation } = useInspections();

  const profile = getProfile(id);
  const elevations = profile?.sidingElevations ?? [];

  const [modalVisible, setModalVisible] = useState(false);
  const [pendingElevation, setPendingElevation] = useState<SidingElevation | null>(null);
  const [pendingLabel, setPendingLabel] = useState("");

  // Phase 2 gate — customer profile & claim details must be complete first.
  if (profile && !isForensicIntakeComplete(profile)) {
    return <ForensicIntakeGuard inspectionId={id} />;
  }

  const openModal = () => {
    setPendingElevation(null);
    setPendingLabel("");
    setModalVisible(true);
  };

  const handleElevationSelect = (e: SidingElevation) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setPendingElevation(e);
    if (!pendingLabel || ELEVATIONS.some((opt) => opt.label === pendingLabel)) {
      setPendingLabel(ELEVATION_LABELS[e]);
    }
  };

  const handleAdd = () => {
    if (!pendingElevation || !pendingLabel.trim()) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    addElevation(id, { elevation: pendingElevation, label: pendingLabel.trim() });
    setModalVisible(false);
  };

  const handleDelete = (entry: SidingElevationEntry) => {
    Alert.alert(
      "Delete Elevation",
      `Delete "${entry.label}" and all its damage instances?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            deleteElevation(id, entry.id);
          },
        },
      ],
    );
  };

  const handleOpen = (entry: SidingElevationEntry) => {
    router.push({
      pathname: "/inspection/siding-damages",
      params: { id, elevationId: entry.id, elevationLabel: entry.label },
    });
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={elevations}
        keyExtractor={(e) => e.id}
        contentContainerStyle={[
          styles.listContent,
          elevations.length === 0 && styles.listEmpty,
        ]}
        ListEmptyComponent={
          <View style={styles.emptyWrap}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="grid" size={40} color={colors.mutedForeground} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              No elevations documented yet
            </Text>
            <Text style={[styles.emptySubtitle, { color: colors.mutedForeground }]}>
              Tap "+ Add Elevation" to start documenting each siding face individually.
            </Text>
          </View>
        }
        renderItem={({ item: entry }) => {
          const total = entry.damageInstances.length;
          const complete = entry.damageInstances.filter((d) => d.isComplete).length;
          const icon = ELEVATION_ICONS[entry.elevation] ?? "grid";
          const allComplete = total > 0 && complete === total;

          return (
            <TouchableOpacity
              onPress={() => handleOpen(entry)}
              activeOpacity={0.85}
              style={[
                styles.elevationCard,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <View style={[styles.elevationIcon, { backgroundColor: colors.secondary }]}>
                <Feather name={icon as any} size={22} color={colors.accent} />
              </View>

              <View style={styles.elevationBody}>
                <Text style={[styles.elevationLabel, { color: colors.foreground }]}>
                  {entry.label}
                </Text>
                <Text style={[styles.elevationMeta, { color: colors.mutedForeground }]}>
                  {total === 0
                    ? "No damage documented"
                    : `${complete}/${total} instances complete`}
                </Text>
              </View>

              <View style={styles.elevationRight}>
                {allComplete && (
                  <Feather name="check-circle" size={18} color={colors.success} />
                )}
                {total > 0 && !allComplete && (
                  <View style={[styles.countBadge, { backgroundColor: colors.accent }]}>
                    <Text style={styles.countBadgeText}>{total}</Text>
                  </View>
                )}
                <TouchableOpacity
                  onPress={() => handleDelete(entry)}
                  hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                >
                  <Feather name="trash-2" size={16} color={colors.destructive} />
                </TouchableOpacity>
                <Feather name="chevron-right" size={20} color={colors.mutedForeground} />
              </View>
            </TouchableOpacity>
          );
        }}
      />

      <View style={[styles.footer, { paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity
          onPress={openModal}
          activeOpacity={0.85}
          style={[styles.addButton, { backgroundColor: colors.accent, borderRadius: colors.radius }]}
        >
          <Feather name="plus" size={20} color="#FFFFFF" />
          <Text style={styles.addButtonText}>Add Elevation</Text>
        </TouchableOpacity>
      </View>

      {/* Add Elevation Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.modalSheet,
              { backgroundColor: colors.card, paddingBottom: bottomPad + 16 },
            ]}
          >
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>Add Elevation</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Feather name="x" size={22} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>

            <Text style={[styles.modalSectionLabel, { color: colors.mutedForeground }]}>
              Elevation Face
            </Text>
            <View style={styles.elevationGrid}>
              {ELEVATIONS.map((opt) => {
                const isSelected = pendingElevation === opt.value;
                return (
                  <TouchableOpacity
                    key={opt.value}
                    onPress={() => handleElevationSelect(opt.value)}
                    activeOpacity={0.8}
                    style={[
                      styles.elevationChip,
                      {
                        backgroundColor: isSelected ? colors.primary : colors.secondary,
                        borderColor: isSelected ? colors.primary : colors.border,
                        borderRadius: colors.radius / 2,
                      },
                    ]}
                  >
                    <Feather
                      name={opt.icon as any}
                      size={16}
                      color={isSelected ? "#FFFFFF" : colors.accent}
                    />
                    <Text
                      style={[
                        styles.elevationChipText,
                        { color: isSelected ? "#FFFFFF" : colors.foreground },
                      ]}
                    >
                      {opt.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            <Text style={[styles.modalSectionLabel, { color: colors.mutedForeground }]}>
              Label
            </Text>
            <TextInput
              value={pendingLabel}
              onChangeText={setPendingLabel}
              placeholder="e.g. Front, Back Left, Garage…"
              placeholderTextColor={colors.mutedForeground}
              style={[
                styles.labelInput,
                {
                  backgroundColor: colors.input,
                  color: colors.foreground,
                  borderColor: colors.border,
                  borderRadius: colors.radius / 2,
                },
              ]}
            />

            <TouchableOpacity
              onPress={handleAdd}
              disabled={!pendingElevation || !pendingLabel.trim()}
              activeOpacity={0.85}
              style={[
                styles.modalSave,
                {
                  backgroundColor:
                    pendingElevation && pendingLabel.trim() ? colors.accent : colors.muted,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <Text
                style={[
                  styles.modalSaveText,
                  {
                    color:
                      pendingElevation && pendingLabel.trim()
                        ? "#FFFFFF"
                        : colors.mutedForeground,
                  },
                ]}
              >
                Add Elevation
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  listContent: { padding: 16, gap: 12 },
  listEmpty: { flex: 1 },
  emptyWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 14,
    padding: 32,
  },
  emptyIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  emptySubtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
  elevationCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderWidth: 1,
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  elevationIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  elevationBody: { flex: 1, gap: 3 },
  elevationLabel: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  elevationMeta: { fontSize: 12, fontFamily: "Inter_400Regular" },
  elevationRight: { flexDirection: "row", alignItems: "center", gap: 10 },
  countBadge: {
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 6,
  },
  countBadgeText: { color: "#FFFFFF", fontSize: 11, fontFamily: "Inter_700Bold" },
  footer: { paddingHorizontal: 16, paddingTop: 8 },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 8,
  },
  addButtonText: { color: "#FFFFFF", fontSize: 16, fontFamily: "Inter_600SemiBold" },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  modalSheet: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    gap: 14,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  modalTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  modalSectionLabel: {
    fontSize: 12,
    fontFamily: "Inter_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  elevationGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  elevationChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingVertical: 9,
    paddingHorizontal: 14,
    borderWidth: 1,
  },
  elevationChipText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  labelInput: {
    height: 46,
    paddingHorizontal: 12,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
  },
  modalSave: {
    alignItems: "center",
    justifyContent: "center",
    padding: 15,
    marginTop: 4,
  },
  modalSaveText: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
});
