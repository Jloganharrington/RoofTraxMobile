import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useInspections } from "@/context/InspectionContext";
import { useSettings } from "@/context/SettingsContext";
import { useColors } from "@/hooks/useColors";
import { isEmailRelayConfigured, sendReportEmail, type SendReportPayload } from "@/utils/emailRelay";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function SendReportScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getProfile, updateProfile } = useInspections();
  const { settings } = useSettings();

  const profile = getProfile(id);

  const [email, setEmail] = useState(profile?.customerEmail ?? "");
  const [subject, setSubject] = useState(
    profile ? `Storm Damage Assessment Report — ${profile.address}` : "",
  );
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null);

  const messageBody = useMemo(() => {
    if (!profile) return "";
    const inspDate = new Date(profile.createdAt).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
    return (
      `Hello,\n\n` +
      `Please find attached the storm damage assessment report for the property at ` +
      `${profile.address}, inspected on ${inspDate}.\n\n` +
      `The report documents all observed storm-related damage, including photos, ` +
      `code citations, and repair estimates where applicable.\n\n` +
      `If you have any questions, feel free to reply to this email.\n\n` +
      `Best regards,\n${settings.userName}\n${settings.companyName}`
    );
  }, [profile, settings.userName, settings.companyName]);

  if (!profile) {
    return (
      <View style={[styles.centered, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground }}>Inspection not found</Text>
      </View>
    );
  }

  const emailValid = EMAIL_REGEX.test(email.trim());
  const hasReport = !!profile.reportUri;
  const canSend = emailValid && subject.trim().length > 0 && !sending;

  const handleConfirmSend = async () => {
    if (!canSend) return;
    setSending(true);
    setResult(null);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    // Persist the customer email on the profile for next time.
    updateProfile(id, { customerEmail: email.trim() });

    try {
      // Attach the generated PDF (base64) when available on a native platform.
      // Skip the (potentially large) file read entirely if the relay isn't
      // configured — sendReportEmail will short-circuit anyway.
      let attachment: SendReportPayload["attachment"] = null;
      if (isEmailRelayConfigured() && hasReport && Platform.OS !== "web" && profile.reportUri) {
        try {
          const FileSystem = require("expo-file-system");
          const base64 = await FileSystem.readAsStringAsync(profile.reportUri, {
            encoding: FileSystem.EncodingType.Base64,
          });
          attachment = { filename: "damage-assessment-report.pdf", base64 };
        } catch {
          attachment = null;
        }
      }

      const payload: SendReportPayload = {
        to: email.trim(),
        subject: subject.trim(),
        message: messageBody,
        attachment,
        meta: {
          inspectionId: profile.id,
          address: profile.address,
          sentAt: new Date().toISOString(),
        },
      };

      const res = await sendReportEmail(payload);
      if (res.ok) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setResult({ ok: true, message: `Report sent to ${email.trim()}` });
      } else {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        setResult({ ok: false, message: res.error ?? "Failed to send the report." });
      }
    } finally {
      setSending(false);
    }
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingBottom: bottomPad + 24 }]}
    >
      {/* Recipient */}
      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>RECIPIENT EMAIL</Text>
        <TextInput
          value={email}
          onChangeText={(t) => {
            setEmail(t);
            setResult(null);
          }}
          placeholder="customer@example.com"
          placeholderTextColor={colors.mutedForeground}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
          style={[
            styles.input,
            {
              backgroundColor: colors.card,
              borderColor: email.length > 0 && !emailValid ? "#EF4444" : colors.border,
              borderRadius: colors.radius,
              color: colors.foreground,
            },
          ]}
        />
        {email.length > 0 && !emailValid && (
          <Text style={styles.inputError}>Enter a valid email address</Text>
        )}
      </View>

      {/* Subject */}
      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>SUBJECT</Text>
        <TextInput
          value={subject}
          onChangeText={(t) => {
            setSubject(t);
            setResult(null);
          }}
          placeholder="Email subject"
          placeholderTextColor={colors.mutedForeground}
          style={[
            styles.input,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
              borderRadius: colors.radius,
              color: colors.foreground,
            },
          ]}
        />
      </View>

      {/* Preview */}
      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>MESSAGE PREVIEW</Text>
        <View
          style={[
            styles.previewCard,
            { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
          ]}
        >
          <Text style={[styles.previewText, { color: colors.foreground }]}>{messageBody}</Text>
        </View>
      </View>

      {/* Attachment */}
      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>ATTACHMENT</Text>
        <View
          style={[
            styles.attachmentCard,
            { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
          ]}
        >
          <View style={[styles.attachmentIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="file-text" size={20} color={hasReport ? colors.accent : colors.mutedForeground} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.attachmentTitle, { color: colors.foreground }]}>
              Damage Assessment Report (PDF)
            </Text>
            <Text style={[styles.attachmentSub, { color: colors.mutedForeground }]} numberOfLines={1}>
              {profile.address}
            </Text>
          </View>
          {hasReport ? (
            <Feather name="check-circle" size={18} color="#22C55E" />
          ) : (
            <Feather name="alert-circle" size={18} color="#F59E0B" />
          )}
        </View>
        {!hasReport && (
          <Text style={styles.attachmentWarning}>
            No generated PDF found — generate the report before sending so it can be attached.
          </Text>
        )}
      </View>

      {/* Result banner */}
      {result && (
        <View
          style={[
            styles.resultBanner,
            {
              backgroundColor: result.ok ? "#F0FDF4" : "#FFFBEB",
              borderRadius: colors.radius,
            },
          ]}
        >
          <Feather
            name={result.ok ? "check-circle" : "alert-triangle"}
            size={18}
            color={result.ok ? "#22C55E" : "#F59E0B"}
          />
          <Text
            style={[styles.resultText, { color: result.ok ? "#166534" : "#92400E" }]}
          >
            {result.message}
          </Text>
        </View>
      )}

      {/* Confirm & Send */}
      <View style={styles.confirmSection}>
        <View style={styles.confirmNoteRow}>
          <Feather name="info" size={13} color={colors.mutedForeground} />
          <Text style={[styles.confirmNote, { color: colors.mutedForeground }]}>
            Review the details above. Nothing is sent until you tap the button below.
          </Text>
        </View>
        <TouchableOpacity
          onPress={handleConfirmSend}
          disabled={!canSend}
          activeOpacity={0.85}
          style={[
            styles.sendButton,
            {
              backgroundColor: canSend ? colors.accent : colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          {sending ? (
            <ActivityIndicator color="#FFFFFF" size="small" />
          ) : (
            <Feather name="send" size={18} color={canSend ? "#FFFFFF" : colors.mutedForeground} />
          )}
          <Text
            style={[
              styles.sendButtonText,
              { color: canSend ? "#FFFFFF" : colors.mutedForeground },
            ]}
          >
            {sending ? "Sending…" : "Confirm & Send Report"}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => router.back()}
          activeOpacity={0.7}
          style={styles.cancelButton}
        >
          <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20, gap: 20 },
  centered: { flex: 1, alignItems: "center", justifyContent: "center" },
  fieldGroup: { gap: 8 },
  fieldLabel: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 1,
  },
  input: {
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  inputError: {
    fontSize: 12,
    color: "#EF4444",
    fontFamily: "Inter_400Regular",
  },
  previewCard: {
    borderWidth: 1,
    padding: 16,
  },
  previewText: {
    fontSize: 13,
    lineHeight: 20,
    fontFamily: "Inter_400Regular",
  },
  attachmentCard: {
    borderWidth: 1,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  attachmentIcon: {
    width: 42,
    height: 42,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  attachmentTitle: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  attachmentSub: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  attachmentWarning: {
    fontSize: 12,
    color: "#92400E",
    fontFamily: "Inter_400Regular",
    lineHeight: 17,
  },
  resultBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 14,
  },
  resultText: { fontSize: 13, fontFamily: "Inter_500Medium", flex: 1, lineHeight: 18 },
  confirmSection: { gap: 12, marginTop: 4 },
  confirmNoteRow: { flexDirection: "row", alignItems: "flex-start", gap: 6 },
  confirmNote: { fontSize: 12, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 17 },
  sendButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 17,
    gap: 10,
  },
  sendButtonText: { fontSize: 16, fontFamily: "Inter_700Bold" },
  cancelButton: { alignItems: "center", padding: 10 },
  cancelText: { fontSize: 14, fontFamily: "Inter_500Medium" },
});
