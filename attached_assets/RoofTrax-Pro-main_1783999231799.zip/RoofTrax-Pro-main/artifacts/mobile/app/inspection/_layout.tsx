import { Stack } from "expo-router";

export default function InspectionLayout() {
  return (
    <Stack
      screenOptions={{
        headerBackTitle: "Back",
        headerTintColor: "#F97316",
        headerStyle: { backgroundColor: "#FFFFFF" },
        headerTitleStyle: {
          fontFamily: "Inter_600SemiBold",
          fontSize: 17,
          color: "#1E3A5F",
        },
      }}
    >
      <Stack.Screen
        name="new"
        options={{
          title: "New Inspection",
          presentation: "modal",
        }}
      />
      <Stack.Screen name="[id]" options={{ title: "Inspection Profile" }} />
      <Stack.Screen name="front-photo" options={{ title: "Front of Home" }} />
      <Stack.Screen name="scope" options={{ title: "Damage Scope" }} />
      <Stack.Screen name="damage-type" options={{ title: "Damage Type" }} />
      <Stack.Screen name="access" options={{ title: "Access Method" }} />
      <Stack.Screen name="drone" options={{ title: "Upload Photos" }} />
      <Stack.Screen name="camera" options={{ headerShown: false }} />
      <Stack.Screen name="annotate" options={{ headerShown: false }} />
      <Stack.Screen name="report" options={{ title: "Generate Report" }} />
      <Stack.Screen name="customer-claim" options={{ title: "Customer & Claim" }} />
      <Stack.Screen name="slopes" options={{ title: "Roof Slopes" }} />
      <Stack.Screen name="slope-damages" options={{ title: "Damage Instances" }} />
      <Stack.Screen name="damage-form" options={{ title: "Document Damage" }} />
      <Stack.Screen name="photo-detail" options={{ title: "Photo Detail" }} />
      <Stack.Screen name="siding-elevations" options={{ title: "Siding Elevations" }} />
      <Stack.Screen name="siding-damages" options={{ title: "Damage Instances" }} />
      <Stack.Screen name="siding-damage-form" options={{ title: "Document Damage" }} />
      <Stack.Screen name="send-report" options={{ title: "Send to Customer" }} />
    </Stack>
  );
}
