import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useInspections, type DamageScope } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";

const SCOPE_OPTIONS: { value: DamageScope; label: string; description: string; icon: string }[] = [
  {
    value: "roof_only",
    label: "Roof Only",
    description: "Damage limited to roof structure and materials",
    icon: "triangle",
  },
  {
    value: "siding_only",
    label: "Siding Only",
    description: "Damage limited to exterior siding and cladding",
    icon: "layers",
  },
  {
    value: "roof_and_siding",
    label: "Roof & Siding",
    description: "Comprehensive damage to both roof and siding",
    icon: "home",
  },
];

export default function ScopeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { updateProfile } = useInspections();
  const [selected, setSelected] = useState<DamageScope | null>(null);

  const handleSelect = (value: DamageScope) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelected(value);
  };

  const handleNext = () => {
    if (!selected) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    updateProfile(id, { damageScope: selected });
    router.push({ pathname: "/inspection/damage-type", params: { id } });
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.inner}>
        <View style={styles.stepRow}>
          {[1, 2, 3, 4, 5].map((step, i) => (
            <View key={step}>
              <View
                style={[
                  styles.stepDot,
                  {
                    backgroundColor: i === 1 ? colors.accent : i < 1 ? colors.success : colors.muted,
                    width: i === 1 ? 24 : 8,
                    borderRadius: i === 1 ? 12 : 4,
                  },
                ]}
              />
            </View>
          ))}
        </View>

        <Text style={[styles.title, { color: colors.foreground }]}>Damage Scope</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Select the type of storm damage observed at this property.
        </Text>

        <View style={styles.optionList}>
          {SCOPE_OPTIONS.map((option) => {
            const isSelected = selected === option.value;
            return (
              <TouchableOpacity
                key={option.value}
                onPress={() => handleSelect(option.value)}
                activeOpacity={0.85}
                style={[
                  styles.optionCard,
                  {
                    backgroundColor: isSelected ? colors.primary : colors.card,
                    borderColor: isSelected ? colors.primary : colors.border,
                    borderRadius: colors.radius,
                  },
                ]}
              >
                <View
                  style={[
                    styles.optionIcon,
                    {
                      backgroundColor: isSelected ? "rgba(255,255,255,0.15)" : colors.secondary,
                    },
                  ]}
                >
                  <Feather
                    name={option.icon as any}
                    size={22}
                    color={isSelected ? "#FFFFFF" : colors.accent}
                  />
                </View>
                <View style={styles.optionText}>
                  <Text
                    style={[
                      styles.optionLabel,
                      { color: isSelected ? "#FFFFFF" : colors.foreground },
                    ]}
                  >
                    {option.label}
                  </Text>
                  <Text
                    style={[
                      styles.optionDesc,
                      {
                        color: isSelected ? "rgba(255,255,255,0.75)" : colors.mutedForeground,
                      },
                    ]}
                  >
                    {option.description}
                  </Text>
                </View>
                {isSelected && (
                  <Feather name="check-circle" size={22} color="#FFFFFF" />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      <View style={[styles.footer, { paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity
          onPress={handleNext}
          disabled={!selected}
          activeOpacity={0.85}
          style={[
            styles.nextButton,
            {
              backgroundColor: selected ? colors.accent : colors.muted,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Text
            style={[
              styles.nextButtonText,
              { color: selected ? "#FFFFFF" : colors.mutedForeground },
            ]}
          >
            Next
          </Text>
          <Feather
            name="arrow-right"
            size={20}
            color={selected ? "#FFFFFF" : colors.mutedForeground}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  inner: { flex: 1, paddingHorizontal: 24, paddingTop: 24, gap: 16 },
  stepRow: { flexDirection: "row", gap: 6, alignItems: "center", marginBottom: 8 },
  stepDot: { height: 8 },
  title: { fontSize: 26, fontFamily: "Inter_700Bold" },
  subtitle: { fontSize: 15, fontFamily: "Inter_400Regular", lineHeight: 22 },
  optionList: { gap: 12 },
  optionCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderWidth: 2,
    gap: 14,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  optionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  optionText: { flex: 1, gap: 4 },
  optionLabel: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
  optionDesc: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 18 },
  footer: { paddingHorizontal: 24, paddingTop: 12 },
  nextButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 10,
  },
  nextButtonText: { fontSize: 17, fontFamily: "Inter_600SemiBold" },
});
