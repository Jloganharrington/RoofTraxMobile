import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useRef, useState } from "react";
import {
  Image,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useInspections } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";
import {
  copyAllToDocumentsDetailed,
  copyToDocumentsDetailed,
  warnCopyFailures,
} from "@/utils/photos";

type CameraMode = "camera" | "preview";

export default function DirectCameraScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { updateProfile } = useInspections();
  const [mode, setMode] = useState<CameraMode>("camera");
  const [capturedUri, setCapturedUri] = useState<string | null>(null);
  const [sessionPhotos, setSessionPhotos] = useState<string[]>([]);

  if (Platform.OS === "web") {
    return (
      <WebCameraFallback
        colors={colors}
        insets={insets}
        id={id}
        sessionPhotos={sessionPhotos}
        setSessionPhotos={setSessionPhotos}
        updateProfile={updateProfile}
      />
    );
  }

  return (
    <NativeCameraView
      colors={colors}
      insets={insets}
      id={id}
      mode={mode}
      setMode={setMode}
      capturedUri={capturedUri}
      setCapturedUri={setCapturedUri}
      sessionPhotos={sessionPhotos}
      setSessionPhotos={setSessionPhotos}
      updateProfile={updateProfile}
    />
  );
}

function NativeCameraView({
  colors,
  insets,
  id,
  mode,
  setMode,
  capturedUri,
  setCapturedUri,
  sessionPhotos,
  setSessionPhotos,
  updateProfile,
}: any) {
  const { CameraView, useCameraPermissions } = require("expo-camera");
  const cameraRef = useRef<any>(null);
  const [permission, requestPermission] = useCameraPermissions();

  const handleCapture = async () => {
    if (!cameraRef.current) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    const photo = await cameraRef.current.takePictureAsync({ quality: 0.85 });
    if (photo?.uri) {
      setCapturedUri(photo.uri);
      setMode("preview");
    }
  };

  const handleRetake = () => {
    setCapturedUri(null);
    setMode("camera");
  };

  const handleUse = async () => {
    if (capturedUri) {
      const { uri: permanent, ok } = await copyToDocumentsDetailed(capturedUri);
      warnCopyFailures(ok ? 0 : 1);
      setSessionPhotos((prev: string[]) => [...prev, permanent]);
      setCapturedUri(null);
      setMode("camera");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleAnnotate = () => {
    if (capturedUri) {
      router.push({
        pathname: "/inspection/annotate" as any,
        params: { id, photoUri: encodeURIComponent(capturedUri) },
      });
    }
  };

  const handleFinished = async () => {
    const allPhotos = capturedUri
      ? [...sessionPhotos, capturedUri]
      : sessionPhotos;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const { uris: permanentPhotos, failedCount } = await copyAllToDocumentsDetailed(allPhotos);
    warnCopyFailures(failedCount);
    updateProfile(id, { damagePhotos: permanentPhotos });
    router.push({ pathname: "/inspection/report", params: { id } });
  };

  if (!permission) {
    return (
      <View style={[styles.centered, { backgroundColor: "#000" }]}>
        <Text style={styles.permissionText}>Loading camera...</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={[styles.centered, { backgroundColor: colors.background }]}>
        <Feather name="camera-off" size={48} color={colors.mutedForeground} />
        <Text style={[styles.permissionTitle, { color: colors.foreground }]}>Camera Access Required</Text>
        <Text style={[styles.permissionSubtitle, { color: colors.mutedForeground }]}>
          Allow camera access to capture inspection photos.
        </Text>
        <TouchableOpacity
          onPress={requestPermission}
          style={[styles.permissionButton, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
        >
          <Text style={{ color: "#FFFFFF", fontFamily: "Inter_600SemiBold", fontSize: 16 }}>
            Allow Camera
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.cameraContainer}>
      {mode === "camera" ? (
        <>
          <CameraView ref={cameraRef} style={StyleSheet.absoluteFill} facing="back" />

          {/* Top overlay */}
          <View style={[styles.topOverlay, { paddingTop: insets.top + 12 }]}>
            <TouchableOpacity
              onPress={() => router.back()}
              style={styles.overlayBtn}
            >
              <Feather name="x" size={24} color="#FFFFFF" />
            </TouchableOpacity>
            <View style={[styles.photoCountPill, { opacity: sessionPhotos.length > 0 ? 1 : 0 }]}>
              <Feather name="image" size={14} color="#FFFFFF" />
              <Text style={styles.photoCountText}>{sessionPhotos.length} saved</Text>
            </View>
            {sessionPhotos.length > 0 && (
              <TouchableOpacity
                onPress={handleFinished}
                style={[styles.doneBtn, { backgroundColor: colors.accent }]}
              >
                <Text style={styles.doneBtnText}>Done</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Bottom overlay */}
          <View style={[styles.bottomOverlay, { paddingBottom: insets.bottom + 20 }]}>
            <Text style={styles.instructionText}>
              {sessionPhotos.length === 0
                ? "Capture damage photos"
                : `${sessionPhotos.length} photo${sessionPhotos.length > 1 ? "s" : ""} saved — keep shooting`}
            </Text>
            <View style={styles.shutterRow}>
              <View style={{ width: 50 }} />
              <TouchableOpacity onPress={handleCapture} style={styles.shutterButton} activeOpacity={0.85}>
                <View style={styles.shutterInner} />
              </TouchableOpacity>
              <View style={{ width: 50 }} />
            </View>
          </View>
        </>
      ) : (
        <>
          {capturedUri && (
            <Image source={{ uri: capturedUri }} style={StyleSheet.absoluteFill} resizeMode="cover" />
          )}

          {/* Preview overlay */}
          <View style={[styles.previewOverlay, { paddingBottom: insets.bottom + 24 }]}>
            <View style={[styles.previewTopBar, { paddingTop: insets.top + 12 }]}>
              <Text style={styles.previewTitle}>Review Photo</Text>
            </View>

            <View style={styles.previewActions}>
              <TouchableOpacity
                onPress={handleRetake}
                style={[styles.previewBtn, { backgroundColor: "rgba(255,255,255,0.2)" }]}
                activeOpacity={0.8}
              >
                <Feather name="refresh-cw" size={20} color="#FFFFFF" />
                <Text style={styles.previewBtnText}>Retake</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleAnnotate}
                style={[styles.previewBtn, { backgroundColor: "rgba(255,255,255,0.2)" }]}
                activeOpacity={0.8}
              >
                <Feather name="edit-3" size={20} color="#FFFFFF" />
                <Text style={styles.previewBtnText}>Annotate</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleUse}
                style={[styles.previewBtn, { backgroundColor: colors.accent }]}
                activeOpacity={0.8}
              >
                <Feather name="check" size={20} color="#FFFFFF" />
                <Text style={styles.previewBtnText}>Use</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleFinished}
                style={[styles.previewBtn, { backgroundColor: colors.success }]}
                activeOpacity={0.8}
              >
                <Feather name="flag" size={20} color="#FFFFFF" />
                <Text style={styles.previewBtnText}>Finished</Text>
              </TouchableOpacity>
            </View>
          </View>
        </>
      )}
    </View>
  );
}

function WebCameraFallback({ colors, insets, id, sessionPhotos, setSessionPhotos, updateProfile }: any) {
  const ImagePicker = require("expo-image-picker");

  const handleCapture = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsMultipleSelection: true,
      quality: 0.85,
    });
    if (!result.canceled) {
      const uris = result.assets.map((a: any) => a.uri);
      setSessionPhotos((prev: string[]) => [...prev, ...uris]);
    }
  };

  const handleFinished = () => {
    updateProfile(id, { damagePhotos: sessionPhotos });
    router.push({ pathname: "/inspection/report", params: { id } });
  };

  const bottomPad = 34;

  return (
    <View style={[styles.centered, { backgroundColor: colors.background, padding: 24 }]}>
      <Feather name="camera" size={48} color={colors.accent} />
      <Text style={[styles.permissionTitle, { color: colors.foreground }]}>Direct-Access Camera</Text>
      <Text style={[styles.permissionSubtitle, { color: colors.mutedForeground, textAlign: "center" }]}>
        Camera access is available on native devices. Add photos from your library.
      </Text>
      {sessionPhotos.length > 0 && (
        <View style={[styles.photoCountPill, { backgroundColor: colors.accent, opacity: 1 }]}>
          <Text style={styles.photoCountText}>{sessionPhotos.length} photo{sessionPhotos.length !== 1 ? "s" : ""} added</Text>
        </View>
      )}
      <TouchableOpacity
        onPress={handleCapture}
        style={[styles.permissionButton, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
      >
        <Text style={{ color: "#FFFFFF", fontFamily: "Inter_600SemiBold", fontSize: 16 }}>
          Add Photos
        </Text>
      </TouchableOpacity>
      {sessionPhotos.length > 0 && (
        <TouchableOpacity
          onPress={handleFinished}
          style={[styles.permissionButton, { backgroundColor: colors.accent, borderRadius: colors.radius }]}
        >
          <Text style={{ color: "#FFFFFF", fontFamily: "Inter_600SemiBold", fontSize: 16 }}>
            Proceed to Report
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  cameraContainer: { flex: 1, backgroundColor: "#000" },
  centered: { flex: 1, alignItems: "center", justifyContent: "center", gap: 16, padding: 24 },
  permissionText: { color: "#FFFFFF", fontSize: 16, fontFamily: "Inter_400Regular" },
  permissionTitle: { fontSize: 22, fontFamily: "Inter_700Bold", textAlign: "center" },
  permissionSubtitle: { fontSize: 15, fontFamily: "Inter_400Regular", lineHeight: 22, textAlign: "center" },
  permissionButton: {
    paddingHorizontal: 32,
    paddingVertical: 14,
    alignItems: "center",
    marginTop: 8,
    width: "100%",
  },
  topOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    gap: 12,
  },
  overlayBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(0,0,0,0.5)",
    alignItems: "center",
    justifyContent: "center",
  },
  photoCountPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: "rgba(0,0,0,0.5)",
  },
  photoCountText: { color: "#FFFFFF", fontSize: 13, fontFamily: "Inter_600SemiBold" },
  doneBtn: {
    marginLeft: "auto",
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
  },
  doneBtnText: { color: "#FFFFFF", fontSize: 15, fontFamily: "Inter_700Bold" },
  bottomOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: "center",
    gap: 24,
    paddingTop: 24,
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  instructionText: {
    color: "rgba(255,255,255,0.85)",
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
  shutterRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    paddingHorizontal: 50,
  },
  shutterButton: {
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: "rgba(255,255,255,0.25)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: "#FFFFFF",
  },
  shutterInner: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: "#FFFFFF",
  },
  previewOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: "space-between",
  },
  previewTopBar: {
    paddingHorizontal: 20,
    alignItems: "center",
  },
  previewTitle: {
    color: "#FFFFFF",
    fontSize: 17,
    fontFamily: "Inter_600SemiBold",
    textShadowColor: "rgba(0,0,0,0.8)",
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  previewActions: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 16,
    paddingHorizontal: 24,
  },
  previewBtn: {
    flex: 1,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 8,
    borderRadius: 16,
  },
  previewBtnText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
});
