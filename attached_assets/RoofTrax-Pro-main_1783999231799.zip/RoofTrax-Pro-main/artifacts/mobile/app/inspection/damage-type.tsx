import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useInspections, type DamageType } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";

const DAMAGE_TYPE_OPTIONS: {
  value: DamageType;
  label: string;
  description: string;
  icon: string;
}[] = [
  {
    value: "wind",
    label: "Wind",
    description: "Shingle lift, blow-off, or structural wind damage",
    icon: "wind",
  },
  {
    value: "wind_hail",
    label: "Wind & Hail",
    description: "Combined wind and hail impact observed",
    icon: "cloud-rain",
  },
  {
    value: "hail",
    label: "Hail",
    description: "Granule loss, dents, or bruising from hailstones",
    icon: "cloud-snow",
  },
  {
    value: "tree",
    label: "Tree Impact",
    description: "Damage from a fallen tree or impacting branches",
    icon: "git-merge",
  },
  {
    value: "water_ice",
    label: "Water/Ice Damming",
    description: "Interior leaks or damage from ice dams or water infiltration",
    icon: "droplet",
  },
];

export default function DamageTypeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { updateProfile } = useInspections();
  const [selected, setSelected] = useState<DamageType | null>(null);

  const handleSelect = (value: DamageType) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelected(value);
  };

  const handleNext = () => {
    if (!selected) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    updateProfile(id, { damageType: selected });
    router.push({ pathname: "/inspection/access", params: { id } });
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.inner}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.stepRow}>
          {[1, 2, 3, 4, 5].map((step, i) => (
            <View key={step}>
              <View
                style={[
                  styles.stepDot,
                  {
                    backgroundColor:
                      i === 2
                        ? colors.accent
                        : i < 2
                          ? colors.success
                          : colors.muted,
                    width: i === 2 ? 24 : 8,
                    borderRadius: i === 2 ? 12 : 4,
                  },
                ]}
              />
            </View>
          ))}
        </View>

        <Text style={[styles.title, { color: colors.foreground }]}>
          Damage Type
        </Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Select the primary type of storm damage observed. This focuses the
          weather history analysis on the right events.
        </Text>

        <View style={styles.optionList}>
          {DAMAGE_TYPE_OPTIONS.map((option) => {
            const isSelected = selected === option.value;
            return (
              <TouchableOpacity
                key={option.value}
                onPress={() => handleSelect(option.value)}
                activeOpacity={0.85}
                style={[
                  styles.optionCard,
                  {
                    backgroundColor: isSelected ? colors.primary : colors.card,
                    borderColor: isSelected ? colors.primary : colors.border,
                    borderRadius: colors.radius,
                  },
                ]}
              >
                <View
                  style={[
                    styles.optionIcon,
                    {
                      backgroundColor: isSelected
                        ? "rgba(255,255,255,0.15)"
                        : colors.secondary,
                    },
                  ]}
                >
                  <Feather
                    name={option.icon as any}
                    size={22}
                    color={isSelected ? "#FFFFFF" : colors.accent}
                  />
                </View>
                <View style={styles.optionText}>
                  <Text
                    style={[
                      styles.optionLabel,
                      { color: isSelected ? "#FFFFFF" : colors.foreground },
                    ]}
                  >
                    {option.label}
                  </Text>
                  <Text
                    style={[
                      styles.optionDesc,
                      {
                        color: isSelected
                          ? "rgba(255,255,255,0.75)"
                          : colors.mutedForeground,
                      },
                    ]}
                  >
                    {option.description}
                  </Text>
                </View>
                {isSelected && (
                  <Feather name="check-circle" size={22} color="#FFFFFF" />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity
          onPress={handleNext}
          disabled={!selected}
          activeOpacity={0.85}
          style={[
            styles.nextButton,
            {
              backgroundColor: selected ? colors.accent : colors.muted,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Text
            style={[
              styles.nextButtonText,
              { color: selected ? "#FFFFFF" : colors.mutedForeground },
            ]}
          >
            Next
          </Text>
          <Feather
            name="arrow-right"
            size={20}
            color={selected ? "#FFFFFF" : colors.mutedForeground}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flex: 1 },
  inner: { paddingHorizontal: 24, paddingTop: 24, paddingBottom: 8, gap: 16 },
  stepRow: {
    flexDirection: "row",
    gap: 6,
    alignItems: "center",
    marginBottom: 8,
  },
  stepDot: { height: 8 },
  title: { fontSize: 26, fontFamily: "Inter_700Bold" },
  subtitle: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    lineHeight: 22,
  },
  optionList: { gap: 10 },
  optionCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderWidth: 2,
    gap: 14,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  optionIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  optionText: { flex: 1, gap: 3 },
  optionLabel: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  optionDesc: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    lineHeight: 17,
  },
  footer: { paddingHorizontal: 24, paddingTop: 12 },
  nextButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 10,
  },
  nextButtonText: { fontSize: 17, fontFamily: "Inter_600SemiBold" },
});
