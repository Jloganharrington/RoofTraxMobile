import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Image,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useInspections } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";
import { copyAllToDocumentsDetailed, warnCopyFailures } from "@/utils/photos";

export default function DroneUploadScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { updateProfile, getProfile } = useInspections();
  const profile = getProfile(id);
  const [photos, setPhotos] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const isTablet = width >= 768;
  const numColumns = isTablet ? 4 : 3;
  const photoSize = (width - 48 - (numColumns - 1) * 8) / numColumns;

  const handleBulkUpload = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission Required", "Please allow access to your photo library.");
      return;
    }
    setLoading(true);
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsMultipleSelection: true,
      quality: 0.85,
      orderedSelection: true,
    });
    setLoading(false);
    if (!result.canceled && result.assets.length > 0) {
      const uris = result.assets.map((a) => a.uri);
      setPhotos((prev) => [...prev, ...uris]);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleRemovePhoto = (uri: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setPhotos((prev) => prev.filter((p) => p !== uri));
  };

  const handleProceed = async () => {
    if (photos.length === 0) return;
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const { uris: permanentPhotos, failedCount } = await copyAllToDocumentsDetailed(photos);
    warnCopyFailures(failedCount);
    updateProfile(id, { damagePhotos: permanentPhotos });
    router.push({ pathname: "/inspection/report", params: { id } });
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.inner}>
        <View style={styles.stepRow}>
          {[1, 2, 3, 4].map((step, i) => (
            <View key={step}>
              <View
                style={[
                  styles.stepDot,
                  {
                    backgroundColor: i === 3 ? colors.accent : colors.success,
                    width: i === 3 ? 24 : 8,
                    borderRadius: i === 3 ? 12 : 4,
                  },
                ]}
              />
            </View>
          ))}
        </View>

        <View style={styles.headerRow}>
          <View>
            <Text style={[styles.title, { color: colors.foreground }]}>Drone Photos</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Bulk upload all aerial damage documentation photos.
            </Text>
          </View>
          {photos.length > 0 && (
            <View style={[styles.countBadge, { backgroundColor: colors.accent }]}>
              <Text style={styles.countText}>{photos.length}</Text>
            </View>
          )}
        </View>

        <TouchableOpacity
          onPress={handleBulkUpload}
          activeOpacity={0.85}
          disabled={loading}
          style={[
            styles.uploadButton,
            { backgroundColor: colors.primary, borderRadius: colors.radius, opacity: loading ? 0.7 : 1 },
          ]}
        >
          <Feather name="upload-cloud" size={22} color="#FFFFFF" />
          <Text style={[styles.uploadButtonText, { color: "#FFFFFF" }]}>
            {loading ? "Selecting..." : photos.length > 0 ? "Add More Photos" : "Select Drone Photos"}
          </Text>
        </TouchableOpacity>

        {photos.length === 0 ? (
          <View
            style={[
              styles.emptyState,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                borderRadius: colors.radius,
              },
            ]}
          >
            <Feather name="image" size={48} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No Photos Selected</Text>
            <Text style={[styles.emptySubtitle, { color: colors.mutedForeground }]}>
              Tap the button above to select all your drone damage photos at once.
            </Text>
          </View>
        ) : (
          <FlatList
            data={photos}
            keyExtractor={(uri, i) => `${uri}-${i}`}
            numColumns={numColumns}
            scrollEnabled={!!photos.length}
            contentContainerStyle={{ gap: 8, paddingBottom: 8 }}
            columnWrapperStyle={{ gap: 8 }}
            renderItem={({ item }) => {
              const hasAnnotations = (profile?.photoAnnotations?.[item]?.length ?? 0) > 0;
              return (
                <View style={{ position: "relative" }}>
                  <Image
                    source={{ uri: item }}
                    style={[
                      styles.photoThumb,
                      { width: photoSize, height: photoSize, borderRadius: colors.radius / 2 },
                    ]}
                    resizeMode="cover"
                  />
                  <TouchableOpacity
                    onPress={() => handleRemovePhoto(item)}
                    style={styles.removeBtn}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <Feather name="x" size={12} color="#FFFFFF" />
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() =>
                      router.push({
                        pathname: "/inspection/annotate" as any,
                        params: { id, photoUri: encodeURIComponent(item) },
                      })
                    }
                    style={[styles.annotateBtn, hasAnnotations && { backgroundColor: "#F97316" }]}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <Feather
                      name={hasAnnotations ? "check" : "edit-3"}
                      size={11}
                      color="#FFFFFF"
                    />
                  </TouchableOpacity>
                </View>
              );
            }}
          />
        )}
      </View>

      <View style={[styles.footer, { paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity
          onPress={handleProceed}
          disabled={photos.length === 0}
          activeOpacity={0.85}
          style={[
            styles.nextButton,
            {
              backgroundColor: photos.length > 0 ? colors.accent : colors.muted,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Text
            style={[
              styles.nextButtonText,
              { color: photos.length > 0 ? "#FFFFFF" : colors.mutedForeground },
            ]}
          >
            Generate Report
          </Text>
          <Feather
            name="file-text"
            size={20}
            color={photos.length > 0 ? "#FFFFFF" : colors.mutedForeground}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  inner: { flex: 1, paddingHorizontal: 24, paddingTop: 24, gap: 16 },
  stepRow: { flexDirection: "row", gap: 6, alignItems: "center", marginBottom: 4 },
  stepDot: { height: 8 },
  headerRow: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" },
  title: { fontSize: 26, fontFamily: "Inter_700Bold" },
  subtitle: { fontSize: 15, fontFamily: "Inter_400Regular", lineHeight: 22, marginTop: 4 },
  countBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  countText: { color: "#FFFFFF", fontSize: 18, fontFamily: "Inter_700Bold" },
  uploadButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 10,
  },
  uploadButtonText: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
  emptyState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderStyle: "dashed",
    gap: 12,
    padding: 32,
  },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold" },
  emptySubtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
  photoThumb: {},
  removeBtn: {
    position: "absolute",
    top: 4,
    right: 4,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: "rgba(0,0,0,0.65)",
    alignItems: "center",
    justifyContent: "center",
  },
  annotateBtn: {
    position: "absolute",
    bottom: 4,
    right: 4,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: "rgba(0,0,0,0.65)",
    alignItems: "center",
    justifyContent: "center",
  },
  footer: { paddingHorizontal: 24, paddingTop: 12 },
  nextButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 10,
  },
  nextButtonText: { fontSize: 17, fontFamily: "Inter_600SemiBold" },
});
