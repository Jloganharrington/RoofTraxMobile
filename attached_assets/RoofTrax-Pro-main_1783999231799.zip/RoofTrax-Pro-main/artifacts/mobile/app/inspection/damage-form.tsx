import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { router, useLocalSearchParams } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Alert,
  FlatList,
  Image,
  Modal,
  Platform,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ForensicIntakeGuard } from "@/components/ForensicIntakeGuard";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import {
  isForensicIntakeComplete,
  REQUIRED_PHOTOS_PER_DAMAGE,
  useInspections,
  type DeckingCondition,
  type DamageSeverity,
  type InstanceDamageType,
} from "@/context/InspectionContext";
import { CODE_CITATIONS } from "@/constants/codeCitations";
import { useColors } from "@/hooks/useColors";
import { copyAllToDocumentsDetailed, warnCopyFailures } from "@/utils/photos";

// ---------------------------------------------------------------------------
// Option maps
// ---------------------------------------------------------------------------
const DAMAGE_TYPE_OPTIONS: { value: InstanceDamageType; label: string; icon: string }[] = [
  { value: "hail", label: "Hail", icon: "cloud-snow" },
  { value: "wind", label: "Wind", icon: "wind" },
  { value: "wind_hail", label: "Wind & Hail", icon: "cloud-rain" },
  { value: "tree", label: "Tree Impact", icon: "git-merge" },
  { value: "water_ice", label: "Water/Ice", icon: "droplet" },
  { value: "other", label: "Other", icon: "alert-circle" },
];

const SEVERITY_OPTIONS: { value: DamageSeverity; label: string; color: string }[] = [
  { value: "minor", label: "Minor", color: "#3B82F6" },
  { value: "moderate", label: "Moderate", color: "#F97316" },
  { value: "severe", label: "Severe", color: "#EF4444" },
];

const DECKING_OPTIONS: { value: DeckingCondition; label: string; icon: string }[] = [
  { value: "solid", label: "Solid", icon: "check-circle" },
  { value: "soft_spots", label: "Soft Spots", icon: "alert-triangle" },
  { value: "rot", label: "Rot", icon: "x-circle" },
  { value: "delamination", label: "Delamination", icon: "layers" },
];

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
export default function DamageFormScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { id, slopeId, damageId } = useLocalSearchParams<{
    id: string;
    slopeId: string;
    damageId?: string;
  }>();
  const { getProfile, addDamageInstance, updateDamageInstance } = useInspections();

  const isEdit = !!damageId;

  // ---- Form state ----------------------------------------------------------
  const [damageType, setDamageType] = useState<InstanceDamageType | null>(null);
  const [severity, setSeverity] = useState<DamageSeverity | null>(null);
  const [photos, setPhotos] = useState<string[]>([]);
  const [causationNote, setCausationNote] = useState("");
  const [deckingCondition, setDeckingCondition] = useState<DeckingCondition | null>(null);
  const [discontinuedProduct, setDiscontinuedProduct] = useState(false);
  const [discontinuedProductNote, setDiscontinuedProductNote] = useState("");
  const [selectedCitations, setSelectedCitations] = useState<string[]>([]);
  const [citationModalVisible, setCitationModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);

  const loadedRef = useRef(false);

  // Load existing data when editing
  useEffect(() => {
    if (!isEdit || !damageId || loadedRef.current) return;
    loadedRef.current = true;
    const profile = getProfile(id);
    const slope = profile?.slopes?.find((s) => s.id === slopeId);
    const instance = slope?.damageInstances.find((d) => d.id === damageId);
    if (!instance) return;
    setDamageType(instance.damageType);
    setSeverity(instance.severity);
    setPhotos(instance.photos);
    setCausationNote(instance.causationNote);
    setDeckingCondition(instance.deckingCondition);
    setDiscontinuedProduct(instance.discontinuedProduct);
    setDiscontinuedProductNote(instance.discontinuedProductNote);
    setSelectedCitations(instance.codeCitationIds);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Phase 2 gate — customer profile & claim details must be complete first.
  const gateProfile = getProfile(id);
  if (gateProfile && !isForensicIntakeComplete(gateProfile)) {
    return <ForensicIntakeGuard inspectionId={id} />;
  }

  // ---- Photo picker --------------------------------------------------------
  const handleAddPhotos = () => {
    Alert.alert("Add Photos", "Choose source", [
      { text: "Camera", onPress: launchCamera },
      { text: "Photo Library", onPress: launchLibrary },
      { text: "Cancel", style: "cancel" },
    ]);
  };

  const launchCamera = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission Required", "Please allow camera access to take photos.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.85 });
    if (!result.canceled && result.assets.length > 0) {
      // Copy to permanent storage immediately so the photo survives an
      // app crash/force-close before the form is saved.
      const { uris, failedCount } = await copyAllToDocumentsDetailed([result.assets[0].uri]);
      setPhotos((prev) => [...prev, ...uris]);
      warnCopyFailures(failedCount);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const launchLibrary = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission Required", "Please allow photo library access.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsMultipleSelection: true,
      quality: 0.85,
    });
    if (!result.canceled && result.assets.length > 0) {
      // Copy to permanent storage immediately so photos survive an
      // app crash/force-close before the form is saved.
      const { uris, failedCount } = await copyAllToDocumentsDetailed(
        result.assets.map((a) => a.uri),
      );
      setPhotos((prev) => [...prev, ...uris]);
      warnCopyFailures(failedCount);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleRemovePhoto = (uri: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setPhotos((prev) => prev.filter((p) => p !== uri));
  };

  // ---- Citation picker -----------------------------------------------------
  const toggleCitation = (cid: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedCitations((prev) =>
      prev.includes(cid) ? prev.filter((c) => c !== cid) : [...prev, cid],
    );
  };

  // ---- Save ----------------------------------------------------------------
  const handleSave = async (markComplete: boolean) => {
    if (!damageType || !severity) {
      Alert.alert("Missing Fields", "Please select a damage type and severity before saving.");
      return;
    }

    if (markComplete && photos.length < REQUIRED_PHOTOS_PER_DAMAGE) {
      Alert.alert(
        "Photos Required",
        `At least ${REQUIRED_PHOTOS_PER_DAMAGE} photos are required to mark this instance complete. You have ${photos.length}.`,
      );
      return;
    }

    setSaving(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    // Safety net — photos are normally copied at capture/pick time, so this
    // is a cheap no-op for anything already in permanent storage.
    let permanentPhotos = photos;
    try {
      const { uris, failedCount } = await copyAllToDocumentsDetailed(photos);
      permanentPhotos = uris;
      warnCopyFailures(failedCount);
    } catch {
      // non-fatal — fall back to original URIs
    }

    const data = {
      damageType,
      severity,
      photos: permanentPhotos,
      causationNote: causationNote.trim(),
      deckingCondition,
      discontinuedProduct,
      discontinuedProductNote: discontinuedProduct ? discontinuedProductNote.trim() : "",
      codeCitationIds: selectedCitations,
      isComplete: markComplete,
    };

    if (isEdit && damageId) {
      updateDamageInstance(id, slopeId, damageId, data);
    } else {
      addDamageInstance(id, slopeId, data);
    }

    setSaving(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.back();
  };

  // ---- Derived state -------------------------------------------------------
  const canMarkComplete =
    damageType !== null &&
    severity !== null &&
    photos.length >= REQUIRED_PHOTOS_PER_DAMAGE;

  const photoColCount = Math.min(4, Math.floor(width / 90));
  const photoSize = (width - 32 - (photoColCount - 1) * 8) / photoColCount;

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  // ---- Render helpers ------------------------------------------------------
  function SectionHeader({ icon, label }: { icon: string; label: string }) {
    return (
      <View style={styles.sectionHeader}>
        <Feather name={icon as any} size={15} color={colors.accent} />
        <Text style={[styles.sectionLabel, { color: colors.foreground }]}>{label}</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[styles.scrollContent, { paddingBottom: 120 + bottomPad }]}
        showsVerticalScrollIndicator={false}
      >
        {/* ---- Damage Type ---- */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          <SectionHeader icon="alert-triangle" label="Damage Type" />
          <View style={styles.chipWrap}>
            {DAMAGE_TYPE_OPTIONS.map((opt) => {
              const isSelected = damageType === opt.value;
              return (
                <TouchableOpacity
                  key={opt.value}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setDamageType(opt.value);
                  }}
                  activeOpacity={0.8}
                  style={[
                    styles.chip,
                    {
                      backgroundColor: isSelected ? colors.primary : colors.secondary,
                      borderColor: isSelected ? colors.primary : colors.border,
                      borderRadius: colors.radius / 2,
                    },
                  ]}
                >
                  <Feather
                    name={opt.icon as any}
                    size={14}
                    color={isSelected ? "#FFFFFF" : colors.accent}
                  />
                  <Text
                    style={[
                      styles.chipText,
                      { color: isSelected ? "#FFFFFF" : colors.foreground },
                    ]}
                  >
                    {opt.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* ---- Severity ---- */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          <SectionHeader icon="bar-chart-2" label="Severity" />
          <View style={styles.chipWrap}>
            {SEVERITY_OPTIONS.map((opt) => {
              const isSelected = severity === opt.value;
              return (
                <TouchableOpacity
                  key={opt.value}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setSeverity(opt.value);
                  }}
                  activeOpacity={0.8}
                  style={[
                    styles.severityChip,
                    {
                      backgroundColor: isSelected ? opt.color : opt.color + "18",
                      borderColor: isSelected ? opt.color : opt.color + "44",
                      borderRadius: colors.radius / 2,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.chipText,
                      { color: isSelected ? "#FFFFFF" : opt.color },
                    ]}
                  >
                    {opt.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* ---- Photos ---- */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          <View style={styles.sectionHeaderRow}>
            <SectionHeader icon="camera" label="Photos" />
            <View
              style={[
                styles.photoCountBadge,
                {
                  backgroundColor:
                    photos.length >= REQUIRED_PHOTOS_PER_DAMAGE
                      ? colors.success + "22"
                      : colors.destructive + "22",
                },
              ]}
            >
              <Feather
                name={photos.length >= REQUIRED_PHOTOS_PER_DAMAGE ? "check" : "alert-circle"}
                size={12}
                color={
                  photos.length >= REQUIRED_PHOTOS_PER_DAMAGE ? colors.success : colors.destructive
                }
              />
              <Text
                style={[
                  styles.photoCountText,
                  {
                    color:
                      photos.length >= REQUIRED_PHOTOS_PER_DAMAGE
                        ? colors.success
                        : colors.destructive,
                  },
                ]}
              >
                {photos.length}/{REQUIRED_PHOTOS_PER_DAMAGE} required
              </Text>
            </View>
          </View>

          {photos.length > 0 && (
            <View style={styles.photoGrid}>
              {photos.map((uri, i) => (
                <View key={`${uri}-${i}`} style={{ position: "relative" }}>
                  <TouchableOpacity
                    activeOpacity={0.85}
                    onPress={() =>
                      router.push({ pathname: "/inspection/photo-detail", params: { uri } })
                    }
                  >
                    <Image
                      source={{ uri }}
                      style={[
                        styles.photoThumb,
                        { width: photoSize, height: photoSize, borderRadius: colors.radius / 2 },
                      ]}
                      resizeMode="cover"
                    />
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => handleRemovePhoto(uri)}
                    style={styles.photoRemove}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <Feather name="x" size={10} color="#FFFFFF" />
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          )}

          <TouchableOpacity
            onPress={handleAddPhotos}
            activeOpacity={0.85}
            style={[
              styles.addPhotoButton,
              {
                borderColor: colors.accent,
                borderRadius: colors.radius / 2,
                backgroundColor: colors.secondary,
              },
            ]}
          >
            <Feather name="plus" size={16} color={colors.accent} />
            <Text style={[styles.addPhotoText, { color: colors.accent }]}>
              {photos.length === 0 ? "Add Photos" : "Add More Photos"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* ---- Causation Note ---- */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          <SectionHeader icon="file-text" label="Causation Note" />
          <TextInput
            value={causationNote}
            onChangeText={setCausationNote}
            placeholder="Describe the observable cause of this damage…"
            placeholderTextColor={colors.mutedForeground}
            multiline
            numberOfLines={4}
            textAlignVertical="top"
            style={[
              styles.textarea,
              {
                backgroundColor: colors.input,
                color: colors.foreground,
                borderColor: colors.border,
                borderRadius: colors.radius / 2,
              },
            ]}
          />
        </View>

        {/* ---- Decking Condition ---- */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          <SectionHeader icon="layers" label="Decking Condition" />
          <View style={styles.chipWrap}>
            {DECKING_OPTIONS.map((opt) => {
              const isSelected = deckingCondition === opt.value;
              return (
                <TouchableOpacity
                  key={opt.value}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setDeckingCondition(isSelected ? null : opt.value);
                  }}
                  activeOpacity={0.8}
                  style={[
                    styles.chip,
                    {
                      backgroundColor: isSelected ? colors.primary : colors.secondary,
                      borderColor: isSelected ? colors.primary : colors.border,
                      borderRadius: colors.radius / 2,
                    },
                  ]}
                >
                  <Feather
                    name={opt.icon as any}
                    size={14}
                    color={isSelected ? "#FFFFFF" : colors.accent}
                  />
                  <Text
                    style={[
                      styles.chipText,
                      { color: isSelected ? "#FFFFFF" : colors.foreground },
                    ]}
                  >
                    {opt.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* ---- Discontinued Product ---- */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          <View style={styles.switchRow}>
            <View style={styles.switchLabel}>
              <SectionHeader icon="package" label="Discontinued Product" />
              <Text style={[styles.switchSubtitle, { color: colors.mutedForeground }]}>
                Material or system no longer manufactured
              </Text>
            </View>
            <Switch
              value={discontinuedProduct}
              onValueChange={(v) => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setDiscontinuedProduct(v);
              }}
              trackColor={{ true: colors.accent, false: colors.muted }}
              thumbColor="#FFFFFF"
            />
          </View>
          {discontinuedProduct && (
            <TextInput
              value={discontinuedProductNote}
              onChangeText={setDiscontinuedProductNote}
              placeholder="Product name, manufacturer, or details…"
              placeholderTextColor={colors.mutedForeground}
              style={[
                styles.inlineInput,
                {
                  backgroundColor: colors.input,
                  color: colors.foreground,
                  borderColor: colors.border,
                  borderRadius: colors.radius / 2,
                },
              ]}
            />
          )}
        </View>

        {/* ---- Code Citations ---- */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          <View style={styles.sectionHeaderRow}>
            <SectionHeader icon="book-open" label="Code Citations" />
            {selectedCitations.length > 0 && (
              <View style={[styles.citationBadge, { backgroundColor: colors.accent }]}>
                <Text style={styles.citationBadgeText}>{selectedCitations.length}</Text>
              </View>
            )}
          </View>

          {selectedCitations.length > 0 && (
            <View style={styles.citationList}>
              {CODE_CITATIONS.filter((c) => selectedCitations.includes(c.id)).map((c) => (
                <View
                  key={c.id}
                  style={[
                    styles.citationTag,
                    { backgroundColor: colors.secondary, borderRadius: colors.radius / 2 },
                  ]}
                >
                  <Text style={[styles.citationTagCode, { color: colors.accent }]}>
                    {c.code} {c.section}
                  </Text>
                  <Text style={[styles.citationTagTitle, { color: colors.foreground }]}>
                    {c.title}
                  </Text>
                  <TouchableOpacity onPress={() => toggleCitation(c.id)}>
                    <Feather name="x" size={14} color={colors.mutedForeground} />
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          )}

          <TouchableOpacity
            onPress={() => setCitationModalVisible(true)}
            activeOpacity={0.85}
            style={[
              styles.addPhotoButton,
              { borderColor: colors.accent, borderRadius: colors.radius / 2, backgroundColor: colors.secondary },
            ]}
          >
            <Feather name="plus" size={16} color={colors.accent} />
            <Text style={[styles.addPhotoText, { color: colors.accent }]}>
              {selectedCitations.length === 0 ? "Add Code Citation" : "Add Another Citation"}
            </Text>
          </TouchableOpacity>
        </View>
      </KeyboardAwareScrollViewCompat>

      {/* ---- Action buttons (fixed footer) ---- */}
      <View
        style={[
          styles.actionBar,
          {
            backgroundColor: colors.card,
            borderTopColor: colors.border,
            paddingBottom: bottomPad + 12,
          },
        ]}
      >
        <TouchableOpacity
          onPress={() => handleSave(false)}
          disabled={saving}
          activeOpacity={0.85}
          style={[
            styles.saveButton,
            { borderColor: colors.primary, borderRadius: colors.radius },
          ]}
        >
          <Feather name="save" size={16} color={colors.primary} />
          <Text style={[styles.saveButtonText, { color: colors.primary }]}>
            {saving ? "Saving…" : "Save Draft"}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => handleSave(true)}
          disabled={saving}
          activeOpacity={0.85}
          style={[
            styles.completeButton,
            {
              backgroundColor: canMarkComplete ? colors.success : colors.muted,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Feather
            name="check-circle"
            size={16}
            color={canMarkComplete ? "#FFFFFF" : colors.mutedForeground}
          />
          <Text
            style={[
              styles.completeButtonText,
              { color: canMarkComplete ? "#FFFFFF" : colors.mutedForeground },
            ]}
          >
            Mark Complete
          </Text>
        </TouchableOpacity>
      </View>

      {/* ---- Code Citation Picker Modal ---- */}
      <Modal
        visible={citationModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setCitationModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.citationSheet,
              { backgroundColor: colors.card, paddingBottom: bottomPad + 16 },
            ]}
          >
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>
                Code Citations
              </Text>
              <TouchableOpacity onPress={() => setCitationModalVisible(false)}>
                <Feather name="check" size={22} color={colors.accent} />
              </TouchableOpacity>
            </View>
            <Text style={[styles.modalSubtitle, { color: colors.mutedForeground }]}>
              Select all applicable codes for this damage instance.
            </Text>

            <FlatList
              data={CODE_CITATIONS}
              keyExtractor={(c) => c.id}
              ItemSeparatorComponent={() => (
                <View style={[styles.separator, { backgroundColor: colors.border }]} />
              )}
              renderItem={({ item: citation }) => {
                const isSelected = selectedCitations.includes(citation.id);
                return (
                  <TouchableOpacity
                    onPress={() => toggleCitation(citation.id)}
                    activeOpacity={0.75}
                    style={[
                      styles.citationRow,
                      isSelected && { backgroundColor: colors.secondary },
                    ]}
                  >
                    <View style={styles.citationRowBody}>
                      <View style={styles.citationRowTop}>
                        <Text style={[styles.citationCode, { color: colors.accent }]}>
                          {citation.code} {citation.section}
                        </Text>
                      </View>
                      <Text style={[styles.citationTitle, { color: colors.foreground }]}>
                        {citation.title}
                      </Text>
                      <Text
                        style={[styles.citationDesc, { color: colors.mutedForeground }]}
                        numberOfLines={2}
                      >
                        {citation.description}
                      </Text>
                    </View>
                    <Feather
                      name={isSelected ? "check-square" : "square"}
                      size={20}
                      color={isSelected ? colors.accent : colors.mutedForeground}
                    />
                  </TouchableOpacity>
                );
              }}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Styles
// ---------------------------------------------------------------------------
const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 16, gap: 12 },
  section: { padding: 16, borderWidth: 1, gap: 12 },
  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  sectionHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  sectionLabel: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  chipWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderWidth: 1,
  },
  chipText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  severityChip: { paddingVertical: 10, paddingHorizontal: 20, borderWidth: 1.5 },
  // Photos
  photoCountBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  photoCountText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  photoGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  photoThumb: {},
  photoRemove: {
    position: "absolute",
    top: 4,
    right: 4,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: "rgba(0,0,0,0.65)",
    alignItems: "center",
    justifyContent: "center",
  },
  addPhotoButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    padding: 12,
    borderWidth: 1.5,
    borderStyle: "dashed",
  },
  addPhotoText: { fontSize: 14, fontFamily: "Inter_500Medium" },
  // Textarea
  textarea: {
    padding: 12,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
    minHeight: 90,
    lineHeight: 20,
  },
  // Switch
  switchRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },
  switchLabel: { flex: 1, gap: 2 },
  switchSubtitle: { fontSize: 12, fontFamily: "Inter_400Regular" },
  inlineInput: {
    height: 44,
    paddingHorizontal: 12,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
  },
  // Code citations
  citationBadge: {
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 6,
  },
  citationBadgeText: { color: "#FFFFFF", fontSize: 11, fontFamily: "Inter_700Bold" },
  citationList: { gap: 8 },
  citationTag: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 10,
  },
  citationTagCode: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  citationTagTitle: { flex: 1, fontSize: 12, fontFamily: "Inter_400Regular" },
  // Action bar
  actionBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    gap: 10,
    padding: 12,
    borderTopWidth: 1,
  },
  saveButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 14,
    borderWidth: 1.5,
  },
  saveButtonText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  completeButton: {
    flex: 1.4,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 14,
  },
  completeButtonText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  citationSheet: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    gap: 12,
    maxHeight: "85%",
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  modalTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  modalSubtitle: { fontSize: 13, fontFamily: "Inter_400Regular" },
  separator: { height: 1, marginHorizontal: 16 },
  citationRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 12,
  },
  citationRowBody: { flex: 1, gap: 3 },
  citationRowTop: { flexDirection: "row", alignItems: "center", gap: 6 },
  citationCode: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  citationTitle: { fontSize: 14, fontFamily: "Inter_500Medium" },
  citationDesc: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
});
