import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useInspections } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function stormDateToInput(iso: string | undefined): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${mm}/${dd}/${d.getFullYear()}`;
}

interface FieldProps {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  placeholder: string;
  error?: string | null;
  keyboardType?: "default" | "email-address" | "phone-pad";
  autoCapitalize?: "none" | "words" | "sentences";
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  error,
  keyboardType = "default",
  autoCapitalize = "words",
}: FieldProps) {
  const colors = useColors();
  return (
    <View style={{ gap: 6 }}>
      <Text style={[fieldStyles.label, { color: colors.foreground }]}>
        {label} <Text style={{ color: colors.destructive }}>*</Text>
      </Text>
      <TextInput
        style={[
          fieldStyles.input,
          {
            backgroundColor: colors.card,
            color: colors.foreground,
            borderColor: error ? colors.destructive : colors.border,
            borderRadius: colors.radius,
          },
        ]}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.mutedForeground}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize}
        autoCorrect={false}
      />
      {error ? (
        <Text style={[fieldStyles.errorText, { color: colors.destructive }]}>{error}</Text>
      ) : null}
    </View>
  );
}

const fieldStyles = StyleSheet.create({
  label: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  input: {
    padding: 14,
    fontSize: 16,
    fontFamily: "Inter_400Regular",
    borderWidth: 1.5,
  },
  errorText: { fontSize: 12, fontFamily: "Inter_400Regular" },
});

export default function CustomerClaimScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getProfile, updateProfile } = useInspections();

  const profile = getProfile(id);

  const [customerName, setCustomerName] = useState(profile?.customerName ?? "");
  const [customerPhone, setCustomerPhone] = useState(profile?.customerPhone ?? "");
  const [customerEmail, setCustomerEmail] = useState(profile?.customerEmail ?? "");
  const [claimNumber, setClaimNumber] = useState(profile?.claimNumber ?? "");
  const [insuranceCarrier, setInsuranceCarrier] = useState(profile?.insuranceCarrier ?? "");
  const [adjusterName, setAdjusterName] = useState(profile?.adjusterName ?? "");
  const [adjusterContact, setAdjusterContact] = useState(profile?.adjusterContact ?? "");
  const [dateOfLoss, setDateOfLoss] = useState(
    profile?.dateOfLoss ?? stormDateToInput(profile?.selectedStorm?.date),
  );
  const [showErrors, setShowErrors] = useState(false);

  if (!profile) {
    return (
      <View style={[styles.centered, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground }}>Inspection not found</Text>
      </View>
    );
  }

  const errors = {
    customerName: customerName.trim() ? null : "Customer name is required.",
    customerPhone: customerPhone.trim() ? null : "Phone number is required.",
    customerEmail: !customerEmail.trim()
      ? "Email is required."
      : EMAIL_REGEX.test(customerEmail.trim())
        ? null
        : "Enter a valid email address.",
    claimNumber: claimNumber.trim() ? null : "Claim / policy number is required.",
    insuranceCarrier: insuranceCarrier.trim() ? null : "Insurance carrier is required.",
    adjusterName: adjusterName.trim() ? null : "Adjuster name is required.",
    adjusterContact: adjusterContact.trim() ? null : "Adjuster phone or email is required.",
    dateOfLoss: dateOfLoss.trim() ? null : "Date of loss is required.",
  };
  const isValid = Object.values(errors).every((e) => e === null);

  const handleContinue = () => {
    if (!isValid) {
      setShowErrors(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      return;
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    updateProfile(id, {
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail.trim(),
      claimNumber: claimNumber.trim(),
      insuranceCarrier: insuranceCarrier.trim(),
      adjusterName: adjusterName.trim(),
      adjusterContact: adjusterContact.trim(),
      dateOfLoss: dateOfLoss.trim(),
    });
    router.back();
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const err = (key: keyof typeof errors) => (showErrors ? errors[key] : null);

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingBottom: bottomPad + 32 }]}
      keyboardShouldPersistTaps="handled"
    >
      {/* Intro */}
      <View style={styles.introRow}>
        <View style={[styles.iconCircle, { backgroundColor: colors.secondary }]}>
          <Feather name="user-check" size={22} color={colors.accent} />
        </View>
        <Text style={[styles.introText, { color: colors.mutedForeground }]}>
          A complete customer profile and claim details are required before the
          forensic inspection can begin.
        </Text>
      </View>

      {/* Customer Profile */}
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
        Customer Profile
      </Text>
      <View
        style={[
          styles.sectionCard,
          { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
        ]}
      >
        <Field
          label="Full Name"
          value={customerName}
          onChangeText={setCustomerName}
          placeholder="e.g. Jane Homeowner"
          error={err("customerName")}
        />
        <Field
          label="Phone"
          value={customerPhone}
          onChangeText={setCustomerPhone}
          placeholder="e.g. (555) 123-4567"
          keyboardType="phone-pad"
          autoCapitalize="none"
          error={err("customerPhone")}
        />
        <Field
          label="Email"
          value={customerEmail}
          onChangeText={setCustomerEmail}
          placeholder="e.g. jane@example.com"
          keyboardType="email-address"
          autoCapitalize="none"
          error={err("customerEmail")}
        />
      </View>

      {/* Claim Details */}
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
        Claim Details
      </Text>
      <View
        style={[
          styles.sectionCard,
          { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
        ]}
      >
        <Field
          label="Claim / Policy Number"
          value={claimNumber}
          onChangeText={setClaimNumber}
          placeholder="e.g. CLM-2026-004821"
          autoCapitalize="none"
          error={err("claimNumber")}
        />
        <Field
          label="Insurance Carrier"
          value={insuranceCarrier}
          onChangeText={setInsuranceCarrier}
          placeholder="e.g. State Farm"
          error={err("insuranceCarrier")}
        />
        <Field
          label="Adjuster Name"
          value={adjusterName}
          onChangeText={setAdjusterName}
          placeholder="e.g. John Adjuster"
          error={err("adjusterName")}
        />
        <Field
          label="Adjuster Contact (phone or email)"
          value={adjusterContact}
          onChangeText={setAdjusterContact}
          placeholder="e.g. (555) 987-6543 or john@carrier.com"
          autoCapitalize="none"
          error={err("adjusterContact")}
        />
        <Field
          label="Date of Loss"
          value={dateOfLoss}
          onChangeText={setDateOfLoss}
          placeholder="MM/DD/YYYY"
          autoCapitalize="none"
          error={err("dateOfLoss")}
        />
        {!!profile.selectedStorm?.date && !dateOfLoss.trim() && (
          <TouchableOpacity
            onPress={() => setDateOfLoss(stormDateToInput(profile.selectedStorm?.date))}
            activeOpacity={0.7}
          >
            <Text style={[styles.stormHint, { color: colors.accent }]}>
              Use selected storm date ({stormDateToInput(profile.selectedStorm?.date)})
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {showErrors && !isValid && (
        <View
          style={[
            styles.warnBanner,
            { backgroundColor: "#FFFBEB", borderRadius: colors.radius },
          ]}
        >
          <Feather name="alert-triangle" size={15} color="#F59E0B" />
          <Text style={styles.warnText}>
            Please complete all required fields to continue.
          </Text>
        </View>
      )}

      <TouchableOpacity
        onPress={handleContinue}
        activeOpacity={0.85}
        style={[
          styles.continueButton,
          {
            backgroundColor: isValid ? colors.primary : colors.muted,
            borderRadius: colors.radius,
          },
        ]}
      >
        <Feather
          name="arrow-right-circle"
          size={20}
          color={isValid ? colors.primaryForeground : colors.mutedForeground}
        />
        <Text
          style={[
            styles.continueButtonText,
            { color: isValid ? colors.primaryForeground : colors.mutedForeground },
          ]}
        >
          Save & Continue to Forensic Inspection
        </Text>
      </TouchableOpacity>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20, gap: 14 },
  centered: { flex: 1, alignItems: "center", justifyContent: "center" },
  introRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 4,
  },
  iconCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  introText: {
    flex: 1,
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    lineHeight: 19,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
    marginTop: 6,
  },
  sectionCard: {
    borderWidth: 1,
    padding: 16,
    gap: 14,
  },
  stormHint: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  warnBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
  },
  warnText: {
    flex: 1,
    fontSize: 13,
    color: "#92400E",
    fontFamily: "Inter_400Regular",
    lineHeight: 18,
  },
  continueButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 10,
    marginTop: 4,
  },
  continueButtonText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
});
