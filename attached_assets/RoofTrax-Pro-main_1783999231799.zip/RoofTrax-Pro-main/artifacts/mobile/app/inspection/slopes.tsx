import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  Alert,
  FlatList,
  Modal,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ForensicIntakeGuard } from "@/components/ForensicIntakeGuard";
import {
  isForensicIntakeComplete,
  useInspections,
  type RoofSlope,
  type SlopeOrientation,
} from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";

const ORIENTATIONS: {
  value: SlopeOrientation;
  label: string;
  icon: string;
}[] = [
  { value: "front", label: "Front", icon: "home" },
  { value: "back", label: "Back", icon: "arrow-up" },
  { value: "left", label: "Left", icon: "arrow-left" },
  { value: "right", label: "Right", icon: "arrow-right" },
  { value: "flat", label: "Flat", icon: "minus" },
  { value: "garage", label: "Garage", icon: "truck" },
  { value: "porch", label: "Porch", icon: "sun" },
  { value: "other", label: "Other", icon: "more-horizontal" },
];

const ORIENTATION_LABELS: Record<SlopeOrientation, string> = Object.fromEntries(
  ORIENTATIONS.map((o) => [o.value, o.label]),
) as Record<SlopeOrientation, string>;

const ORIENTATION_ICONS: Record<SlopeOrientation, string> = Object.fromEntries(
  ORIENTATIONS.map((o) => [o.value, o.icon]),
) as Record<SlopeOrientation, string>;

// ---------------------------------------------------------------------------
// SlopeCard — extracted so it can own its own SQ input state
// ---------------------------------------------------------------------------
function SlopeCard({
  slope,
  inspId,
  onOpen,
  onDelete,
}: {
  slope: RoofSlope;
  inspId: string;
  onOpen: (slope: RoofSlope) => void;
  onDelete: (slope: RoofSlope) => void;
}) {
  const colors = useColors();
  const { updateSlope } = useInspections();

  const total = slope.damageInstances.length;
  const complete = slope.damageInstances.filter((d) => d.isComplete).length;
  const icon = ORIENTATION_ICONS[slope.orientation] ?? "layers";
  const allComplete = total > 0 && complete === total;

  const [sqText, setSqText] = useState(
    slope.squareFootage != null ? slope.squareFootage.toString() : "",
  );

  // Keep local state in sync if the slope is updated externally
  useEffect(() => {
    setSqText(slope.squareFootage != null ? slope.squareFootage.toString() : "");
  }, [slope.squareFootage]);

  const handleSqBlur = () => {
    const num = parseFloat(sqText);
    updateSlope(inspId, slope.id, {
      squareFootage: isNaN(num) || num < 0 ? undefined : num,
    });
  };

  return (
    <View
      style={[
        styles.slopeCard,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius,
        },
      ]}
    >
      {/* Main tap row */}
      <TouchableOpacity
        onPress={() => onOpen(slope)}
        activeOpacity={0.85}
        style={styles.slopeMainRow}
      >
        <View style={[styles.slopeIcon, { backgroundColor: colors.secondary }]}>
          <Feather name={icon as any} size={22} color={colors.accent} />
        </View>

        <View style={styles.slopeBody}>
          <Text style={[styles.slopeLabel, { color: colors.foreground }]}>
            {slope.label}
          </Text>
          <Text style={[styles.slopeMeta, { color: colors.mutedForeground }]}>
            {total === 0
              ? "No damage documented"
              : `${complete}/${total} instances complete`}
          </Text>
        </View>

        <View style={styles.slopeRight}>
          {allComplete && (
            <Feather name="check-circle" size={18} color={colors.success} />
          )}
          {total > 0 && !allComplete && (
            <View style={[styles.countBadge, { backgroundColor: colors.accent }]}>
              <Text style={styles.countBadgeText}>{total}</Text>
            </View>
          )}
          <TouchableOpacity
            onPress={() => onDelete(slope)}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.deleteBtn}
          >
            <Feather name="trash-2" size={16} color={colors.destructive} />
          </TouchableOpacity>
          <Feather name="chevron-right" size={20} color={colors.mutedForeground} />
        </View>
      </TouchableOpacity>

      {/* SQ input row */}
      <View style={[styles.sqRow, { borderTopColor: colors.border }]}>
        <Feather name="square" size={13} color={colors.mutedForeground} />
        <Text style={[styles.sqLabel, { color: colors.mutedForeground }]}>Square Footage:</Text>
        <TextInput
          value={sqText}
          onChangeText={setSqText}
          onBlur={handleSqBlur}
          keyboardType="decimal-pad"
          placeholder="—"
          placeholderTextColor={colors.mutedForeground}
          style={[
            styles.sqInput,
            {
              backgroundColor: colors.input,
              color: colors.foreground,
              borderColor: colors.border,
              borderRadius: colors.radius / 3,
            },
          ]}
        />
        <Text style={[styles.sqUnit, { color: colors.mutedForeground }]}>SQ</Text>
      </View>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Main screen
// ---------------------------------------------------------------------------
export default function SlopesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getProfile, addSlope, deleteSlope } = useInspections();

  const profile = getProfile(id);
  const slopes = profile?.slopes ?? [];

  const [modalVisible, setModalVisible] = useState(false);
  const [pendingOrientation, setPendingOrientation] = useState<SlopeOrientation | null>(null);
  const [pendingLabel, setPendingLabel] = useState("");

  // Phase 2 gate — customer profile & claim details must be complete first.
  if (profile && !isForensicIntakeComplete(profile)) {
    return <ForensicIntakeGuard inspectionId={id} />;
  }

  const openModal = () => {
    setPendingOrientation(null);
    setPendingLabel("");
    setModalVisible(true);
  };

  const handleOrientationSelect = (o: SlopeOrientation) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setPendingOrientation(o);
    if (!pendingLabel || ORIENTATIONS.some((opt) => opt.label === pendingLabel)) {
      setPendingLabel(ORIENTATION_LABELS[o]);
    }
  };

  const handleAddSlope = () => {
    if (!pendingOrientation || !pendingLabel.trim()) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    addSlope(id, { orientation: pendingOrientation, label: pendingLabel.trim() });
    setModalVisible(false);
  };

  const handleDeleteSlope = (slope: RoofSlope) => {
    Alert.alert(
      "Delete Slope",
      `Delete "${slope.label}" and all its damage instances?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            deleteSlope(id, slope.id);
          },
        },
      ],
    );
  };

  const handleOpenSlope = (slope: RoofSlope) => {
    router.push({
      pathname: "/inspection/slope-damages",
      params: { id, slopeId: slope.id, slopeLabel: slope.label },
    });
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={slopes}
        keyExtractor={(s) => s.id}
        contentContainerStyle={[
          styles.listContent,
          slopes.length === 0 && styles.listEmpty,
        ]}
        ListEmptyComponent={
          <View style={styles.emptyWrap}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="layers" size={40} color={colors.mutedForeground} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              No slopes documented yet
            </Text>
            <Text style={[styles.emptySubtitle, { color: colors.mutedForeground }]}>
              Tap "+ Add Slope" to start documenting each roof slope individually.
            </Text>
          </View>
        }
        renderItem={({ item: slope }) => (
          <SlopeCard
            slope={slope}
            inspId={id}
            onOpen={handleOpenSlope}
            onDelete={handleDeleteSlope}
          />
        )}
      />

      <View style={[styles.footer, { paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity
          onPress={openModal}
          activeOpacity={0.85}
          style={[
            styles.addButton,
            { backgroundColor: colors.accent, borderRadius: colors.radius },
          ]}
        >
          <Feather name="plus" size={20} color="#FFFFFF" />
          <Text style={styles.addButtonText}>Add Slope</Text>
        </TouchableOpacity>
      </View>

      {/* Add Slope Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.modalSheet,
              {
                backgroundColor: colors.card,
                paddingBottom: bottomPad + 16,
              },
            ]}
          >
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>Add Slope</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Feather name="x" size={22} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>

            <Text style={[styles.modalSectionLabel, { color: colors.mutedForeground }]}>
              Orientation
            </Text>
            <View style={styles.orientationGrid}>
              {ORIENTATIONS.map((o) => {
                const isSelected = pendingOrientation === o.value;
                return (
                  <TouchableOpacity
                    key={o.value}
                    onPress={() => handleOrientationSelect(o.value)}
                    activeOpacity={0.8}
                    style={[
                      styles.orientationChip,
                      {
                        backgroundColor: isSelected ? colors.primary : colors.secondary,
                        borderColor: isSelected ? colors.primary : colors.border,
                        borderRadius: colors.radius / 2,
                      },
                    ]}
                  >
                    <Feather
                      name={o.icon as any}
                      size={16}
                      color={isSelected ? "#FFFFFF" : colors.accent}
                    />
                    <Text
                      style={[
                        styles.orientationLabel,
                        { color: isSelected ? "#FFFFFF" : colors.foreground },
                      ]}
                    >
                      {o.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            <Text style={[styles.modalSectionLabel, { color: colors.mutedForeground }]}>
              Label
            </Text>
            <TextInput
              value={pendingLabel}
              onChangeText={setPendingLabel}
              placeholder="e.g. Front, Back, Garage Left…"
              placeholderTextColor={colors.mutedForeground}
              style={[
                styles.labelInput,
                {
                  backgroundColor: colors.input,
                  color: colors.foreground,
                  borderColor: colors.border,
                  borderRadius: colors.radius / 2,
                },
              ]}
            />

            <TouchableOpacity
              onPress={handleAddSlope}
              disabled={!pendingOrientation || !pendingLabel.trim()}
              activeOpacity={0.85}
              style={[
                styles.modalSave,
                {
                  backgroundColor:
                    pendingOrientation && pendingLabel.trim() ? colors.accent : colors.muted,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <Text
                style={[
                  styles.modalSaveText,
                  {
                    color:
                      pendingOrientation && pendingLabel.trim()
                        ? "#FFFFFF"
                        : colors.mutedForeground,
                  },
                ]}
              >
                Add Slope
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  listContent: { padding: 16, gap: 12 },
  listEmpty: { flex: 1 },
  emptyWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 14,
    padding: 32,
  },
  emptyIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  emptySubtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
  slopeCard: {
    borderWidth: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
    overflow: "hidden",
  },
  slopeMainRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 12,
  },
  slopeIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  slopeBody: { flex: 1, gap: 3 },
  slopeLabel: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  slopeMeta: { fontSize: 12, fontFamily: "Inter_400Regular" },
  slopeRight: { flexDirection: "row", alignItems: "center", gap: 10 },
  countBadge: {
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 6,
  },
  countBadgeText: { color: "#FFFFFF", fontSize: 11, fontFamily: "Inter_700Bold" },
  deleteBtn: { padding: 2 },
  sqRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderTopWidth: 1,
  },
  sqLabel: { fontSize: 12, fontFamily: "Inter_500Medium" },
  sqInput: {
    flex: 1,
    height: 34,
    paddingHorizontal: 10,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
    textAlign: "right",
  },
  sqUnit: { fontSize: 12, fontFamily: "Inter_600SemiBold", width: 24 },
  footer: { paddingHorizontal: 16, paddingTop: 8 },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 8,
  },
  addButtonText: { color: "#FFFFFF", fontSize: 16, fontFamily: "Inter_600SemiBold" },
  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalSheet: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    gap: 14,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  modalTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  modalSectionLabel: {
    fontSize: 12,
    fontFamily: "Inter_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  orientationGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  orientationChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderWidth: 1,
  },
  orientationLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },
  labelInput: {
    height: 46,
    paddingHorizontal: 12,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
  },
  modalSave: {
    alignItems: "center",
    justifyContent: "center",
    padding: 15,
    marginTop: 4,
  },
  modalSaveText: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
});
