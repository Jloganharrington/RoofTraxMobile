import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Image,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useInspections } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";
import { copyToDocumentsDetailed, warnCopyFailures } from "@/utils/photos";

export default function FrontPhotoScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { updateProfile } = useInspections();
  const [photoUri, setPhotoUri] = useState<string | null>(null);

  const takePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Camera Access Required", "Please allow camera access to take inspection photos.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.85 });
    if (!result.canceled && result.assets[0]) {
      setPhotoUri(result.assets[0].uri);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const pickFromLibrary = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Photo Library Access Required", "Please allow photo library access.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      quality: 0.85,
    });
    if (!result.canceled && result.assets[0]) {
      setPhotoUri(result.assets[0].uri);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleRetake = () => {
    setPhotoUri(null);
  };

  const handleNext = async () => {
    if (!photoUri) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const { uri: permanentUri, ok } = await copyToDocumentsDetailed(photoUri);
    warnCopyFailures(ok ? 0 : 1);
    updateProfile(id, { frontPhoto: permanentUri, status: "in_progress" });
    router.push({ pathname: "/inspection/scope", params: { id } });
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.inner}>
        {/* Step indicator */}
        <View style={styles.stepRow}>
          {[1, 2, 3, 4].map((step, i) => (
            <View key={step} style={styles.stepItem}>
              <View
                style={[
                  styles.stepDot,
                  {
                    backgroundColor: i === 0 ? colors.accent : colors.muted,
                    width: i === 0 ? 24 : 8,
                    borderRadius: i === 0 ? 12 : 4,
                  },
                ]}
              />
            </View>
          ))}
        </View>

        <Text style={[styles.title, { color: colors.foreground }]}>
          Front of Home
        </Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Take a clear photo of the front of the property. This is required before proceeding.
        </Text>

        {photoUri ? (
          <View style={styles.photoContainer}>
            <Image
              source={{ uri: photoUri }}
              style={[styles.photo, { borderRadius: colors.radius }]}
              resizeMode="cover"
            />
            <View style={[styles.photoBadge, { backgroundColor: colors.success }]}>
              <Feather name="check" size={14} color="#FFFFFF" />
              <Text style={styles.photoBadgeText}>Photo Captured</Text>
            </View>
          </View>
        ) : (
          <View style={[styles.placeholder, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            <Feather name="camera" size={48} color={colors.mutedForeground} />
            <Text style={[styles.placeholderText, { color: colors.mutedForeground }]}>
              No photo yet
            </Text>
          </View>
        )}

        <View style={styles.buttonRow}>
          <TouchableOpacity
            onPress={takePhoto}
            activeOpacity={0.85}
            style={[
              styles.photoButton,
              { backgroundColor: colors.primary, borderRadius: colors.radius },
            ]}
          >
            <Feather name="camera" size={20} color={colors.primaryForeground} />
            <Text style={[styles.photoButtonText, { color: colors.primaryForeground }]}>
              {photoUri ? "Retake" : "Take Photo"}
            </Text>
          </TouchableOpacity>

          {!photoUri && (
            <TouchableOpacity
              onPress={pickFromLibrary}
              activeOpacity={0.85}
              style={[
                styles.photoButton,
                { backgroundColor: colors.secondary, borderRadius: colors.radius },
              ]}
            >
              <Feather name="image" size={20} color={colors.primary} />
              <Text style={[styles.photoButtonText, { color: colors.primary }]}>
                From Library
              </Text>
            </TouchableOpacity>
          )}

          {photoUri && (
            <TouchableOpacity
              onPress={handleRetake}
              activeOpacity={0.85}
              style={[
                styles.photoButton,
                { backgroundColor: colors.secondary, borderRadius: colors.radius },
              ]}
            >
              <Feather name="refresh-cw" size={20} color={colors.primary} />
              <Text style={[styles.photoButtonText, { color: colors.primary }]}>Retake</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      <View style={[styles.footer, { paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity
          onPress={handleNext}
          disabled={!photoUri}
          activeOpacity={0.85}
          style={[
            styles.nextButton,
            {
              backgroundColor: photoUri ? colors.accent : colors.muted,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Text
            style={[
              styles.nextButtonText,
              { color: photoUri ? "#FFFFFF" : colors.mutedForeground },
            ]}
          >
            Next
          </Text>
          <Feather
            name="arrow-right"
            size={20}
            color={photoUri ? "#FFFFFF" : colors.mutedForeground}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  inner: { flex: 1, paddingHorizontal: 24, paddingTop: 24, gap: 16 },
  stepRow: { flexDirection: "row", gap: 6, alignItems: "center", marginBottom: 8 },
  stepItem: {},
  stepDot: { height: 8 },
  title: { fontSize: 26, fontFamily: "Inter_700Bold" },
  subtitle: { fontSize: 15, fontFamily: "Inter_400Regular", lineHeight: 22 },
  photoContainer: { flex: 1, position: "relative", maxHeight: 280 },
  photo: { width: "100%", height: 260 },
  photoBadge: {
    position: "absolute",
    top: 12,
    right: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  photoBadgeText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  placeholder: {
    flex: 1,
    maxHeight: 260,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderStyle: "dashed",
    gap: 12,
  },
  placeholderText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  buttonRow: { flexDirection: "row", gap: 12 },
  photoButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 14,
    gap: 8,
  },
  photoButtonText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  footer: { paddingHorizontal: 24, paddingTop: 12 },
  nextButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 10,
  },
  nextButtonText: { fontSize: 17, fontFamily: "Inter_600SemiBold" },
});
