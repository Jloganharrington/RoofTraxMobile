import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useMemo, useRef, useState } from "react";
import {
  Alert,
  Image,
  Modal,
  PanResponder,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import Svg, {
  Circle,
  Line,
  Path,
  Polygon,
  Rect,
  Text as SvgText,
} from "react-native-svg";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { type Annotation, type AnnotationTool, useInspections } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";

const SVG_W = 1000;
const SVG_H = 750;

const COLORS = ["#EF4444", "#F97316", "#EAB308", "#22C55E", "#FFFFFF", "#06B6D4"];
const STROKES = [4, 8, 14];

const TOOL_ICONS: Record<AnnotationTool, string> = {
  arrow: "arrow-up-right",
  circle: "circle",
  rect: "square",
  freehand: "edit-2",
  text: "type",
};

const TOOL_LABELS: Record<AnnotationTool, string> = {
  arrow: "Arrow",
  circle: "Circle",
  rect: "Box",
  freehand: "Draw",
  text: "Text",
};

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

function arrowheadPoints(x1: number, y1: number, x2: number, y2: number): string {
  const len = 30;
  const angle = Math.atan2(y2 - y1, x2 - x1);
  return [
    `${x2},${y2}`,
    `${x2 - len * Math.cos(angle - Math.PI / 6)},${y2 - len * Math.sin(angle - Math.PI / 6)}`,
    `${x2 - len * Math.cos(angle + Math.PI / 6)},${y2 - len * Math.sin(angle + Math.PI / 6)}`,
  ].join(" ");
}

function freehandPath(points: { x: number; y: number }[]): string {
  if (points.length === 0) return "";
  return points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");
}

function AnnotationShape({ a }: { a: Annotation }) {
  const sw = a.strokeWidth ?? 6;
  const c = a.color ?? "#EF4444";

  if (a.tool === "arrow" && a.x1 != null && a.y1 != null && a.x2 != null && a.y2 != null) {
    const pts = arrowheadPoints(a.x1, a.y1, a.x2, a.y2);
    return (
      <>
        <Line
          x1={a.x1} y1={a.y1} x2={a.x2} y2={a.y2}
          stroke={c} strokeWidth={sw} strokeLinecap="round"
        />
        <Polygon points={pts} fill={c} />
      </>
    );
  }
  if (a.tool === "circle" && a.cx != null && a.cy != null && a.r != null) {
    return <Circle cx={a.cx} cy={a.cy} r={a.r} stroke={c} strokeWidth={sw} fill="none" />;
  }
  if (a.tool === "rect" && a.x != null && a.y != null && a.width != null && a.height != null) {
    return (
      <Rect
        x={a.x} y={a.y} width={a.width} height={a.height}
        stroke={c} strokeWidth={sw} fill="none" rx={4}
      />
    );
  }
  if (a.tool === "freehand" && a.points && a.points.length > 1) {
    return (
      <Path
        d={freehandPath(a.points)}
        stroke={c} strokeWidth={sw} fill="none"
        strokeLinecap="round" strokeLinejoin="round"
      />
    );
  }
  if (a.tool === "text" && a.text && a.x != null && a.y != null) {
    return (
      <SvgText
        x={a.x} y={a.y}
        fill={c}
        fontSize={a.fontSize ?? 40}
        fontWeight="bold"
        stroke={c === "#FFFFFF" ? "rgba(0,0,0,0.6)" : "none"}
        strokeWidth={c === "#FFFFFF" ? 2 : 0}
      >
        {a.text}
      </SvgText>
    );
  }
  return null;
}

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

export default function AnnotateScreen() {
  const insets = useSafeAreaInsets();
  const { width: screenWidth } = useWindowDimensions();
  const { id, photoUri } = useLocalSearchParams<{ id: string; photoUri: string }>();
  const { getProfile, updateProfile } = useInspections();
  const profile = getProfile(id);

  const decodedUri = decodeURIComponent(photoUri ?? "");
  const canvasWidth = screenWidth;
  const canvasHeight = Math.round(screenWidth * 0.75);

  const existingAnnotations = profile?.photoAnnotations?.[decodedUri] ?? [];
  const [annotations, setAnnotations] = useState<Annotation[]>(existingAnnotations);
  const [currentAnnotation, setCurrentAnnotation] = useState<Annotation | null>(null);
  const [tool, setTool] = useState<AnnotationTool>("arrow");
  const [color, setColor] = useState(COLORS[0]);
  const [strokeWidth, setStrokeWidth] = useState(STROKES[1]);
  const [showTextModal, setShowTextModal] = useState(false);
  const [textInput, setTextInput] = useState("");
  const pendingTextPos = useRef<{ x: number; y: number } | null>(null);

  const toolRef = useRef(tool);
  const colorRef = useRef(color);
  const strokeRef = useRef(strokeWidth);
  const currentRef = useRef<Annotation | null>(null);

  toolRef.current = tool;
  colorRef.current = color;
  strokeRef.current = strokeWidth;

  const toSvg = (lx: number, ly: number) => ({
    x: clamp((lx / canvasWidth) * SVG_W, 0, SVG_W),
    y: clamp((ly / canvasHeight) * SVG_H, 0, SVG_H),
  });

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderGrant: (evt) => {
          const { locationX, locationY } = evt.nativeEvent;
          const { x, y } = {
            x: clamp((locationX / canvasWidth) * SVG_W, 0, SVG_W),
            y: clamp((locationY / canvasHeight) * SVG_H, 0, SVG_H),
          };
          const t = toolRef.current;
          const c = colorRef.current;
          const sw = strokeRef.current;

          if (t === "text") {
            pendingTextPos.current = { x, y };
            setShowTextModal(true);
            return;
          }

          let ann: Annotation;
          if (t === "arrow") {
            ann = { id: genId(), tool: "arrow", color: c, strokeWidth: sw, x1: x, y1: y, x2: x, y2: y };
          } else if (t === "circle") {
            ann = { id: genId(), tool: "circle", color: c, strokeWidth: sw, cx: x, cy: y, r: 1 };
          } else if (t === "rect") {
            ann = { id: genId(), tool: "rect", color: c, strokeWidth: sw, x1: x, y1: y, x, y, width: 0, height: 0 };
          } else {
            ann = { id: genId(), tool: "freehand", color: c, strokeWidth: sw, points: [{ x, y }] };
          }
          currentRef.current = ann;
          setCurrentAnnotation({ ...ann });
        },
        onPanResponderMove: (evt) => {
          const { locationX, locationY } = evt.nativeEvent;
          const { x, y } = {
            x: clamp((locationX / canvasWidth) * SVG_W, 0, SVG_W),
            y: clamp((locationY / canvasHeight) * SVG_H, 0, SVG_H),
          };
          const cur = currentRef.current;
          if (!cur) return;

          let updated: Annotation;
          if (cur.tool === "arrow") {
            updated = { ...cur, x2: x, y2: y };
          } else if (cur.tool === "circle") {
            const dx = x - (cur.cx ?? 0);
            const dy = y - (cur.cy ?? 0);
            updated = { ...cur, r: Math.max(1, Math.sqrt(dx * dx + dy * dy)) };
          } else if (cur.tool === "rect") {
            const x0 = cur.x1 ?? 0;
            const y0 = cur.y1 ?? 0;
            updated = {
              ...cur,
              x: Math.min(x0, x),
              y: Math.min(y0, y),
              width: Math.abs(x - x0),
              height: Math.abs(y - y0),
            };
          } else {
            updated = { ...cur, points: [...(cur.points ?? []), { x, y }] };
          }
          currentRef.current = updated;
          setCurrentAnnotation({ ...updated });
        },
        onPanResponderRelease: () => {
          const cur = currentRef.current;
          if (!cur) return;

          const isValid =
            cur.tool === "freehand"
              ? (cur.points?.length ?? 0) > 2
              : cur.tool === "arrow"
              ? Math.hypot((cur.x2 ?? 0) - (cur.x1 ?? 0), (cur.y2 ?? 0) - (cur.y1 ?? 0)) > 10
              : cur.tool === "circle"
              ? (cur.r ?? 0) > 8
              : (cur.width ?? 0) > 8 && (cur.height ?? 0) > 8;

          if (isValid) {
            setAnnotations((prev) => [...prev, cur]);
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          }
          currentRef.current = null;
          setCurrentAnnotation(null);
        },
      }),
    [canvasWidth, canvasHeight]
  );

  const handleConfirmText = () => {
    if (!textInput.trim() || !pendingTextPos.current) {
      setShowTextModal(false);
      setTextInput("");
      return;
    }
    const { x, y } = pendingTextPos.current;
    const ann: Annotation = {
      id: genId(),
      tool: "text",
      color: colorRef.current,
      strokeWidth: strokeRef.current,
      text: textInput.trim(),
      fontSize: 40,
      x,
      y,
    };
    setAnnotations((prev) => [...prev, ann]);
    pendingTextPos.current = null;
    setTextInput("");
    setShowTextModal(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleUndo = () => {
    setAnnotations((prev) => prev.slice(0, -1));
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleClear = () => {
    Alert.alert("Clear All", "Remove all annotations from this photo?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Clear",
        style: "destructive",
        onPress: () => {
          setAnnotations([]);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        },
      },
    ]);
  };

  const handleSave = () => {
    const existing = profile?.photoAnnotations ?? {};
    updateProfile(id, {
      photoAnnotations: { ...existing, [decodedUri]: annotations },
    });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.back();
  };

  const bottomPad = Platform.OS === "web" ? 24 : insets.bottom;

  const tools: AnnotationTool[] = ["arrow", "circle", "rect", "freehand", "text"];

  return (
    <View style={[styles.container, { backgroundColor: "#0A0A0A" }]}>
      <View style={[styles.header, { paddingTop: insets.top + 10 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.iconBtn}>
          <Feather name="x" size={22} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Annotate Photo</Text>
        <View style={styles.headerRight}>
          {annotations.length > 0 && (
            <TouchableOpacity onPress={handleUndo} style={styles.iconBtn}>
              <Feather name="corner-up-left" size={20} color="#FFFFFF" />
            </TouchableOpacity>
          )}
          {annotations.length > 0 && (
            <TouchableOpacity onPress={handleClear} style={styles.iconBtn}>
              <Feather name="trash-2" size={20} color="#FF6B6B" />
            </TouchableOpacity>
          )}
          <TouchableOpacity onPress={handleSave} style={styles.saveBtn}>
            <Feather name="check" size={16} color="#FFFFFF" />
            <Text style={styles.saveBtnText}>Save</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={[styles.canvas, { width: canvasWidth, height: canvasHeight }]}>
        <Image
          source={{ uri: decodedUri }}
          style={[StyleSheet.absoluteFill, { backgroundColor: "#111" }]}
          resizeMode="contain"
        />
        <Svg
          style={StyleSheet.absoluteFill}
          viewBox={`0 0 ${SVG_W} ${SVG_H}`}
          {...panResponder.panHandlers}
        >
          {annotations.map((a) => (
            <AnnotationShape key={a.id} a={a} />
          ))}
          {currentAnnotation && <AnnotationShape a={currentAnnotation} />}
        </Svg>
        {annotations.length === 0 && !currentAnnotation && (
          <View style={styles.hint} pointerEvents="none">
            <Feather name="edit-3" size={20} color="rgba(255,255,255,0.5)" />
            <Text style={styles.hintText}>Draw on the photo to mark damage</Text>
          </View>
        )}
      </View>

      <View style={[styles.toolbar, { paddingBottom: bottomPad + 4 }]}>
        <View style={styles.toolRow}>
          {tools.map((t) => (
            <TouchableOpacity
              key={t}
              onPress={() => setTool(t)}
              style={[styles.toolBtn, tool === t && styles.toolBtnActive]}
              activeOpacity={0.7}
            >
              <Feather
                name={TOOL_ICONS[t] as any}
                size={20}
                color={tool === t ? "#FFFFFF" : "rgba(255,255,255,0.55)"}
              />
              <Text style={[styles.toolLabel, tool === t && styles.toolLabelActive]}>
                {TOOL_LABELS[t]}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.colorRow}>
          {COLORS.map((c) => (
            <TouchableOpacity
              key={c}
              onPress={() => setColor(c)}
              style={[
                styles.colorDot,
                { backgroundColor: c, borderColor: c === "#FFFFFF" ? "#555" : c },
                color === c && styles.colorDotSelected,
              ]}
              activeOpacity={0.75}
            />
          ))}

          <View style={styles.divider} />

          {STROKES.map((s) => (
            <TouchableOpacity
              key={s}
              onPress={() => setStrokeWidth(s)}
              style={[styles.strokeBtn, strokeWidth === s && styles.strokeBtnActive]}
              activeOpacity={0.75}
            >
              <View
                style={{
                  width: s * 2.2,
                  height: s * 2.2,
                  borderRadius: s * 1.1,
                  backgroundColor: strokeWidth === s ? "#F97316" : "rgba(255,255,255,0.55)",
                }}
              />
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <Modal
        visible={showTextModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowTextModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Add Label</Text>
            <TextInput
              style={styles.modalInput}
              value={textInput}
              onChangeText={setTextInput}
              placeholder="Enter label text..."
              placeholderTextColor="rgba(255,255,255,0.35)"
              autoFocus
              maxLength={50}
              onSubmitEditing={handleConfirmText}
              returnKeyType="done"
            />
            <View style={styles.modalActions}>
              <TouchableOpacity
                onPress={() => {
                  setShowTextModal(false);
                  setTextInput("");
                }}
                style={[styles.modalBtn, styles.modalBtnCancel]}
              >
                <Text style={styles.modalBtnCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleConfirmText} style={[styles.modalBtn, styles.modalBtnConfirm]}>
                <Text style={styles.modalBtnConfirmText}>Place Label</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingBottom: 12,
    gap: 8,
  },
  iconBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "rgba(255,255,255,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },
  headerTitle: {
    flex: 1,
    color: "#FFFFFF",
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    textAlign: "center",
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  saveBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: "#F97316",
  },
  saveBtnText: {
    color: "#FFFFFF",
    fontFamily: "Inter_700Bold",
    fontSize: 14,
  },
  canvas: {
    alignSelf: "center",
    overflow: "hidden",
    backgroundColor: "#111",
  },
  hint: {
    position: "absolute",
    bottom: 16,
    left: 0,
    right: 0,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
    pointerEvents: "none",
  },
  hintText: {
    color: "rgba(255,255,255,0.45)",
    fontSize: 13,
    fontFamily: "Inter_400Regular",
  },
  toolbar: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: 12,
    gap: 14,
  },
  toolRow: {
    flexDirection: "row",
    gap: 6,
  },
  toolBtn: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 10,
    borderRadius: 10,
    gap: 4,
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  toolBtnActive: {
    backgroundColor: "#F97316",
  },
  toolLabel: {
    color: "rgba(255,255,255,0.55)",
    fontSize: 10,
    fontFamily: "Inter_500Medium",
  },
  toolLabelActive: {
    color: "#FFFFFF",
  },
  colorRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  colorDot: {
    width: 28,
    height: 28,
    borderRadius: 14,
    borderWidth: 2,
  },
  colorDotSelected: {
    borderColor: "#FFFFFF",
    borderWidth: 3,
    transform: [{ scale: 1.18 }],
  },
  divider: {
    width: 1,
    height: 24,
    backgroundColor: "rgba(255,255,255,0.2)",
    marginHorizontal: 2,
  },
  strokeBtn: {
    width: 36,
    height: 36,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "transparent",
  },
  strokeBtnActive: {
    backgroundColor: "rgba(249,115,22,0.25)",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.72)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  modalCard: {
    width: "100%",
    borderRadius: 16,
    padding: 24,
    gap: 16,
    backgroundColor: "#1E3A5F",
  },
  modalTitle: {
    color: "#FFFFFF",
    fontSize: 18,
    fontFamily: "Inter_700Bold",
  },
  modalInput: {
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 10,
    padding: 14,
    color: "#FFFFFF",
    fontSize: 16,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.2)",
  },
  modalActions: {
    flexDirection: "row",
    gap: 12,
  },
  modalBtn: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 14,
    borderRadius: 10,
  },
  modalBtnCancel: {
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.25)",
  },
  modalBtnCancelText: {
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_500Medium",
    fontSize: 15,
  },
  modalBtnConfirm: {
    backgroundColor: "#F97316",
  },
  modalBtnConfirmText: {
    color: "#FFFFFF",
    fontFamily: "Inter_600SemiBold",
    fontSize: 15,
  },
});
