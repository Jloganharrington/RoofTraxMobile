import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React from "react";
import {
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import { BETA_PURPLE, BETA_PURPLE_BG } from "@/utils/hailBeta";

// ---------------------------------------------------------------------------
// Photo detail view for a damage-instance photo. Read-only: displays the
// photo full-width and hosts the entry point to the standalone BETA hail
// analysis. Nothing here writes to InspectionContext or affects reports.
// ---------------------------------------------------------------------------

export default function PhotoDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { uri } = useLocalSearchParams<{ uri: string }>();

  const photoUri = typeof uri === "string" ? uri : "";

  const handleAnalyze = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({ pathname: "/hail-analysis", params: { photoUri } });
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 40 }}
    >
      {photoUri ? (
        <Image
          source={{ uri: photoUri }}
          style={[
            styles.photo,
            { width: width - 40, height: width - 40, borderRadius: colors.radius },
          ]}
          resizeMode="cover"
        />
      ) : (
        <View style={[styles.missing, { borderColor: colors.border, borderRadius: colors.radius }]}>
          <Feather name="image" size={28} color={colors.mutedForeground} />
          <Text style={[styles.missingText, { color: colors.mutedForeground }]}>
            Photo not found
          </Text>
        </View>
      )}

      {photoUri ? (
        <>
          {/* Visually distinct BETA entry point — purple, separated from the
              navy/orange Phase 2 UI. */}
          <TouchableOpacity
            onPress={handleAnalyze}
            activeOpacity={0.85}
            style={[styles.betaButton, { backgroundColor: BETA_PURPLE, borderRadius: colors.radius }]}
          >
            <Feather name="zap" size={18} color="#FFFFFF" />
            <Text style={styles.betaButtonText}>Analyze for Hail Indicators</Text>
            <View style={styles.betaChip}>
              <Text style={[styles.betaChipText, { color: BETA_PURPLE }]}>BETA</Text>
            </View>
          </TouchableOpacity>

          <View style={[styles.betaNote, { backgroundColor: BETA_PURPLE_BG, borderRadius: colors.radius }]}>
            <Feather name="info" size={14} color={BETA_PURPLE} />
            <Text style={[styles.betaNoteText, { color: BETA_PURPLE }]}>
              Experimental feature — results are shown only on the analysis screen and are never
              saved to this damage instance or included in reports.
            </Text>
          </View>
        </>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  photo: { backgroundColor: "#EEE", alignSelf: "center" },
  missing: {
    borderWidth: 2,
    borderStyle: "dashed",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
    gap: 10,
  },
  missingText: { fontSize: 14, fontFamily: "Inter_500Medium" },
  betaButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 15,
    marginTop: 20,
  },
  betaButtonText: { color: "#FFFFFF", fontSize: 15, fontFamily: "Inter_600SemiBold" },
  betaChip: {
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 6,
  },
  betaChipText: { fontSize: 10, fontFamily: "Inter_700Bold", letterSpacing: 1 },
  betaNote: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    padding: 12,
    marginTop: 12,
  },
  betaNoteText: { flex: 1, fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
});
