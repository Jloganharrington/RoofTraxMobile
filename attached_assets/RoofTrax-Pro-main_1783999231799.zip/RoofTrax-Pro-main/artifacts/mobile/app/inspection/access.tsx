import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useInspections, type AccessMethod } from "@/context/InspectionContext";
import { useColors } from "@/hooks/useColors";

const ACCESS_OPTIONS: {
  value: AccessMethod;
  label: string;
  description: string;
  icon: string;
  detail: string;
}[] = [
  {
    value: "drone",
    label: "Drone Inspection",
    description: "Aerial imagery captured via drone",
    icon: "wind",
    detail: "Bulk upload all drone-captured damage photos",
  },
  {
    value: "direct_access",
    label: "Direct-Access",
    description: "Physical access to roof or exterior",
    icon: "camera",
    detail: "Capture photos directly from within the app",
  },
];

export default function AccessScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { updateProfile } = useInspections();
  const [selected, setSelected] = useState<AccessMethod | null>(null);

  const handleSelect = (value: AccessMethod) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelected(value);
  };

  const handleNext = () => {
    if (!selected) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    updateProfile(id, { accessMethod: selected });
    if (selected === "drone") {
      router.push({ pathname: "/inspection/drone", params: { id } });
    } else {
      router.push({ pathname: "/inspection/camera", params: { id } });
    }
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.inner}>
        <View style={styles.stepRow}>
          {[1, 2, 3, 4].map((step, i) => (
            <View key={step}>
              <View
                style={[
                  styles.stepDot,
                  {
                    backgroundColor: i === 2 ? colors.accent : i < 2 ? colors.success : colors.muted,
                    width: i === 2 ? 24 : 8,
                    borderRadius: i === 2 ? 12 : 4,
                  },
                ]}
              />
            </View>
          ))}
        </View>

        <Text style={[styles.title, { color: colors.foreground }]}>Access Method</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          How were the damage photos taken? This determines the photo upload workflow.
        </Text>

        <View style={styles.optionList}>
          {ACCESS_OPTIONS.map((option) => {
            const isSelected = selected === option.value;
            return (
              <TouchableOpacity
                key={option.value}
                onPress={() => handleSelect(option.value)}
                activeOpacity={0.85}
                style={[
                  styles.optionCard,
                  {
                    backgroundColor: isSelected ? colors.primary : colors.card,
                    borderColor: isSelected ? colors.primary : colors.border,
                    borderRadius: colors.radius,
                  },
                ]}
              >
                <View
                  style={[
                    styles.optionIconWrap,
                    {
                      backgroundColor: isSelected ? "rgba(255,255,255,0.15)" : colors.secondary,
                    },
                  ]}
                >
                  <Feather
                    name={option.icon as any}
                    size={28}
                    color={isSelected ? "#FFFFFF" : colors.accent}
                  />
                </View>
                <View style={styles.optionBody}>
                  <Text
                    style={[
                      styles.optionLabel,
                      { color: isSelected ? "#FFFFFF" : colors.foreground },
                    ]}
                  >
                    {option.label}
                  </Text>
                  <Text
                    style={[
                      styles.optionDesc,
                      { color: isSelected ? "rgba(255,255,255,0.75)" : colors.mutedForeground },
                    ]}
                  >
                    {option.description}
                  </Text>
                  <View
                    style={[
                      styles.detailPill,
                      {
                        backgroundColor: isSelected
                          ? "rgba(255,255,255,0.12)"
                          : colors.secondary,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.detailText,
                        {
                          color: isSelected ? "rgba(255,255,255,0.9)" : colors.mutedForeground,
                        },
                      ]}
                    >
                      {option.detail}
                    </Text>
                  </View>
                </View>
                {isSelected && (
                  <Feather name="check-circle" size={24} color="#FFFFFF" />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      <View style={[styles.footer, { paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity
          onPress={handleNext}
          disabled={!selected}
          activeOpacity={0.85}
          style={[
            styles.nextButton,
            {
              backgroundColor: selected ? colors.accent : colors.muted,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Text
            style={[
              styles.nextButtonText,
              { color: selected ? "#FFFFFF" : colors.mutedForeground },
            ]}
          >
            Next
          </Text>
          <Feather
            name="arrow-right"
            size={20}
            color={selected ? "#FFFFFF" : colors.mutedForeground}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  inner: { flex: 1, paddingHorizontal: 24, paddingTop: 24, gap: 16 },
  stepRow: { flexDirection: "row", gap: 6, alignItems: "center", marginBottom: 8 },
  stepDot: { height: 8 },
  title: { fontSize: 26, fontFamily: "Inter_700Bold" },
  subtitle: { fontSize: 15, fontFamily: "Inter_400Regular", lineHeight: 22 },
  optionList: { gap: 16 },
  optionCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 20,
    borderWidth: 2,
    gap: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  optionIconWrap: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
  },
  optionBody: { flex: 1, gap: 6 },
  optionLabel: { fontSize: 18, fontFamily: "Inter_700Bold" },
  optionDesc: { fontSize: 14, fontFamily: "Inter_400Regular" },
  detailPill: {
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    marginTop: 4,
  },
  detailText: { fontSize: 12, fontFamily: "Inter_500Medium" },
  footer: { paddingHorizontal: 24, paddingTop: 12 },
  nextButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 10,
  },
  nextButtonText: { fontSize: 17, fontFamily: "Inter_600SemiBold" },
});
