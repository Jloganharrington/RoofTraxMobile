import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React from "react";
import {
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { isForensicIntakeComplete, useInspections } from "@/context/InspectionContext";
import { useSettings } from "@/context/SettingsContext";
import { useColors } from "@/hooks/useColors";
import { StatusBadge } from "@/components/StatusBadge";
import { WeatherEventsCard } from "@/components/WeatherEventsCard";

export default function InspectionDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getProfile, deleteProfile, updateProfile } = useInspections();
  const { settings } = useSettings();

  const profile = getProfile(id);

  if (!profile) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.centered}>
          <Feather name="alert-circle" size={48} color={colors.mutedForeground} />
          <Text style={[styles.notFoundText, { color: colors.mutedForeground }]}>
            Inspection not found
          </Text>
        </View>
      </View>
    );
  }

  const handleStartPhase1 = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({ pathname: "/inspection/front-photo", params: { id } });
  };

  const handleBeginForensic = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({ pathname: "/inspection/customer-claim", params: { id } });
  };

  const handleDelete = () => {
    Alert.alert(
      "Delete Inspection",
      "This will permanently delete this inspection profile and all associated data.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            deleteProfile(id);
            router.back();
          },
        },
      ]
    );
  };

  const handleViewReport = () => {
    router.push({ pathname: "/inspection/report", params: { id } });
  };

  const formattedDate = new Date(profile.createdAt).toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const scopeLabels: Record<string, string> = {
    roof_only: "Roof Only",
    siding_only: "Siding Only",
    roof_and_siding: "Roof & Siding",
  };

  const damageTypeLabels: Record<string, string> = {
    wind: "Wind",
    wind_hail: "Wind & Hail",
    hail: "Hail",
    tree: "Tree Impact",
    water_ice: "Water/Ice Damming",
  };

  const accessLabels: Record<string, string> = {
    drone: "Drone Inspection",
    direct_access: "Direct-Access",
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const intakeComplete = isForensicIntakeComplete(profile);

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingBottom: bottomPad + 24 }]}
    >
      {/* Header Card */}
      <View
        style={[
          styles.headerCard,
          { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border },
        ]}
      >
        <View style={styles.addressRow}>
          <View style={[styles.iconCircle, { backgroundColor: colors.secondary }]}>
            <Feather name="home" size={24} color={colors.accent} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.address, { color: colors.foreground }]}>
              {profile.address}
            </Text>
            <Text style={[styles.createdAt, { color: colors.mutedForeground }]}>
              {formattedDate}
            </Text>
          </View>
        </View>
        <StatusBadge status={profile.status} />
      </View>

      {/* Phase 1 Inspection */}
      <View
        style={[
          styles.phaseCard,
          { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border },
        ]}
      >
        <View style={styles.phaseHeader}>
          <View>
            <Text style={[styles.phaseTitle, { color: colors.foreground }]}>
              Phase 1 — Preliminary Inspection
            </Text>
            <Text style={[styles.phaseSubtitle, { color: colors.mutedForeground }]}>
              Guided photo documentation & damage assessment
            </Text>
          </View>
        </View>

        {/* Progress Details */}
        {profile.damageScope && (
          <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Damage Scope</Text>
            <Text style={[styles.detailValue, { color: colors.foreground }]}>
              {scopeLabels[profile.damageScope]}
            </Text>
          </View>
        )}
        {profile.damageType && (
          <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Damage Type</Text>
            <Text style={[styles.detailValue, { color: colors.foreground }]}>
              {damageTypeLabels[profile.damageType]}
            </Text>
          </View>
        )}

        {/* Storm & Weather History — nested under Phase 1, after Damage Type */}
        <View style={styles.nestedWeatherCard}>
          <WeatherEventsCard
            profile={profile}
            onWeatherEventsPersisted={(weatherEvents) => updateProfile(id, { weatherEvents })}
            onSelectedStormPersisted={(selectedStorm) => updateProfile(id, { selectedStorm })}
          />
        </View>

        {profile.accessMethod && (
          <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Access Method</Text>
            <Text style={[styles.detailValue, { color: colors.foreground }]}>
              {accessLabels[profile.accessMethod]}
            </Text>
          </View>
        )}
        {profile.damagePhotos.length > 0 && (
          <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Damage Photos</Text>
            <Text style={[styles.detailValue, { color: colors.foreground }]}>
              {profile.damagePhotos.length} photo{profile.damagePhotos.length !== 1 ? "s" : ""}
            </Text>
          </View>
        )}

        {profile.status === "report_ready" ? (
          <TouchableOpacity
            onPress={handleViewReport}
            activeOpacity={0.85}
            style={[
              styles.phaseButton,
              { backgroundColor: colors.success, borderRadius: colors.radius },
            ]}
          >
            <Feather name="file-text" size={20} color="#FFFFFF" />
            <Text style={[styles.phaseButtonText, { color: "#FFFFFF" }]}>View Report</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            onPress={handleStartPhase1}
            activeOpacity={0.85}
            style={[
              styles.phaseButton,
              { backgroundColor: colors.accent, borderRadius: colors.radius },
            ]}
          >
            <Feather name="clipboard" size={20} color="#FFFFFF" />
            <Text style={[styles.phaseButtonText, { color: "#FFFFFF" }]}>
              {profile.status === "in_progress"
                ? "Continue Phase 1 Inspection"
                : "Begin Phase 1 Inspection"}
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Phase 2 — Forensic Inspection gate */}
      <View
        style={[
          styles.phaseCard,
          { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border },
        ]}
      >
        <View style={[styles.phaseHeader, { flexDirection: "row", alignItems: "flex-start" }]}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.phaseTitle, { color: colors.foreground }]}>
              Phase 2 — Forensic Inspection
            </Text>
            <Text style={[styles.phaseSubtitle, { color: colors.mutedForeground }]}>
              {intakeComplete
                ? "Customer & claim details on file"
                : "Customer profile & claim details are required before the forensic inspection can begin"}
            </Text>
          </View>
          <View style={[styles.iconCircle, { backgroundColor: colors.secondary, width: 44, height: 44, borderRadius: 22 }]}>
            <Feather
              name={intakeComplete ? "check-circle" : "lock"}
              size={20}
              color={intakeComplete ? colors.success : colors.accent}
            />
          </View>
        </View>

        {intakeComplete ? (
          <>
            <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Customer</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]} numberOfLines={1}>
                {profile.customerName}
              </Text>
            </View>
            <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Phone</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]} numberOfLines={1}>
                {profile.customerPhone}
              </Text>
            </View>
            <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Email</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]} numberOfLines={1}>
                {profile.customerEmail}
              </Text>
            </View>
            <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Claim #</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]} numberOfLines={1}>
                {profile.claimNumber}
              </Text>
            </View>
            <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Carrier</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]} numberOfLines={1}>
                {profile.insuranceCarrier}
              </Text>
            </View>
            <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Adjuster</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]} numberOfLines={1}>
                {profile.adjusterName}
              </Text>
            </View>
            <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Adjuster Contact</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]} numberOfLines={1}>
                {profile.adjusterContact}
              </Text>
            </View>
            <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Date of Loss</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]} numberOfLines={1}>
                {profile.dateOfLoss}
              </Text>
            </View>
            <TouchableOpacity
              onPress={handleBeginForensic}
              activeOpacity={0.8}
              style={[
                styles.editDetailsButton,
                { borderColor: colors.border, borderRadius: colors.radius },
              ]}
            >
              <Feather name="edit-2" size={15} color={colors.accent} />
              <Text style={[styles.editDetailsText, { color: colors.accent }]}>
                Edit Customer & Claim Details
              </Text>
            </TouchableOpacity>
          </>
        ) : (
          <TouchableOpacity
            onPress={handleBeginForensic}
            activeOpacity={0.85}
            style={[
              styles.phaseButton,
              { backgroundColor: colors.accent, borderRadius: colors.radius },
            ]}
          >
            <Feather name="search" size={20} color="#FFFFFF" />
            <Text style={[styles.phaseButtonText, { color: "#FFFFFF" }]}>
              Begin Forensic Inspection
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Roof Documentation */}
      {(() => {
        if (!intakeComplete) return null;
        const slopes = profile.slopes ?? [];
        const totalInstances = slopes.reduce((n, s) => n + s.damageInstances.length, 0);
        const completeInstances = slopes.reduce(
          (n, s) => n + s.damageInstances.filter((d) => d.isComplete).length,
          0,
        );
        return (
          <View
            style={[
              styles.phaseCard,
              { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border },
            ]}
          >
            <View style={styles.phaseHeader}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.phaseTitle, { color: colors.foreground }]}>
                  Roof Documentation
                </Text>
                <Text style={[styles.phaseSubtitle, { color: colors.mutedForeground }]}>
                  Slopes, damage instances &amp; code citations
                </Text>
              </View>
              {slopes.length > 0 && (
                <View style={[styles.iconCircle, { backgroundColor: colors.secondary }]}>
                  <Text style={{ color: colors.accent, fontFamily: "Inter_700Bold", fontSize: 15 }}>
                    {slopes.length}
                  </Text>
                </View>
              )}
            </View>
            {slopes.length > 0 && (
              <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
                <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Damage Instances</Text>
                <Text style={[styles.detailValue, { color: colors.foreground }]}>
                  {completeInstances}/{totalInstances} complete
                </Text>
              </View>
            )}
            <TouchableOpacity
              onPress={() => router.push({ pathname: "/inspection/slopes", params: { id } })}
              activeOpacity={0.85}
              style={[
                styles.phaseButton,
                { backgroundColor: colors.primary, borderRadius: colors.radius },
              ]}
            >
              <Feather name="layers" size={20} color="#FFFFFF" />
              <Text style={[styles.phaseButtonText, { color: "#FFFFFF" }]}>
                {slopes.length === 0 ? "Start Roof Model" : "Open Roof Model"}
              </Text>
            </TouchableOpacity>
          </View>
        );
      })()}

      {/* Roofing Estimate */}
      {(() => {
        if (!intakeComplete) return null;
        const slopes = profile.slopes ?? [];
        if (slopes.length === 0) return null;

        const rate = settings.pricePerSq;
        const totalSq = slopes.reduce((sum, s) => sum + (s.squareFootage ?? 0), 0);
        const totalEst = rate != null ? totalSq * rate : null;

        const fmtSq = (n: number) =>
          n === 0 ? "—" : Number.isInteger(n) ? n.toString() : n.toFixed(1);
        const fmtUsd = (n: number) =>
          "$" + Math.round(n).toLocaleString("en-US");

        return (
          <View
            style={[
              styles.phaseCard,
              { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border },
            ]}
          >
            {/* Header */}
            <View style={styles.phaseHeader}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.phaseTitle, { color: colors.foreground }]}>
                  Roofing Estimate
                </Text>
                <Text style={[styles.phaseSubtitle, { color: colors.mutedForeground }]}>
                  {rate != null
                    ? `${fmtUsd(rate)} / SQ · enter SQ on each slope`
                    : "Set price/SQ in Settings to calculate"}
                </Text>
              </View>
              <View style={[styles.iconCircle, { backgroundColor: "#F0FDF4" }]}>
                <Feather name="dollar-sign" size={20} color={colors.success} />
              </View>
            </View>

            {/* No rate set */}
            {rate == null && (
              <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
                <Feather name="info" size={13} color={colors.mutedForeground} />
                <Text
                  style={[
                    styles.detailLabel,
                    { color: colors.mutedForeground, flex: 1, marginLeft: 6 },
                  ]}
                >
                  Go to Settings → Pricing to set your rate.
                </Text>
              </View>
            )}

            {/* Per-slope breakdown */}
            {rate != null && (
              <>
                {/* Column headers */}
                <View
                  style={[
                    styles.estimateHeaderRow,
                    { borderTopColor: colors.border, borderBottomColor: colors.border },
                  ]}
                >
                  <Text
                    style={[styles.estimateColSlope, { color: colors.mutedForeground }]}
                  >
                    SLOPE
                  </Text>
                  <Text
                    style={[styles.estimateColSq, { color: colors.mutedForeground }]}
                  >
                    SQ
                  </Text>
                  <Text
                    style={[styles.estimateColAmt, { color: colors.mutedForeground }]}
                  >
                    SUBTOTAL
                  </Text>
                </View>

                {slopes.map((s) => {
                  const sq = s.squareFootage ?? 0;
                  const sub = sq * rate;
                  return (
                    <View key={s.id} style={styles.estimateRow}>
                      <Text
                        style={[styles.estimateColSlope, { color: colors.foreground }]}
                        numberOfLines={1}
                      >
                        {s.label}
                      </Text>
                      <Text
                        style={[
                          styles.estimateColSq,
                          { color: sq > 0 ? colors.foreground : colors.mutedForeground },
                        ]}
                      >
                        {fmtSq(sq)}
                      </Text>
                      <Text
                        style={[
                          styles.estimateColAmt,
                          { color: sq > 0 ? colors.foreground : colors.mutedForeground },
                        ]}
                      >
                        {sq > 0 ? fmtUsd(sub) : "—"}
                      </Text>
                    </View>
                  );
                })}

                {/* Total row */}
                <View
                  style={[
                    styles.estimateTotalRow,
                    { borderTopColor: colors.border, backgroundColor: colors.secondary },
                  ]}
                >
                  <Text style={[styles.estimateColSlope, styles.estimateTotalText, { color: colors.foreground }]}>
                    TOTAL
                  </Text>
                  <Text style={[styles.estimateColSq, styles.estimateTotalText, { color: colors.foreground }]}>
                    {fmtSq(totalSq)}
                  </Text>
                  <Text style={[styles.estimateColAmt, styles.estimateTotalText, { color: colors.success }]}>
                    {totalSq > 0 && totalEst != null ? fmtUsd(totalEst) : "—"}
                  </Text>
                </View>
              </>
            )}
          </View>
        );
      })()}

      {/* Siding Documentation */}
      {(() => {
        if (!intakeComplete) return null;
        const elevations = profile.sidingElevations ?? [];
        const totalSiding = elevations.reduce((n, e) => n + e.damageInstances.length, 0);
        const completeSiding = elevations.reduce(
          (n, e) => n + e.damageInstances.filter((d) => d.isComplete).length,
          0,
        );
        return (
          <View
            style={[
              styles.phaseCard,
              { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border },
            ]}
          >
            <View style={styles.phaseHeader}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.phaseTitle, { color: colors.foreground }]}>
                  Siding Documentation
                </Text>
                <Text style={[styles.phaseSubtitle, { color: colors.mutedForeground }]}>
                  Elevations &amp; siding damage instances
                </Text>
              </View>
              {elevations.length > 0 && (
                <View style={[styles.iconCircle, { backgroundColor: colors.secondary }]}>
                  <Text style={{ color: colors.accent, fontFamily: "Inter_700Bold", fontSize: 15 }}>
                    {elevations.length}
                  </Text>
                </View>
              )}
            </View>
            {elevations.length > 0 && (
              <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
                <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Damage Instances</Text>
                <Text style={[styles.detailValue, { color: colors.foreground }]}>
                  {completeSiding}/{totalSiding} complete
                </Text>
              </View>
            )}
            <TouchableOpacity
              onPress={() =>
                router.push({ pathname: "/inspection/siding-elevations", params: { id } })
              }
              activeOpacity={0.85}
              style={[
                styles.phaseButton,
                { backgroundColor: colors.primary, borderRadius: colors.radius },
              ]}
            >
              <Feather name="grid" size={20} color="#FFFFFF" />
              <Text style={[styles.phaseButtonText, { color: "#FFFFFF" }]}>
                {elevations.length === 0 ? "Start Siding Model" : "Open Siding Model"}
              </Text>
            </TouchableOpacity>
          </View>
        );
      })()}

      {/* Delete */}
      <TouchableOpacity
        onPress={handleDelete}
        activeOpacity={0.8}
        style={[styles.deleteButton, { borderColor: colors.destructive, borderRadius: colors.radius }]}
      >
        <Feather name="trash-2" size={16} color={colors.destructive} />
        <Text style={[styles.deleteText, { color: colors.destructive }]}>Delete Inspection</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20, gap: 16 },
  centered: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  notFoundText: { fontSize: 16, fontFamily: "Inter_400Regular" },
  headerCard: {
    padding: 20,
    borderWidth: 1,
    gap: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  addressRow: { flexDirection: "row", gap: 16, alignItems: "flex-start" },
  iconCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: "center",
    justifyContent: "center",
  },
  address: {
    fontSize: 17,
    fontFamily: "Inter_600SemiBold",
    lineHeight: 24,
    marginBottom: 4,
  },
  createdAt: { fontSize: 13, fontFamily: "Inter_400Regular" },
  phaseCard: {
    borderWidth: 1,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  phaseHeader: {
    padding: 20,
    gap: 4,
  },
  nestedWeatherCard: {
    marginHorizontal: 16,
    marginBottom: 12,
  },
  phaseTitle: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    marginBottom: 4,
  },
  phaseSubtitle: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    lineHeight: 18,
  },
  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderTopWidth: 1,
  },
  detailLabel: { fontSize: 14, fontFamily: "Inter_400Regular" },
  detailValue: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  phaseButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 10,
    margin: 16,
  },
  phaseButtonText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  deleteButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 14,
    gap: 8,
    borderWidth: 1,
  },
  deleteText: {
    fontSize: 15,
    fontFamily: "Inter_500Medium",
  },
  editDetailsButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 12,
    gap: 8,
    borderWidth: 1,
    margin: 16,
  },
  editDetailsText: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  // Estimate table
  estimateHeaderRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderTopWidth: 1,
    borderBottomWidth: 1,
  },
  estimateRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  estimateTotalRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  estimateColSlope: { flex: 1, fontSize: 12, fontFamily: "Inter_500Medium" },
  estimateColSq: { width: 52, fontSize: 12, fontFamily: "Inter_500Medium", textAlign: "right" },
  estimateColAmt: { width: 80, fontSize: 12, fontFamily: "Inter_500Medium", textAlign: "right" },
  estimateTotalText: { fontSize: 13, fontFamily: "Inter_700Bold" },
});
