import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  type Annotation,
  type InspectionProfile,
  type RoofSlope,
  type SidingElevationEntry,
  useInspections,
} from "@/context/InspectionContext";
import { useSettings } from "@/context/SettingsContext";
import { useColors } from "@/hooks/useColors";
import { CODE_CITATIONS } from "@/constants/codeCitations";

// ---------------------------------------------------------------------------
// Code citation lookup
// ---------------------------------------------------------------------------
const CODE_CITATION_MAP = Object.fromEntries(CODE_CITATIONS.map((c) => [c.id, c]));

// ---------------------------------------------------------------------------
// Label maps
// ---------------------------------------------------------------------------
const SCOPE_LABELS: Record<string, string> = {
  roof_only: "Roof Only",
  siding_only: "Siding Only",
  roof_and_siding: "Roof & Siding",
};

const ACCESS_LABELS: Record<string, string> = {
  drone: "Drone Inspection",
  direct_access: "Direct-Access",
};

const ROOF_DAMAGE_TYPE_LABELS: Record<string, string> = {
  hail: "Hail",
  wind: "Wind",
  wind_hail: "Wind + Hail",
  tree: "Tree Impact",
  water_ice: "Water / Ice",
  other: "Other",
};

const SIDING_DAMAGE_TYPE_LABELS: Record<string, string> = {
  hail: "Hail",
  wind: "Wind",
  impact: "Impact",
  water: "Water Intrusion",
  other: "Other",
};

const SEVERITY_LABELS: Record<string, string> = {
  minor: "Minor",
  moderate: "Moderate",
  severe: "Severe",
};

const DECKING_LABELS: Record<string, string> = {
  solid: "Solid",
  soft_spots: "Soft Spots",
  rot: "Rot",
  delamination: "Delamination",
};

const ELEVATION_FACE_LABELS: Record<string, string> = {
  front: "Front",
  back: "Back",
  left: "Left",
  right: "Right",
  other: "Other",
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function fmtSq(n: number): string {
  if (n === 0) return "—";
  return Number.isInteger(n) ? n.toString() : n.toFixed(1);
}

function fmtUsd(n: number): string {
  return "$" + Math.round(n).toLocaleString("en-US");
}

// ---------------------------------------------------------------------------
// HTML section builders
// ---------------------------------------------------------------------------
function causeOfLossHtml(profile: InspectionProfile): string {
  const storm = profile.selectedStorm;
  if (!storm) return "";

  const longDate = new Date(storm.date + "T00:00:00").toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  const hail = storm.hailSize != null ? `${storm.hailSize.toFixed(2)}"` : "N/A";
  const wind = storm.windSpeed != null ? `${Math.round(storm.windSpeed)} mph` : "N/A";
  const distance = storm.distance != null ? `${storm.distance.toFixed(1)} mi` : "N/A";
  const probability = storm.probability != null ? `${Math.round(storm.probability)}%` : "N/A";

  const reasonHtml = storm.reason ? `<p class="storm-reason">${escapeHtml(storm.reason)}</p>` : "";
  const descriptionHtml = storm.description
    ? `<div class="storm-description">
         <div class="storm-description-label">Official Weather Report</div>
         <p>${escapeHtml(storm.description)}</p>
       </div>`
    : "";

  return `<div class="section">
    <div class="section-title">Cause of Loss — Storm Event</div>
    <div class="storm-card">
      <div class="storm-date">${longDate}</div>
      <div class="storm-metrics">
        <div class="storm-metric">
          <div class="storm-metric-label">Hail Size</div>
          <div class="storm-metric-value">${hail}</div>
        </div>
        <div class="storm-metric">
          <div class="storm-metric-label">Wind Speed</div>
          <div class="storm-metric-value">${wind}</div>
        </div>
        <div class="storm-metric">
          <div class="storm-metric-label">Distance</div>
          <div class="storm-metric-value">${distance}</div>
        </div>
        <div class="storm-metric">
          <div class="storm-metric-label">Match Probability</div>
          <div class="storm-metric-value">${probability}</div>
        </div>
      </div>
      ${reasonHtml}
      ${descriptionHtml}
    </div>
  </div>`;
}

function annotationsToSvgHtml(annotations: Annotation[]): string {
  if (!annotations || annotations.length === 0) return "";
  const elements = annotations
    .map((a) => {
      const sw = a.strokeWidth ?? 6;
      const c = a.color ?? "#EF4444";
      if (a.tool === "arrow" && a.x1 != null && a.y1 != null && a.x2 != null && a.y2 != null) {
        const len = 30;
        const angle = Math.atan2(a.y2 - a.y1, a.x2 - a.x1);
        const pts = [
          `${a.x2},${a.y2}`,
          `${a.x2 - len * Math.cos(angle - Math.PI / 6)},${a.y2 - len * Math.sin(angle - Math.PI / 6)}`,
          `${a.x2 - len * Math.cos(angle + Math.PI / 6)},${a.y2 - len * Math.sin(angle + Math.PI / 6)}`,
        ].join(" ");
        return `<line x1="${a.x1}" y1="${a.y1}" x2="${a.x2}" y2="${a.y2}" stroke="${c}" stroke-width="${sw}" stroke-linecap="round"/><polygon points="${pts}" fill="${c}"/>`;
      }
      if (a.tool === "circle" && a.cx != null && a.cy != null && a.r != null) {
        return `<circle cx="${a.cx}" cy="${a.cy}" r="${a.r}" stroke="${c}" stroke-width="${sw}" fill="none"/>`;
      }
      if (a.tool === "rect" && a.x != null && a.y != null && a.width != null && a.height != null) {
        return `<rect x="${a.x}" y="${a.y}" width="${a.width}" height="${a.height}" stroke="${c}" stroke-width="${sw}" fill="none" rx="4"/>`;
      }
      if (a.tool === "freehand" && a.points && a.points.length > 1) {
        const d = a.points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");
        return `<path d="${d}" stroke="${c}" stroke-width="${sw}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
      }
      if (a.tool === "text" && a.text && a.x != null && a.y != null) {
        const escaped = a.text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        return `<text x="${a.x}" y="${a.y}" fill="${c}" font-size="${a.fontSize ?? 40}" font-weight="bold" font-family="Arial,sans-serif">${escaped}</text>`;
      }
      return "";
    })
    .filter(Boolean)
    .join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 750" style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;">${elements}</svg>`;
}

function roofingSectionHtml(
  slopes: RoofSlope[],
  photoBase64Map: Record<string, string>,
): string {
  const title = `Roof Documentation (${slopes.length} Slope${slopes.length !== 1 ? "s" : ""})`;

  if (slopes.length === 0) {
    return `<div class="section"><div class="section-title">${title}</div><p class="no-data">No roof slopes documented.</p></div>`;
  }

  const slopesHtml = slopes
    .map((slope) => {
      const sqLabel =
        slope.squareFootage != null ? `${fmtSq(slope.squareFootage)} SQ` : "SQ not entered";

      const instancesHtml =
        slope.damageInstances.length === 0
          ? `<div class="instance-block"><p class="no-data">No damage instances documented on this slope.</p></div>`
          : slope.damageInstances
              .map((di, idx) => {
                const typeLabel = ROOF_DAMAGE_TYPE_LABELS[di.damageType] ?? di.damageType;
                const sevLabel = SEVERITY_LABELS[di.severity] ?? di.severity;
                const statusBadge = di.isComplete
                  ? `<span class="badge badge-complete">&#10003; Complete</span>`
                  : `<span class="badge badge-draft">Draft</span>`;

                const metaItems: string[] = [];
                if (di.deckingCondition) {
                  metaItems.push(
                    `<span class="meta-item"><strong>Decking:</strong> ${escapeHtml(DECKING_LABELS[di.deckingCondition] ?? di.deckingCondition)}</span>`,
                  );
                }
                if (di.discontinuedProduct) {
                  const note = di.discontinuedProductNote
                    ? `: ${escapeHtml(di.discontinuedProductNote)}`
                    : "";
                  metaItems.push(
                    `<span class="meta-item"><strong>Discontinued Product${note}</strong></span>`,
                  );
                }
                const metaHtml =
                  metaItems.length > 0
                    ? `<div class="instance-meta">${metaItems.join("")}</div>`
                    : "";

                const causationHtml = di.causationNote
                  ? `<div class="causation-note">${escapeHtml(di.causationNote)}</div>`
                  : "";

                const citationsHtml =
                  di.codeCitationIds.length > 0
                    ? `<div class="citations-block">
                        <div class="citations-label">Code Citations</div>
                        ${di.codeCitationIds
                          .map((citId) => {
                            const cit = CODE_CITATION_MAP[citId];
                            if (!cit) return "";
                            return `<div class="citation-item">
                              <span class="citation-code">${escapeHtml(cit.code)} ${escapeHtml(cit.section)}</span>
                              <span class="citation-text"><strong>${escapeHtml(cit.title)}</strong> — ${escapeHtml(cit.description)}</span>
                            </div>`;
                          })
                          .join("")}
                      </div>`
                    : "";

                const photosHtml =
                  di.photos.length > 0
                    ? `<div class="instance-photos">${di.photos
                        .map((uri) => {
                          const src = photoBase64Map[uri];
                          if (!src) return "";
                          return `<img class="instance-photo" src="${src}" alt="Roof damage photo" />`;
                        })
                        .filter(Boolean)
                        .join("")}</div>`
                    : "";

                return `<div class="instance-block">
                  <div class="instance-title-row">
                    <span class="instance-num">Instance ${idx + 1}</span>
                    <span class="badge badge-type">${escapeHtml(typeLabel)}</span>
                    <span class="badge badge-${di.severity}">${escapeHtml(sevLabel)}</span>
                    ${statusBadge}
                  </div>
                  ${metaHtml}
                  ${causationHtml}
                  ${citationsHtml}
                  ${photosHtml}
                </div>`;
              })
              .join("");

      return `<div class="slope-block">
        <div class="slope-header">
          <span>${escapeHtml(slope.label)}</span>
          <span class="slope-sq">${escapeHtml(sqLabel)}</span>
        </div>
        ${instancesHtml}
      </div>`;
    })
    .join("");

  return `<div class="section">
    <div class="section-title">${title}</div>
    ${slopesHtml}
  </div>`;
}

function sidingSectionHtml(
  elevations: SidingElevationEntry[],
  photoBase64Map: Record<string, string>,
): string {
  const title = `Siding Documentation (${elevations.length} Elevation${elevations.length !== 1 ? "s" : ""})`;

  if (elevations.length === 0) {
    return `<div class="section"><div class="section-title">${title}</div><p class="no-data">No siding elevations documented.</p></div>`;
  }

  const elevsHtml = elevations
    .map((elev) => {
      const faceLabel = ELEVATION_FACE_LABELS[elev.elevation] ?? elev.elevation;

      const instancesHtml =
        elev.damageInstances.length === 0
          ? `<div class="instance-block"><p class="no-data">No damage instances documented on this elevation.</p></div>`
          : elev.damageInstances
              .map((di, idx) => {
                const typeLabel = SIDING_DAMAGE_TYPE_LABELS[di.damageType] ?? di.damageType;
                const sevLabel = SEVERITY_LABELS[di.severity] ?? di.severity;
                const statusBadge = di.isComplete
                  ? `<span class="badge badge-complete">&#10003; Complete</span>`
                  : `<span class="badge badge-draft">Draft</span>`;

                const causationHtml = di.causationNote
                  ? `<div class="causation-note">${escapeHtml(di.causationNote)}</div>`
                  : "";

                const photosHtml =
                  di.photos.length > 0
                    ? `<div class="instance-photos">${di.photos
                        .map((uri) => {
                          const src = photoBase64Map[uri];
                          if (!src) return "";
                          return `<img class="instance-photo" src="${src}" alt="Siding damage photo" />`;
                        })
                        .filter(Boolean)
                        .join("")}</div>`
                    : "";

                return `<div class="instance-block">
                  <div class="instance-title-row">
                    <span class="instance-num">Instance ${idx + 1}</span>
                    <span class="badge badge-type">${escapeHtml(typeLabel)}</span>
                    <span class="badge badge-${di.severity}">${escapeHtml(sevLabel)}</span>
                    ${statusBadge}
                  </div>
                  ${causationHtml}
                  ${photosHtml}
                </div>`;
              })
              .join("");

      return `<div class="slope-block">
        <div class="slope-header">
          <span>${escapeHtml(elev.label)}</span>
          <span class="slope-sq">${escapeHtml(faceLabel)} Face</span>
        </div>
        ${instancesHtml}
      </div>`;
    })
    .join("");

  return `<div class="section">
    <div class="section-title">${title}</div>
    ${elevsHtml}
  </div>`;
}

function estimateSectionHtml(slopes: RoofSlope[], pricePerSq: number | undefined): string {
  if (slopes.length === 0 || pricePerSq == null) return "";

  const totalSq = slopes.reduce((s, slope) => s + (slope.squareFootage ?? 0), 0);
  const totalEst = totalSq * pricePerSq;

  const rows = slopes
    .map((slope) => {
      const sq = slope.squareFootage ?? 0;
      const sub = sq * pricePerSq;
      return `<tr>
        <td>${escapeHtml(slope.label)}</td>
        <td style="text-align:right">${fmtSq(sq)}</td>
        <td style="text-align:right">${sq > 0 ? escapeHtml(fmtUsd(sub)) : "—"}</td>
      </tr>`;
    })
    .join("");

  return `<div class="section">
    <div class="section-title">Roofing Estimate — ${escapeHtml(fmtUsd(pricePerSq))} / SQ</div>
    <table class="estimate-table">
      <thead>
        <tr>
          <th>Slope</th>
          <th style="text-align:right">SQ</th>
          <th style="text-align:right">Subtotal</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
      <tfoot>
        <tr class="estimate-total">
          <td><strong>TOTAL</strong></td>
          <td style="text-align:right">${fmtSq(totalSq)}</td>
          <td style="text-align:right;color:#16A34A;">${totalSq > 0 ? escapeHtml(fmtUsd(totalEst)) : "—"}</td>
        </tr>
      </tfoot>
    </table>
  </div>`;
}

// ---------------------------------------------------------------------------
// Main screen
// ---------------------------------------------------------------------------
export default function ReportScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getProfile, getProfileNow, updateProfile } = useInspections();
  const { settings } = useSettings();
  const [generating, setGenerating] = useState(false);
  const [viewing, setViewing] = useState(false);
  const profile = getProfile(id);
  const [reportUri, setReportUri] = useState<string | null>(
    () => getProfileNow(id)?.reportUri ?? null,
  );
  const isTablet = width >= 768;
  const numCols = isTablet ? 4 : 3;
  const photoSize = (width - 48 - (numCols - 1) * 8) / numCols;

  if (!profile) {
    return (
      <View style={[styles.centered, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground }}>Inspection not found</Text>
      </View>
    );
  }

  const allPhotos = profile.frontPhoto
    ? [profile.frontPhoto, ...profile.damagePhotos]
    : profile.damagePhotos;

  // Count model data for the summary card
  const slopeCount = profile.slopes?.length ?? 0;
  const elevationCount = profile.sidingElevations?.length ?? 0;
  const roofingDamageCount =
    profile.slopes?.reduce((n, s) => n + s.damageInstances.length, 0) ?? 0;
  const sidingDamageCount =
    profile.sidingElevations?.reduce((n, e) => n + e.damageInstances.length, 0) ?? 0;

  const handleGenerateReport = async () => {
    if (Platform.OS === "web") {
      Alert.alert("PDF Generation", "PDF report generation is available on iOS and Android devices.");
      return;
    }

    setGenerating(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const Print = require("expo-print");
      const FileSystem = require("expo-file-system");
      const Sharing = require("expo-sharing");

      const snapshot: InspectionProfile | undefined = getProfileNow(id);
      if (!snapshot) {
        Alert.alert("Error", "Inspection data not found. Please go back and try again.");
        setGenerating(false);
        return;
      }

      const ensureReadableUri = async (uri: string): Promise<string> => {
        try {
          if (!uri) return uri;
          const docDir: string = FileSystem.documentDirectory ?? "";
          const filename = uri.split("/").pop() ?? `photo_${Date.now()}.jpg`;
          const destUri = `${docDir}insp_${filename}`;
          const info = await FileSystem.getInfoAsync(destUri);
          if (!info.exists) {
            await FileSystem.copyAsync({ from: uri, to: destUri });
          }
          return destUri;
        } catch {
          return uri;
        }
      };

      const toBase64 = async (uri: string): Promise<string> => {
        try {
          const readableUri = await ensureReadableUri(uri);
          const base64 = await FileSystem.readAsStringAsync(readableUri, {
            encoding: FileSystem.EncodingType.Base64,
          });
          return `data:image/jpeg;base64,${base64}`;
        } catch {
          return "";
        }
      };

      // ---- Standard photo processing ----
      const logoDataUri = settings.companyLogo ? await toBase64(settings.companyLogo) : null;
      const frontPhotoDataUri = snapshot.frontPhoto ? await toBase64(snapshot.frontPhoto) : null;
      const damagePhotoItems = (
        await Promise.all(
          snapshot.damagePhotos.map(async (uri) => {
            const dataUri = await toBase64(uri);
            const annotations = snapshot.photoAnnotations?.[uri] ?? [];
            return { dataUri, annotations };
          }),
        )
      ).filter((item) => Boolean(item.dataUri));

      // ---- Collect & convert all model (roofing + siding) photos ----
      const modelPhotoUris: string[] = [];
      for (const slope of snapshot.slopes ?? []) {
        for (const di of slope.damageInstances) {
          modelPhotoUris.push(...di.photos);
        }
      }
      for (const elev of snapshot.sidingElevations ?? []) {
        for (const di of elev.damageInstances) {
          modelPhotoUris.push(...di.photos);
        }
      }
      const uniqueModelUris = [...new Set(modelPhotoUris)];
      const photoBase64Map: Record<string, string> = {};
      await Promise.all(
        uniqueModelUris.map(async (uri) => {
          const dataUri = await toBase64(uri);
          if (dataUri) photoBase64Map[uri] = dataUri;
        }),
      );

      // ---- Build HTML sections ----
      const date = new Date(snapshot.createdAt).toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      });

      const logoHtml = logoDataUri
        ? `<img class="logo" src="${logoDataUri}" alt="Company Logo" />`
        : `<div class="logo-placeholder">${escapeHtml(settings.companyName)}</div>`;

      const frontPhotoHtml = frontPhotoDataUri
        ? `<div class="section">
            <div class="section-title">Front of Property</div>
            <img class="front-photo" src="${frontPhotoDataUri}" alt="Front of Home" />
           </div>`
        : "";

      const damagePhotosHtml =
        damagePhotoItems.length > 0
          ? `<div class="section">
              <div class="section-title">Phase 1 Damage Photos (${damagePhotoItems.length})</div>
              <div class="photo-grid">
                ${damagePhotoItems
                  .map(({ dataUri, annotations }) => {
                    const svgOverlay = annotationsToSvgHtml(annotations);
                    return `<div class="photo-wrapper"><img class="damage-photo" src="${dataUri}" alt="Damage photo" />${svgOverlay}</div>`;
                  })
                  .join("")}
              </div>
             </div>`
          : "";

      const roofHtml = roofingSectionHtml(snapshot.slopes ?? [], photoBase64Map);
      const estimateHtml = estimateSectionHtml(snapshot.slopes ?? [], settings.pricePerSq);
      const sidingHtml = sidingSectionHtml(snapshot.sidingElevations ?? [], photoBase64Map);

      const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, 'Helvetica Neue', Arial, sans-serif; color: #1E3A5F; background: #fff; }
  .page { padding: 32px; max-width: 900px; margin: 0 auto; }
  /* Header */
  .header { display: flex; align-items: center; border-bottom: 3px solid #F97316; padding-bottom: 24px; margin-bottom: 28px; gap: 20px; }
  .logo { width: 72px; height: 72px; object-fit: contain; border-radius: 8px; }
  .logo-placeholder { width: 72px; height: 72px; background: #1E3A5F; color: white; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold; border-radius: 8px; text-align: center; padding: 8px; }
  .header-text .report-type { font-size: 11px; font-weight: 700; color: #F97316; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 4px; }
  .header-text h1 { font-size: 24px; font-weight: 800; color: #1E3A5F; line-height: 1.2; }
  .header-text .company { font-size: 14px; color: #6B7280; margin-top: 4px; }
  /* Info grid */
  .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 28px; }
  .info-card { background: #F4F5F7; border-radius: 8px; padding: 14px 16px; }
  .info-card .info-label { font-size: 11px; font-weight: 700; color: #F97316; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 4px; }
  .info-card .info-value { font-size: 15px; font-weight: 600; color: #1E3A5F; line-height: 1.4; }
  /* Section */
  .section { margin-bottom: 28px; }
  .section-title { font-size: 13px; font-weight: 700; color: #F97316; letter-spacing: 1.5px; text-transform: uppercase; border-bottom: 1px solid #E5E7EB; padding-bottom: 8px; margin-bottom: 14px; }
  /* Phase 1 photos */
  .front-photo { width: 100%; max-height: 320px; object-fit: cover; border-radius: 8px; }
  .photo-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
  .photo-wrapper { position: relative; display: block; }
  .damage-photo { width: 100%; aspect-ratio: 4/3; object-fit: cover; border-radius: 6px; display: block; }
  /* Storm card */
  .storm-card { background: #F4F5F7; border-left: 4px solid #F97316; border-radius: 8px; padding: 16px 18px; }
  .storm-date { font-size: 16px; font-weight: 700; color: #1E3A5F; margin-bottom: 12px; }
  .storm-metrics { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 12px; }
  .storm-metric-label { font-size: 10px; font-weight: 700; color: #F97316; letter-spacing: 0.5px; text-transform: uppercase; margin-bottom: 2px; }
  .storm-metric-value { font-size: 15px; font-weight: 700; color: #1E3A5F; }
  .storm-reason { font-size: 13px; color: #1E3A5F; line-height: 1.5; margin-bottom: 10px; }
  .storm-description { border-top: 1px solid #D1D5DB; padding-top: 10px; }
  .storm-description-label { font-size: 10px; font-weight: 700; color: #6B7280; letter-spacing: 0.5px; text-transform: uppercase; margin-bottom: 4px; }
  .storm-description p { font-size: 12px; color: #6B7280; line-height: 1.5; white-space: pre-line; }
  /* Slope / elevation blocks */
  .slope-block { margin-bottom: 16px; border: 1px solid #E5E7EB; border-radius: 8px; overflow: hidden; }
  .slope-header { background: #1E3A5F; color: white; padding: 10px 16px; font-size: 13px; font-weight: 700; display: flex; justify-content: space-between; align-items: center; }
  .slope-sq { font-size: 12px; color: #F97316; font-weight: 600; }
  /* Damage instances */
  .instance-block { padding: 14px 16px; }
  .instance-block + .instance-block { border-top: 1px solid #F3F4F6; }
  .instance-num { font-size: 12px; font-weight: 700; color: #374151; }
  .instance-title-row { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
  /* Badges */
  .badge { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }
  .badge-type { background: #EFF6FF; color: #1E40AF; }
  .badge-minor { background: #EFF6FF; color: #1D4ED8; }
  .badge-moderate { background: #FFF7ED; color: #C2410C; }
  .badge-severe { background: #FEF2F2; color: #B91C1C; }
  .badge-complete { background: #F0FDF4; color: #166534; }
  .badge-draft { background: #F9FAFB; color: #6B7280; border: 1px solid #E5E7EB; }
  /* Meta row */
  .instance-meta { display: flex; flex-wrap: wrap; gap: 16px; margin-bottom: 10px; }
  .meta-item { font-size: 12px; color: #6B7280; }
  .meta-item strong { color: #1E3A5F; }
  /* Causation note */
  .causation-note { font-size: 12px; color: #374151; line-height: 1.5; background: #FFFBEB; border-left: 3px solid #F97316; padding: 8px 12px; border-radius: 0 4px 4px 0; margin-bottom: 10px; font-style: italic; }
  /* Code citations */
  .citations-block { margin-bottom: 10px; }
  .citations-label { font-size: 10px; font-weight: 700; color: #6B7280; letter-spacing: 0.5px; text-transform: uppercase; margin-bottom: 6px; }
  .citation-item { display: flex; gap: 8px; align-items: flex-start; margin-bottom: 5px; }
  .citation-code { font-size: 10px; font-weight: 700; color: white; background: #1E3A5F; padding: 2px 8px; border-radius: 4px; white-space: nowrap; flex-shrink: 0; }
  .citation-text { font-size: 11px; color: #374151; line-height: 1.5; }
  /* Instance photos */
  .instance-photos { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; margin-top: 10px; }
  .instance-photo { width: 100%; aspect-ratio: 4/3; object-fit: cover; border-radius: 6px; display: block; }
  /* Estimate table */
  .estimate-table { width: 100%; border-collapse: collapse; border-radius: 8px; overflow: hidden; border: 1px solid #E5E7EB; }
  .estimate-table th { background: #1E3A5F; color: white; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; padding: 10px 16px; text-align: left; }
  .estimate-table td { padding: 10px 16px; font-size: 13px; border-bottom: 1px solid #E5E7EB; color: #1E3A5F; }
  .estimate-table tr:last-child td { border-bottom: none; }
  .estimate-total td { background: #F4F5F7; font-weight: 700; border-top: 2px solid #1E3A5F !important; }
  /* Misc */
  .no-data { font-size: 13px; color: #9CA3AF; font-style: italic; padding: 4px 0; }
  /* Footer */
  .footer { border-top: 1px solid #E5E7EB; padding-top: 16px; margin-top: 32px; font-size: 11px; color: #9CA3AF; display: flex; justify-content: space-between; }
  @media print { body { -webkit-print-color-adjust: exact; } }
</style>
</head>
<body>
<div class="page">
  <div class="header">
    ${logoHtml}
    <div class="header-text">
      <div class="report-type">Storm Damage Assessment Report</div>
      <h1>Preliminary Damage Documentation</h1>
      <div class="company">${escapeHtml(settings.companyName)}</div>
    </div>
  </div>
  
  <div class="info-grid">
    <div class="info-card" style="grid-column: 1 / -1;">
      <div class="info-label">Property Address</div>
      <div class="info-value">${escapeHtml(snapshot.address)}</div>
    </div>
    <div class="info-card">
      <div class="info-label">Inspector</div>
      <div class="info-value">${escapeHtml(settings.userName)}</div>
    </div>
    <div class="info-card">
      <div class="info-label">Inspection Date</div>
      <div class="info-value">${date}</div>
    </div>
    <div class="info-card">
      <div class="info-label">Damage Scope</div>
      <div class="info-value">${snapshot.damageScope ? escapeHtml(SCOPE_LABELS[snapshot.damageScope] ?? snapshot.damageScope) : "Not specified"}</div>
    </div>
    <div class="info-card">
      <div class="info-label">Access Method</div>
      <div class="info-value">${snapshot.accessMethod ? escapeHtml(ACCESS_LABELS[snapshot.accessMethod] ?? snapshot.accessMethod) : "Not specified"}</div>
    </div>
  </div>

  ${causeOfLossHtml(snapshot)}
  ${roofHtml}
  ${estimateHtml}
  ${sidingHtml}
  ${frontPhotoHtml}
  ${damagePhotosHtml}

  <div class="footer">
    <span>Generated by ${escapeHtml(settings.companyName)}</span>
    <span>Preliminary Storm Damage Assessment</span>
    <span>${new Date().toLocaleDateString()}</span>
  </div>
</div>
</body>
</html>`;

      const { uri } = await Print.printToFileAsync({ html, base64: false });
      setReportUri(uri);
      updateProfile(id, { reportUri: uri, status: "report_ready" });

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(uri, {
          mimeType: "application/pdf",
          dialogTitle: "Share Damage Assessment Report",
          UTI: "com.adobe.pdf",
        });
      }
    } catch (error) {
      console.error("Report generation error:", error);
      Alert.alert("Error", "Failed to generate the report. Please try again.");
    } finally {
      setGenerating(false);
    }
  };

  const handleViewReport = async () => {
    if (!reportUri) return;
    if (Platform.OS === "web") {
      Alert.alert("View Report", "Open the app on iOS or Android to view the PDF report.");
      return;
    }
    setViewing(true);
    try {
      const Print = require("expo-print");
      await Print.printAsync({ uri: reportUri });
    } catch {
      Alert.alert("Error", "Unable to open the report viewer. Try sharing instead.");
    } finally {
      setViewing(false);
    }
  };

  const handleShare = async () => {
    if (!reportUri) return;
    try {
      const Sharing = require("expo-sharing");
      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(reportUri, {
          mimeType: "application/pdf",
          dialogTitle: "Share Damage Assessment Report",
          UTI: "com.adobe.pdf",
        });
      }
    } catch {
      Alert.alert("Error", "Unable to share the report.");
    }
  };

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingBottom: bottomPad + 24 }]}
    >
      {/* Summary Card */}
      <View
        style={[
          styles.summaryCard,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
            borderRadius: colors.radius,
          },
        ]}
      >
        <View style={[styles.reportBadge, { backgroundColor: colors.primary }]}>
          <Feather name="file-text" size={18} color="#FFFFFF" />
          <Text style={styles.reportBadgeText}>Storm Damage Assessment</Text>
        </View>

        <Text style={[styles.address, { color: colors.foreground }]}>{profile.address}</Text>

        <View style={styles.detailGrid}>
          <View
            style={[
              styles.detailItem,
              { backgroundColor: colors.secondary, borderRadius: colors.radius / 2 },
            ]}
          >
            <Text style={[styles.detailItemLabel, { color: colors.mutedForeground }]}>
              Inspector
            </Text>
            <Text style={[styles.detailItemValue, { color: colors.foreground }]}>
              {settings.userName}
            </Text>
          </View>
          <View
            style={[
              styles.detailItem,
              { backgroundColor: colors.secondary, borderRadius: colors.radius / 2 },
            ]}
          >
            <Text style={[styles.detailItemLabel, { color: colors.mutedForeground }]}>Date</Text>
            <Text style={[styles.detailItemValue, { color: colors.foreground }]}>
              {new Date(profile.createdAt).toLocaleDateString()}
            </Text>
          </View>
          <View
            style={[
              styles.detailItem,
              { backgroundColor: colors.secondary, borderRadius: colors.radius / 2 },
            ]}
          >
            <Text style={[styles.detailItemLabel, { color: colors.mutedForeground }]}>Scope</Text>
            <Text style={[styles.detailItemValue, { color: colors.foreground }]}>
              {profile.damageScope ? SCOPE_LABELS[profile.damageScope] : "-"}
            </Text>
          </View>
          <View
            style={[
              styles.detailItem,
              { backgroundColor: colors.secondary, borderRadius: colors.radius / 2 },
            ]}
          >
            <Text style={[styles.detailItemLabel, { color: colors.mutedForeground }]}>Access</Text>
            <Text style={[styles.detailItemValue, { color: colors.foreground }]}>
              {profile.accessMethod ? ACCESS_LABELS[profile.accessMethod] : "-"}
            </Text>
          </View>
        </View>

        {/* Model data summary */}
        {(slopeCount > 0 || elevationCount > 0) && (
          <View style={[styles.modelSummaryRow, { borderTopColor: colors.border }]}>
            {slopeCount > 0 && (
              <View style={styles.modelSummaryItem}>
                <Feather name="layers" size={13} color={colors.accent} />
                <Text style={[styles.modelSummaryText, { color: colors.mutedForeground }]}>
                  {slopeCount} slope{slopeCount !== 1 ? "s" : ""}
                  {roofingDamageCount > 0 ? ` · ${roofingDamageCount} instance${roofingDamageCount !== 1 ? "s" : ""}` : ""}
                </Text>
              </View>
            )}
            {elevationCount > 0 && (
              <View style={styles.modelSummaryItem}>
                <Feather name="grid" size={13} color={colors.accent} />
                <Text style={[styles.modelSummaryText, { color: colors.mutedForeground }]}>
                  {elevationCount} elevation{elevationCount !== 1 ? "s" : ""}
                  {sidingDamageCount > 0 ? ` · ${sidingDamageCount} instance${sidingDamageCount !== 1 ? "s" : ""}` : ""}
                </Text>
              </View>
            )}
            {settings.pricePerSq != null && slopeCount > 0 && (
              <View style={styles.modelSummaryItem}>
                <Feather name="dollar-sign" size={13} color={colors.success} />
                <Text style={[styles.modelSummaryText, { color: colors.mutedForeground }]}>
                  Estimate included (${settings.pricePerSq}/SQ)
                </Text>
              </View>
            )}
          </View>
        )}

        <View style={[styles.photoCountRow, { borderTopColor: colors.border }]}>
          <Feather name="image" size={16} color={colors.mutedForeground} />
          <Text style={[styles.photoCountLabel, { color: colors.mutedForeground }]}>
            {allPhotos.length} phase-1 photo{allPhotos.length !== 1 ? "s" : ""} included
          </Text>
        </View>
      </View>

      {/* Company branding note */}
      {settings.companyLogo && (
        <View
          style={[
            styles.brandRow,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Image
            source={{ uri: settings.companyLogo }}
            style={styles.brandLogo}
            resizeMode="contain"
          />
          <Text style={[styles.brandText, { color: colors.mutedForeground }]}>
            Report will include your company branding
          </Text>
        </View>
      )}

      {/* Photos Preview */}
      {allPhotos.length > 0 && (
        <View style={styles.photosSection}>
          <View style={styles.photosSectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Phase 1 Photos
            </Text>
            <View
              style={[
                styles.annotateHint,
                { backgroundColor: colors.secondary, borderRadius: colors.radius / 2 },
              ]}
            >
              <Feather name="edit-3" size={12} color={colors.mutedForeground} />
              <Text style={[styles.annotateHintText, { color: colors.mutedForeground }]}>
                Tap to annotate
              </Text>
            </View>
          </View>
          <FlatList
            data={allPhotos}
            keyExtractor={(uri, i) => `${uri}-${i}`}
            numColumns={numCols}
            scrollEnabled={false}
            contentContainerStyle={{ gap: 6 }}
            columnWrapperStyle={{ gap: 6 }}
            renderItem={({ item, index }) => {
              const isFront = index === 0 && !!profile.frontPhoto;
              const annotationCount = profile.photoAnnotations?.[item]?.length ?? 0;
              const isAnnotated = annotationCount > 0;
              return (
                <TouchableOpacity
                  onPress={() =>
                    router.push({
                      pathname: "/inspection/annotate" as any,
                      params: { id, photoUri: encodeURIComponent(item) },
                    })
                  }
                  activeOpacity={0.85}
                  style={{ position: "relative" }}
                >
                  <Image
                    source={{ uri: item }}
                    style={[
                      styles.photoThumb,
                      {
                        width: photoSize,
                        height: photoSize,
                        borderRadius: colors.radius / 2,
                      },
                    ]}
                    resizeMode="cover"
                  />
                  {isFront && (
                    <View style={[styles.frontLabel, { backgroundColor: colors.primary }]}>
                      <Text style={styles.frontLabelText}>Front</Text>
                    </View>
                  )}
                  <View
                    style={[
                      styles.annotatePhotoBtn,
                      { backgroundColor: isAnnotated ? "#F97316" : "rgba(0,0,0,0.55)" },
                    ]}
                  >
                    <Feather name={isAnnotated ? "check" : "edit-3"} size={11} color="#FFFFFF" />
                  </View>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      )}

      {/* Action Buttons */}
      <View style={styles.actions}>
        {reportUri ? (
          <>
            <View
              style={[
                styles.successBanner,
                { backgroundColor: "#F0FDF4", borderRadius: colors.radius },
              ]}
            >
              <Feather name="check-circle" size={20} color="#22C55E" />
              <Text style={[styles.successText, { color: "#22C55E" }]}>
                Report Generated Successfully
              </Text>
            </View>
            <TouchableOpacity
              onPress={handleViewReport}
              disabled={viewing}
              activeOpacity={0.85}
              style={[
                styles.generateButton,
                { backgroundColor: colors.primary, borderRadius: colors.radius },
              ]}
            >
              {viewing ? (
                <ActivityIndicator color="#FFFFFF" size="small" />
              ) : (
                <Feather name="eye" size={20} color="#FFFFFF" />
              )}
              <Text style={[styles.generateButtonText, { color: "#FFFFFF" }]}>
                {viewing ? "Opening…" : "View Report"}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleShare}
              activeOpacity={0.85}
              style={[
                styles.shareButton,
                {
                  borderColor: colors.primary,
                  borderRadius: colors.radius,
                  backgroundColor: colors.card,
                },
              ]}
            >
              <Feather name="share-2" size={18} color={colors.primary} />
              <Text style={[styles.shareButtonText, { color: colors.primary }]}>Share PDF</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() =>
                router.push({
                  pathname: "/inspection/send-report" as any,
                  params: { id },
                })
              }
              activeOpacity={0.85}
              style={[
                styles.shareButton,
                {
                  borderColor: colors.accent,
                  borderRadius: colors.radius,
                  backgroundColor: colors.card,
                },
              ]}
            >
              <Feather name="mail" size={18} color={colors.accent} />
              <Text style={[styles.shareButtonText, { color: colors.accent }]}>
                Send to Customer
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleGenerateReport}
              disabled={generating}
              activeOpacity={0.85}
              style={[
                styles.regenerateButton,
                { borderColor: colors.border, borderRadius: colors.radius },
              ]}
            >
              {generating ? (
                <ActivityIndicator color={colors.mutedForeground} size="small" />
              ) : (
                <Feather name="refresh-cw" size={16} color={colors.mutedForeground} />
              )}
              <Text style={[styles.regenerateText, { color: colors.mutedForeground }]}>
                {generating ? "Regenerating…" : "Regenerate Report"}
              </Text>
            </TouchableOpacity>
          </>
        ) : (
          <TouchableOpacity
            onPress={handleGenerateReport}
            disabled={generating}
            activeOpacity={0.85}
            style={[
              styles.generateButton,
              { backgroundColor: colors.accent, borderRadius: colors.radius },
            ]}
          >
            {generating ? (
              <ActivityIndicator color="#FFFFFF" size="small" />
            ) : (
              <Feather name="file-text" size={20} color="#FFFFFF" />
            )}
            <Text style={[styles.generateButtonText, { color: "#FFFFFF" }]}>
              {generating ? "Generating Report…" : "Generate PDF Report"}
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20, gap: 16 },
  centered: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  summaryCard: {
    borderWidth: 1,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  reportBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    paddingHorizontal: 16,
  },
  reportBadgeText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  address: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
    padding: 16,
    paddingBottom: 12,
    lineHeight: 26,
  },
  detailGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  detailItem: { flex: 1, minWidth: "45%", padding: 10, gap: 3 },
  detailItemLabel: { fontSize: 10, fontFamily: "Inter_600SemiBold", textTransform: "uppercase", letterSpacing: 0.5 },
  detailItemValue: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  modelSummaryRow: {
    borderTopWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 6,
  },
  modelSummaryItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  modelSummaryText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  photoCountRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderTopWidth: 1,
  },
  photoCountLabel: { fontSize: 13, fontFamily: "Inter_400Regular" },
  brandRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderWidth: 1,
  },
  brandLogo: { width: 44, height: 44, borderRadius: 6 },
  brandText: { fontSize: 13, fontFamily: "Inter_400Regular", flex: 1 },
  photosSection: { gap: 12 },
  photosSectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  sectionTitle: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
  annotateHint: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  annotateHintText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  photoThumb: {},
  frontLabel: {
    position: "absolute",
    top: 4,
    left: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  frontLabelText: { color: "#FFFFFF", fontSize: 10, fontFamily: "Inter_700Bold" },
  annotatePhotoBtn: {
    position: "absolute",
    bottom: 4,
    right: 4,
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  actions: { gap: 10 },
  successBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 14,
  },
  successText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  generateButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 18,
    gap: 10,
  },
  generateButtonText: { fontSize: 16, fontFamily: "Inter_700Bold" },
  shareButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 15,
    gap: 8,
    borderWidth: 1.5,
  },
  shareButtonText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  regenerateButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 13,
    gap: 8,
    borderWidth: 1,
  },
  regenerateText: { fontSize: 13, fontFamily: "Inter_500Medium" },
});
