import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useSettings } from "@/context/SettingsContext";
import { useColors } from "@/hooks/useColors";
import { BETA_PURPLE, BETA_PURPLE_BG } from "@/utils/hailBeta";
import { copyToDocumentsDetailed } from "@/utils/photos";

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { settings, updateSettings } = useSettings();

  const [companyName, setCompanyName] = useState(settings.companyName);
  const [userName, setUserName] = useState(settings.userName);
  const [pricePerSqText, setPricePerSqText] = useState(
    settings.pricePerSq != null ? settings.pricePerSq.toString() : "",
  );
  const [pricePerSidingSqText, setPricePerSidingSqText] = useState(
    settings.pricePerSidingSq != null ? settings.pricePerSidingSq.toString() : "",
  );
  const [saving, setSaving] = useState(false);

  const parsePrice = (text: string): number | undefined => {
    const parsed = parseFloat(text.replace(/[^0-9.]/g, ""));
    return isNaN(parsed) || parsed < 0 ? undefined : parsed;
  };

  const handleSave = async () => {
    setSaving(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await updateSettings({
      companyName,
      userName,
      pricePerSq: parsePrice(pricePerSqText),
      pricePerSidingSq: parsePrice(pricePerSidingSqText),
    });
    setSaving(false);
  };

  const handleLogoUpload = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission Required", "Please allow access to your photo library.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.9,
    });
    if (!result.canceled && result.assets[0]) {
      // Copy to permanent app storage — the raw picker URI is temporary
      // and can go stale, which would break the logo in reports later.
      const { uri, ok } = await copyToDocumentsDetailed(result.assets[0].uri);
      await updateSettings({ companyLogo: uri });
      if (!ok) {
        Alert.alert(
          "Logo Backup Warning",
          "The logo could not be copied to permanent storage and may disappear later. Try uploading it again.",
        );
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleRemoveLogo = () => {
    Alert.alert("Remove Logo", "Are you sure you want to remove the company logo?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove",
        style: "destructive",
        onPress: () => updateSettings({ companyLogo: undefined }),
      },
    ]);
  };

  const topPad = Platform.OS === "web" ? 67 : 0;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topPad + 20,
          paddingBottom: insets.bottom + 40,
        },
      ]}
      keyboardShouldPersistTaps="handled"
    >
      <Text style={[styles.pageTitle, { color: colors.foreground }]}>Settings</Text>

      {/* Company Logo */}
      <View style={[styles.section, { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border }]}>
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>COMPANY LOGO</Text>
        <View style={styles.logoArea}>
          {settings.companyLogo ? (
            <View style={styles.logoPreviewRow}>
              <Image
                source={{ uri: settings.companyLogo }}
                style={[styles.logoImage, { borderRadius: colors.radius }]}
              />
              <View style={styles.logoActions}>
                <TouchableOpacity
                  onPress={handleLogoUpload}
                  style={[styles.actionBtn, { backgroundColor: colors.secondary }]}
                >
                  <Feather name="refresh-cw" size={16} color={colors.primary} />
                  <Text style={[styles.actionBtnText, { color: colors.primary }]}>Replace</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleRemoveLogo}
                  style={[styles.actionBtn, { backgroundColor: "#FEF2F2" }]}
                >
                  <Feather name="trash-2" size={16} color={colors.destructive} />
                  <Text style={[styles.actionBtnText, { color: colors.destructive }]}>Remove</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            <TouchableOpacity
              onPress={handleLogoUpload}
              activeOpacity={0.8}
              style={[styles.uploadButton, { borderColor: colors.border, borderRadius: colors.radius }]}
            >
              <LinearGradient
                colors={["#F8F9FF", "#F0F4FF"]}
                style={[styles.uploadInner, { borderRadius: colors.radius }]}
              >
                <Feather name="upload" size={28} color={colors.accent} />
                <Text style={[styles.uploadText, { color: colors.foreground }]}>Upload Company Logo</Text>
                <Text style={[styles.uploadHint, { color: colors.mutedForeground }]}>Used in branded reports</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Profile */}
      <View style={[styles.section, { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border }]}>
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>PROFILE</Text>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>Company Name</Text>
          <TextInput
            style={[
              styles.input,
              {
                backgroundColor: colors.input,
                color: colors.foreground,
                borderRadius: colors.radius / 2,
                borderColor: colors.border,
              },
            ]}
            value={companyName}
            onChangeText={setCompanyName}
            placeholder="Enter company name"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="next"
          />
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>Your Name</Text>
          <TextInput
            style={[
              styles.input,
              {
                backgroundColor: colors.input,
                color: colors.foreground,
                borderRadius: colors.radius / 2,
                borderColor: colors.border,
              },
            ]}
            value={userName}
            onChangeText={setUserName}
            placeholder="Enter your name"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="done"
            onSubmitEditing={handleSave}
          />
        </View>

        <TouchableOpacity
          onPress={handleSave}
          activeOpacity={0.8}
          style={[
            styles.saveButton,
            {
              backgroundColor: colors.primary,
              borderRadius: colors.radius,
              opacity: saving ? 0.7 : 1,
            },
          ]}
        >
          <Feather name="check" size={18} color={colors.primaryForeground} />
          <Text style={[styles.saveButtonText, { color: colors.primaryForeground }]}>
            {saving ? "Saving..." : "Save Changes"}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Pricing */}
      <View
        style={[
          styles.section,
          { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border },
        ]}
      >
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>PRICING</Text>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>
            Price per Roofing Square (Basic)
          </Text>
          <Text style={[styles.fieldHint, { color: colors.mutedForeground }]}>
            Used to calculate slope-by-slope and total estimates (1 SQ = 100 sq ft)
          </Text>
          <View
            style={[
              styles.currencyRow,
              {
                backgroundColor: colors.input,
                borderColor: colors.border,
                borderRadius: colors.radius / 2,
              },
            ]}
          >
            <Text style={[styles.currencyPrefix, { color: colors.mutedForeground }]}>$</Text>
            <TextInput
              style={[styles.currencyInput, { color: colors.foreground }]}
              value={pricePerSqText}
              onChangeText={setPricePerSqText}
              placeholder="0.00"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="decimal-pad"
              returnKeyType="done"
            />
            <Text style={[styles.currencySuffix, { color: colors.mutedForeground }]}>/SQ</Text>
          </View>
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>
            Price per Siding Square (Basic)
          </Text>
          <Text style={[styles.fieldHint, { color: colors.mutedForeground }]}>
            Used to calculate siding estimates (1 SQ = 100 sq ft)
          </Text>
          <View
            style={[
              styles.currencyRow,
              {
                backgroundColor: colors.input,
                borderColor: colors.border,
                borderRadius: colors.radius / 2,
              },
            ]}
          >
            <Text style={[styles.currencyPrefix, { color: colors.mutedForeground }]}>$</Text>
            <TextInput
              style={[styles.currencyInput, { color: colors.foreground }]}
              value={pricePerSidingSqText}
              onChangeText={setPricePerSidingSqText}
              placeholder="0.00"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="decimal-pad"
              returnKeyType="done"
            />
            <Text style={[styles.currencySuffix, { color: colors.mutedForeground }]}>/SQ</Text>
          </View>
        </View>

        <TouchableOpacity
          onPress={handleSave}
          activeOpacity={0.8}
          style={[
            styles.saveButton,
            {
              backgroundColor: colors.primary,
              borderRadius: colors.radius,
              opacity: saving ? 0.7 : 1,
            },
          ]}
        >
          <Feather name="check" size={18} color={colors.primaryForeground} />
          <Text style={[styles.saveButtonText, { color: colors.primaryForeground }]}>
            {saving ? "Saving..." : "Save Changes"}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Beta Features — standalone, not part of the core inspection flow */}
      <View
        style={[
          styles.section,
          { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: BETA_PURPLE },
        ]}
      >
        <View style={styles.betaHeaderRow}>
          <Text style={[styles.sectionTitle, { color: BETA_PURPLE, marginBottom: 0 }]}>
            BETA FEATURES
          </Text>
          <View style={[styles.betaChip, { backgroundColor: BETA_PURPLE }]}>
            <Text style={styles.betaChipText}>BETA</Text>
          </View>
        </View>
        <Text style={[styles.betaHint, { color: colors.mutedForeground }]}>
          Experimental tools — separate from the core inspection flow and never included in
          reports.
        </Text>
        <TouchableOpacity
          onPress={() => router.push("/hail-reference")}
          activeOpacity={0.8}
          style={[
            styles.betaRow,
            { backgroundColor: BETA_PURPLE_BG, borderRadius: colors.radius / 2 },
          ]}
        >
          <Feather name="cloud-snow" size={18} color={BETA_PURPLE} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.betaRowTitle, { color: BETA_PURPLE }]}>
              Hail Reference Library
            </Text>
            <Text style={[styles.betaRowSub, { color: colors.mutedForeground }]}>
              Adjudicated hail photos used by the beta hail analysis
            </Text>
          </View>
          <Feather name="chevron-right" size={18} color={BETA_PURPLE} />
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 20 },
  pageTitle: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    marginBottom: 24,
  },
  section: {
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  sectionTitle: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 1,
    marginBottom: 16,
  },
  logoArea: {},
  logoPreviewRow: {
    flexDirection: "row",
    gap: 16,
    alignItems: "flex-start",
  },
  logoImage: {
    width: 80,
    height: 80,
    resizeMode: "contain",
    backgroundColor: "#F5F5F5",
  },
  logoActions: {
    flex: 1,
    gap: 8,
  },
  actionBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 10,
    borderRadius: 8,
  },
  actionBtnText: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
  },
  uploadButton: {
    borderWidth: 2,
    borderStyle: "dashed",
    overflow: "hidden",
  },
  uploadInner: {
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
    gap: 8,
  },
  uploadText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  uploadHint: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
  },
  fieldGroup: { marginBottom: 16 },
  fieldHint: { fontSize: 12, fontFamily: "Inter_400Regular", marginBottom: 8, lineHeight: 17 },
  currencyRow: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    paddingHorizontal: 12,
    height: 50,
  },
  currencyPrefix: { fontSize: 17, fontFamily: "Inter_500Medium", marginRight: 2 },
  currencyInput: { flex: 1, fontSize: 17, fontFamily: "Inter_400Regular", height: "100%" },
  currencySuffix: { fontSize: 14, fontFamily: "Inter_500Medium", marginLeft: 4 },
  label: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
    marginBottom: 8,
  },
  input: {
    padding: 14,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
  },
  saveButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 14,
    gap: 8,
    marginTop: 4,
  },
  saveButtonText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  betaHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 8,
  },
  betaChip: {
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 6,
  },
  betaChipText: {
    color: "#FFFFFF",
    fontSize: 9,
    fontFamily: "Inter_700Bold",
    letterSpacing: 1,
  },
  betaHint: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    lineHeight: 17,
    marginBottom: 12,
  },
  betaRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
  },
  betaRowTitle: { fontSize: 14.5, fontFamily: "Inter_600SemiBold" },
  betaRowSub: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
});
