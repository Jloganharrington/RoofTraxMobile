import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React from "react";
import {
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { InspectionCard } from "@/components/InspectionCard";
import { useInspections } from "@/context/InspectionContext";
import { useSettings } from "@/context/SettingsContext";
import { useColors } from "@/hooks/useColors";

export default function DashboardScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { profiles } = useInspections();
  const { settings } = useSettings();

  const isTablet = width >= 768;
  const topPad = Platform.OS === "web" ? 67 : insets.top + 16;
  const bottomPad = Platform.OS === "web" ? 84 : insets.bottom + 84;

  const handleNewInspection = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push("/inspection/new");
  };

  const stats = {
    total: profiles.length,
    inProgress: profiles.filter((p) => p.status === "in_progress").length,
    ready: profiles.filter((p) => p.status === "report_ready").length,
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.primary,
            paddingTop: topPad,
          },
        ]}
      >
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.greeting}>Good day,</Text>
            <Text style={styles.userName}>{settings.userName}</Text>
          </View>
          <View style={[styles.companyBadge, { backgroundColor: "rgba(255,255,255,0.15)" }]}>
            <Feather name="shield" size={14} color="rgba(255,255,255,0.9)" />
            <Text style={styles.companyName} numberOfLines={1}>
              {settings.companyName}
            </Text>
          </View>
        </View>

        {/* Stats Row */}
        {profiles.length > 0 && (
          <View style={styles.statsRow}>
            <StatPill
              value={stats.total}
              label="Total"
              color="rgba(255,255,255,0.15)"
              textColor="#FFFFFF"
            />
            <StatPill
              value={stats.inProgress}
              label="In Progress"
              color={colors.accent}
              textColor="#FFFFFF"
            />
            <StatPill
              value={stats.ready}
              label="Reports Ready"
              color="#22C55E"
              textColor="#FFFFFF"
            />
          </View>
        )}
      </View>

      {/* Inspections List */}
      <FlatList
        data={isTablet ? profiles : profiles}
        keyExtractor={(item) => item.id}
        numColumns={isTablet ? 2 : 1}
        key={isTablet ? "tablet" : "phone"}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: bottomPad },
        ]}
        columnWrapperStyle={isTablet ? { gap: 12 } : undefined}
        showsVerticalScrollIndicator={false}
        scrollEnabled={!!profiles.length}
        ListHeaderComponent={
          <View style={styles.listHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Inspection Profiles
            </Text>
            <Text style={[styles.sectionCount, { color: colors.mutedForeground }]}>
              {profiles.length > 0 ? `${profiles.length} profile${profiles.length !== 1 ? "s" : ""}` : ""}
            </Text>
          </View>
        }
        ListEmptyComponent={
          <View style={[styles.emptyState, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="clipboard" size={32} color={colors.accent} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              No Inspections Yet
            </Text>
            <Text style={[styles.emptySubtitle, { color: colors.mutedForeground }]}>
              Create your first inspection profile to begin documenting storm damage.
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={isTablet ? styles.tabletCardWrap : undefined}>
            <InspectionCard profile={item} />
          </View>
        )}
      />

      {/* FAB */}
      <TouchableOpacity
        onPress={handleNewInspection}
        activeOpacity={0.85}
        style={[
          styles.fab,
          {
            backgroundColor: colors.accent,
            bottom: Platform.OS === "web" ? 100 : insets.bottom + 96,
          },
        ]}
      >
        <Feather name="plus" size={26} color="#FFFFFF" />
      </TouchableOpacity>
    </View>
  );
}

function StatPill({
  value,
  label,
  color,
  textColor,
}: {
  value: number;
  label: string;
  color: string;
  textColor: string;
}) {
  return (
    <View style={[statStyles.pill, { backgroundColor: color }]}>
      <Text style={[statStyles.value, { color: textColor }]}>{value}</Text>
      <Text style={[statStyles.label, { color: textColor }]}>{label}</Text>
    </View>
  );
}

const statStyles = StyleSheet.create({
  pill: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 10,
    borderRadius: 10,
    gap: 2,
  },
  value: { fontSize: 22, fontFamily: "Inter_700Bold" },
  label: { fontSize: 11, fontFamily: "Inter_500Medium", opacity: 0.85 },
});

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  greeting: {
    color: "rgba(255,255,255,0.7)",
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
  userName: {
    color: "#FFFFFF",
    fontSize: 24,
    fontFamily: "Inter_700Bold",
  },
  companyBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    maxWidth: 160,
  },
  companyName: {
    color: "rgba(255,255,255,0.9)",
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
  statsRow: {
    flexDirection: "row",
    gap: 8,
  },
  listContent: {
    paddingHorizontal: 20,
    paddingTop: 8,
  },
  listHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
  },
  sectionCount: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
  emptyState: {
    alignItems: "center",
    padding: 40,
    gap: 16,
    borderWidth: 1,
    marginTop: 8,
  },
  emptyIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    textAlign: "center",
  },
  emptySubtitle: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 22,
  },
  tabletCardWrap: { flex: 1 },
  fab: {
    position: "absolute",
    right: 24,
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 8,
  },
});
