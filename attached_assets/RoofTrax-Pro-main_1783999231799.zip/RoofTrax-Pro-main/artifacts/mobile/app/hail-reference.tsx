import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { Stack } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Platform,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import {
  BETA_PURPLE,
  BETA_PURPLE_BG,
  addHailReference,
  deleteHailReference,
  fetchHailReferences,
  referenceImageUri,
  type HailReferenceItem,
  type HailReferenceStatus,
} from "@/utils/hailBeta";

// ---------------------------------------------------------------------------
// Standalone BETA screen — hail reference library. Not connected to the
// inspection wizard, damage forms, or report generation.
// ---------------------------------------------------------------------------

interface PendingPhoto {
  previewUri: string;
  base64: string;
  mimeType: string;
}

export default function HailReferenceScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const [items, setItems] = useState<HailReferenceItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Add form state
  const [pending, setPending] = useState<PendingPhoto | null>(null);
  const [status, setStatus] = useState<HailReferenceStatus>("confirmed");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  // Delete state — inline confirmation (Alert.alert buttons are no-ops on web)
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setLoadError(null);
      const list = await fetchHailReferences();
      setItems(list);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : "Failed to load the library.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handlePickPhoto = async () => {
    const { status: perm } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (perm !== "granted") {
      Alert.alert("Permission Required", "Please allow access to your photo library.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      quality: 0.7,
      base64: true,
    });
    if (!result.canceled && result.assets[0]?.base64) {
      const asset = result.assets[0];
      setPending({
        previewUri: asset.uri,
        base64: asset.base64 as string,
        mimeType:
          asset.mimeType === "image/png" || asset.mimeType === "image/webp"
            ? asset.mimeType
            : "image/jpeg",
      });
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleSave = async () => {
    if (!pending || saving) return;
    setSaving(true);
    try {
      await addHailReference({
        imageBase64: pending.base64,
        mimeType: pending.mimeType,
        status,
        notes: notes.trim(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setPending(null);
      setNotes("");
      setStatus("confirmed");
      setLoading(true);
      await load();
    } catch (err) {
      Alert.alert(
        "Upload Failed",
        err instanceof Error ? err.message : "Could not save the reference photo.",
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (deletingId) return;
    setDeletingId(id);
    setDeleteError(null);
    try {
      await deleteHailReference(id);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setConfirmingId(null);
      setItems((prev) => prev.filter((it) => it.id !== id));
      await load();
    } catch (err) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setDeleteError(
        err instanceof Error ? err.message : "Could not delete the reference photo.",
      );
    } finally {
      setDeletingId(null);
    }
  };

  const statusBadge = (s: HailReferenceStatus) => (
    <View
      style={[
        styles.statusBadge,
        { backgroundColor: s === "confirmed" ? colors.success + "22" : colors.destructive + "22" },
      ]}
    >
      <Feather
        name={s === "confirmed" ? "check-circle" : "x-circle"}
        size={12}
        color={s === "confirmed" ? colors.success : colors.destructive}
      />
      <Text
        style={[
          styles.statusBadgeText,
          { color: s === "confirmed" ? colors.success : colors.destructive },
        ]}
      >
        {s === "confirmed" ? "Confirmed Hail" : "Denied (Not Hail)"}
      </Text>
    </View>
  );

  return (
    <>
      <Stack.Screen options={{ title: "Hail Reference Library" }} />
      <ScrollView
        style={[styles.container, { backgroundColor: colors.background }]}
        contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 40 }}
        keyboardShouldPersistTaps="handled"
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              load();
            }}
          />
        }
      >
        {/* Beta banner */}
        <View style={[styles.betaBanner, { backgroundColor: BETA_PURPLE_BG, borderRadius: colors.radius }]}>
          <View style={[styles.betaChip, { backgroundColor: BETA_PURPLE }]}>
            <Text style={styles.betaChipText}>BETA</Text>
          </View>
          <Text style={[styles.betaBannerText, { color: BETA_PURPLE }]}>
            Build your own library of adjudicated hail photos. Used only by the beta hail
            analysis — never in inspections or reports.
          </Text>
        </View>

        {/* Add section */}
        <View
          style={[
            styles.section,
            { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>
            ADD REFERENCE PHOTO
          </Text>

          {pending ? (
            <View style={styles.pendingRow}>
              <Image
                source={{ uri: pending.previewUri }}
                style={[styles.pendingImage, { borderRadius: colors.radius / 2 }]}
                resizeMode="cover"
              />
              <TouchableOpacity
                onPress={() => setPending(null)}
                style={[styles.changePhotoBtn, { backgroundColor: colors.secondary }]}
              >
                <Feather name="refresh-cw" size={14} color={colors.primary} />
                <Text style={[styles.changePhotoText, { color: colors.primary }]}>Change</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity
              onPress={handlePickPhoto}
              activeOpacity={0.8}
              style={[
                styles.pickButton,
                { borderColor: BETA_PURPLE, borderRadius: colors.radius },
              ]}
            >
              <Feather name="image" size={24} color={BETA_PURPLE} />
              <Text style={[styles.pickButtonText, { color: BETA_PURPLE }]}>Choose Photo</Text>
            </TouchableOpacity>
          )}

          {pending && (
            <>
              <Text style={[styles.label, { color: colors.foreground }]}>Adjudication</Text>
              <View style={styles.statusRow}>
                {(["confirmed", "denied"] as HailReferenceStatus[]).map((s) => {
                  const selected = status === s;
                  const tint = s === "confirmed" ? colors.success : colors.destructive;
                  return (
                    <TouchableOpacity
                      key={s}
                      onPress={() => setStatus(s)}
                      style={[
                        styles.statusOption,
                        {
                          borderColor: selected ? tint : colors.border,
                          backgroundColor: selected ? tint + "18" : colors.card,
                          borderRadius: colors.radius / 2,
                        },
                      ]}
                    >
                      <Feather
                        name={s === "confirmed" ? "check-circle" : "x-circle"}
                        size={16}
                        color={selected ? tint : colors.mutedForeground}
                      />
                      <Text
                        style={[
                          styles.statusOptionText,
                          { color: selected ? tint : colors.mutedForeground },
                        ]}
                      >
                        {s === "confirmed" ? "Confirmed Hail" : "Denied (Not Hail)"}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <Text style={[styles.label, { color: colors.foreground }]}>Notes</Text>
              <TextInput
                style={[
                  styles.notesInput,
                  {
                    backgroundColor: colors.input,
                    color: colors.foreground,
                    borderColor: colors.border,
                    borderRadius: colors.radius / 2,
                  },
                ]}
                value={notes}
                onChangeText={setNotes}
                placeholder="e.g. 1.5-inch hail, adjuster-verified, laminate shingle"
                placeholderTextColor={colors.mutedForeground}
                multiline
              />

              <TouchableOpacity
                onPress={handleSave}
                activeOpacity={0.85}
                disabled={saving}
                style={[
                  styles.saveButton,
                  { backgroundColor: BETA_PURPLE, borderRadius: colors.radius, opacity: saving ? 0.7 : 1 },
                ]}
              >
                {saving ? (
                  <ActivityIndicator color="#FFFFFF" size="small" />
                ) : (
                  <Feather name="upload-cloud" size={18} color="#FFFFFF" />
                )}
                <Text style={styles.saveButtonText}>
                  {saving ? "Uploading..." : "Save to Library"}
                </Text>
              </TouchableOpacity>
            </>
          )}
        </View>

        {/* Library */}
        <View
          style={[
            styles.section,
            { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>
            LIBRARY ({items.length})
          </Text>

          {loading ? (
            <ActivityIndicator color={BETA_PURPLE} style={{ paddingVertical: 24 }} />
          ) : loadError ? (
            <View style={styles.emptyState}>
              <Feather name="alert-triangle" size={20} color={colors.destructive} />
              <Text style={[styles.emptyText, { color: colors.destructive }]}>{loadError}</Text>
              <TouchableOpacity
                onPress={() => {
                  setLoading(true);
                  load();
                }}
                style={[styles.retryBtn, { backgroundColor: colors.secondary, borderRadius: colors.radius / 2 }]}
              >
                <Text style={[styles.retryText, { color: colors.primary }]}>Retry</Text>
              </TouchableOpacity>
            </View>
          ) : items.length === 0 ? (
            <View style={styles.emptyState}>
              <Feather name="cloud-snow" size={22} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                No reference photos yet. Add your first adjudicated hail photo above.
              </Text>
            </View>
          ) : (
            items.map((item) => {
              const confirming = confirmingId === item.id;
              const deleting = deletingId === item.id;
              return (
                <View
                  key={item.id}
                  style={[
                    styles.libraryRow,
                    { borderColor: colors.border, borderRadius: colors.radius / 2 },
                  ]}
                >
                  <View style={styles.libraryTopRow}>
                    <Image
                      source={{ uri: referenceImageUri(item) }}
                      style={[styles.libraryImage, { borderRadius: colors.radius / 2 }]}
                      resizeMode="cover"
                    />
                    <View style={styles.libraryInfo}>
                      {statusBadge(item.status)}
                      {item.notes ? (
                        <Text style={[styles.libraryNotes, { color: colors.foreground }]} numberOfLines={3}>
                          {item.notes}
                        </Text>
                      ) : (
                        <Text style={[styles.libraryNotes, { color: colors.mutedForeground }]}>
                          No notes
                        </Text>
                      )}
                      <Text style={[styles.libraryDate, { color: colors.mutedForeground }]}>
                        Added {new Date(item.createdAt).toLocaleDateString()}
                      </Text>
                    </View>
                    {!confirming && (
                      <TouchableOpacity
                        onPress={() => {
                          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                          setDeleteError(null);
                          setConfirmingId(item.id);
                        }}
                        disabled={Boolean(deletingId)}
                        accessibilityLabel="Delete reference photo"
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        style={styles.trashBtn}
                      >
                        <Feather name="trash-2" size={18} color={colors.destructive} />
                      </TouchableOpacity>
                    )}
                  </View>

                  {confirming && (
                    <View
                      style={[
                        styles.confirmBox,
                        { backgroundColor: colors.destructive + "10", borderRadius: colors.radius / 2 },
                      ]}
                    >
                      <Text style={[styles.confirmText, { color: colors.foreground }]}>
                        Permanently delete this reference photo?
                      </Text>
                      <View style={styles.confirmActions}>
                        <TouchableOpacity
                          onPress={() => {
                            setConfirmingId(null);
                            setDeleteError(null);
                          }}
                          disabled={deleting}
                          style={[
                            styles.confirmBtn,
                            { backgroundColor: colors.secondary, borderRadius: colors.radius / 2 },
                          ]}
                        >
                          <Text style={[styles.confirmBtnText, { color: colors.foreground }]}>
                            Cancel
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() => handleDelete(item.id)}
                          disabled={deleting}
                          style={[
                            styles.confirmBtn,
                            {
                              backgroundColor: colors.destructive,
                              borderRadius: colors.radius / 2,
                              opacity: deleting ? 0.7 : 1,
                            },
                          ]}
                        >
                          {deleting ? (
                            <ActivityIndicator color="#FFFFFF" size="small" />
                          ) : (
                            <Feather name="trash-2" size={14} color="#FFFFFF" />
                          )}
                          <Text style={[styles.confirmBtnText, { color: "#FFFFFF" }]}>
                            {deleting ? "Deleting..." : "Delete"}
                          </Text>
                        </TouchableOpacity>
                      </View>
                      {deleteError ? (
                        <Text style={[styles.deleteErrorText, { color: colors.destructive }]}>
                          {deleteError}
                        </Text>
                      ) : null}
                    </View>
                  )}
                </View>
              );
            })
          )}
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  betaBanner: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    padding: 14,
    marginBottom: 16,
  },
  betaChip: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginTop: 1,
  },
  betaChipText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontFamily: "Inter_700Bold",
    letterSpacing: 1,
  },
  betaBannerText: { flex: 1, fontSize: 12.5, fontFamily: "Inter_500Medium", lineHeight: 18 },
  section: {
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  sectionTitle: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 1,
    marginBottom: 14,
  },
  pickButton: {
    borderWidth: 2,
    borderStyle: "dashed",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 28,
    gap: 8,
  },
  pickButtonText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  pendingRow: { flexDirection: "row", alignItems: "flex-end", gap: 12, marginBottom: 14 },
  pendingImage: { width: 110, height: 110, backgroundColor: "#EEE" },
  changePhotoBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  changePhotoText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  label: { fontSize: 14, fontFamily: "Inter_500Medium", marginBottom: 8, marginTop: 4 },
  statusRow: { flexDirection: "row", gap: 10, marginBottom: 14 },
  statusOption: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 12,
    borderWidth: 1.5,
  },
  statusOptionText: { fontSize: 12.5, fontFamily: "Inter_600SemiBold" },
  notesInput: {
    borderWidth: 1,
    padding: 12,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    minHeight: 70,
    textAlignVertical: "top",
    marginBottom: 14,
  },
  saveButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 14,
  },
  saveButtonText: { color: "#FFFFFF", fontSize: 15, fontFamily: "Inter_600SemiBold" },
  emptyState: { alignItems: "center", gap: 10, paddingVertical: 20 },
  emptyText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 19,
  },
  retryBtn: { paddingHorizontal: 16, paddingVertical: 8 },
  retryText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    alignSelf: "flex-start",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusBadgeText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  libraryRow: {
    borderWidth: 1,
    padding: 10,
    marginBottom: 10,
  },
  libraryTopRow: { flexDirection: "row", gap: 12 },
  libraryImage: { width: 84, height: 84, backgroundColor: "#EEE" },
  libraryInfo: { flex: 1, gap: 6, justifyContent: "center" },
  libraryNotes: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 18 },
  libraryDate: { fontSize: 11, fontFamily: "Inter_400Regular" },
  trashBtn: {
    alignSelf: "flex-start",
    padding: 4,
  },
  confirmBox: {
    marginTop: 10,
    padding: 12,
    gap: 10,
  },
  confirmText: { fontSize: 13, fontFamily: "Inter_500Medium", lineHeight: 18 },
  confirmActions: { flexDirection: "row", gap: 10 },
  confirmBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 10,
  },
  confirmBtnText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  deleteErrorText: { fontSize: 12, fontFamily: "Inter_500Medium", lineHeight: 17 },
});
