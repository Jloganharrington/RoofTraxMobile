import * as FileSystem from "expo-file-system/legacy";
import { Platform } from "react-native";

import { API_BASE_URL } from "@/config/apiUrl";

// ---------------------------------------------------------------------------
// Standalone BETA hail feature helpers. Deliberately independent from the
// inspection wizard, damage forms, and report generation — nothing here
// reads or writes InspectionContext.
// ---------------------------------------------------------------------------

/** Distinct beta accent — purple, unmistakably different from the app's
 *  navy (#1E3A5F) primary and orange (#F97316) accent. */
export const BETA_PURPLE = "#7C3AED";
export const BETA_PURPLE_BG = "#F3EEFD";

export type HailReferenceStatus = "confirmed" | "denied";

export interface HailReferenceItem {
  id: string;
  status: HailReferenceStatus;
  notes: string;
  mimeType: string;
  createdAt: string;
  imageUrl: string;
}

export interface HailAnalysisResult {
  probability: number;
  reasoning: string;
  indicators: string[];
  confounders: string[];
  disclaimer: string;
}

export function referenceImageUri(item: HailReferenceItem): string {
  return `${API_BASE_URL}${item.imageUrl}`;
}

export async function fetchHailReferences(): Promise<HailReferenceItem[]> {
  const res = await fetch(`${API_BASE_URL}/api/hail-reference/list`);
  if (!res.ok) throw new Error(`Failed to load reference library (${res.status})`);
  const data = await res.json();
  return Array.isArray(data?.items) ? data.items : [];
}

export async function addHailReference(input: {
  imageBase64: string;
  mimeType: string;
  status: HailReferenceStatus;
  notes: string;
}): Promise<HailReferenceItem> {
  const res = await fetch(`${API_BASE_URL}/api/hail-reference/add`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new Error(body?.message ?? `Failed to save reference photo (${res.status})`);
  }
  return res.json();
}

export async function deleteHailReference(id: string): Promise<void> {
  const res = await fetch(`${API_BASE_URL}/api/hail-reference/${encodeURIComponent(id)}`, {
    method: "DELETE",
  });
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new Error(body?.message ?? `Failed to delete reference photo (${res.status})`);
  }
}

export async function analyzeHailIndicators(input: {
  photoBase64: string;
  mimeType: string;
  referenceIds: string[];
}): Promise<HailAnalysisResult> {
  const res = await fetch(`${API_BASE_URL}/api/hail-analysis/analyze`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new Error(body?.message ?? `Analysis failed (${res.status})`);
  }
  return res.json();
}

/** Best-effort mime type from a local photo URI. */
export function guessMimeType(uri: string): "image/jpeg" | "image/png" | "image/webp" {
  const clean = uri.split("?")[0].toLowerCase();
  if (clean.endsWith(".png")) return "image/png";
  if (clean.endsWith(".webp")) return "image/webp";
  return "image/jpeg";
}

/**
 * Reads a local photo URI into raw base64 (no data-URI prefix).
 * Native: expo-file-system. Web: fetch → blob → FileReader.
 */
export async function photoUriToBase64(uri: string): Promise<string> {
  if (Platform.OS === "web") {
    const res = await fetch(uri);
    if (!res.ok) throw new Error("Could not read the photo.");
    const blob = await res.blob();
    return await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error("Could not read the photo."));
      reader.onload = () => {
        const result = String(reader.result ?? "");
        const idx = result.indexOf("base64,");
        resolve(idx >= 0 ? result.slice(idx + 7) : result);
      };
      reader.readAsDataURL(blob);
    });
  }
  return FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
}
