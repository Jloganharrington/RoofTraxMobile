// This app stores inspections with a single free-text `address` field (no
// structured city/state — see context/InspectionContext.tsx). The weather
// system reference assumes a structured propertyData.city/state, which
// doesn't exist here, so this derives it from the free-text address instead.
export function parseCityState(address: string): { city: string; state: string } | null {
  if (!address) return null;

  const parts = address
    .split(",")
    .map((p) => p.trim())
    .filter(Boolean);
  if (parts.length < 2) return null;

  const city = parts[parts.length - 2];
  const lastPart = parts[parts.length - 1];
  // Matches a 2-letter state abbreviation, optionally followed by a zip
  // (e.g. "IL 62704" or just "IL").
  const stateMatch = lastPart.match(/\b([A-Za-z]{2})\b/);
  const state = stateMatch?.[1]?.toUpperCase();

  if (!city || !state) return null;
  return { city, state };
}
