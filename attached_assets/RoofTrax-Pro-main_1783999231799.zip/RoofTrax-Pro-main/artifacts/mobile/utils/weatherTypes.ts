export interface WeatherEvent {
  date: string;
  type: "hail" | "wind" | "tornado";
  size?: number | null;
  magnitude?: number | null;
  distance?: number | null;
}

export interface WeatherEventsResult {
  events: WeatherEvent[];
  counts: { hail: number; wind: number; tornado: number };
}

export interface AnalyzedStormEvent {
  date: string;
  hailSize?: number | null;
  windSpeed?: number | null;
  distance?: number | null;
  probability: number;
  reason?: string;
  description?: string;
}

export interface SelectedStorm {
  date: string;
  hailSize?: number | null;
  windSpeed?: number | null;
  distance?: number | null;
  probability?: number | null;
  reason?: string;
  description?: string;
}
