import * as FileSystem from "expo-file-system/legacy";
import { Alert, Platform } from "react-native";

export interface CopyPhotoResult {
  uri: string;
  ok: boolean;
}

export interface CopyPhotosResult {
  uris: string[];
  failedCount: number;
}

/**
 * Deterministic short hash of a string (djb2, hex). Used to make copy
 * destinations unique per source URI so two different photos that share
 * a basename can never alias to the same destination file, while repeat
 * copies of the same source stay idempotent.
 */
function hashUri(input: string): string {
  let hash = 5381;
  for (let i = 0; i < input.length; i++) {
    hash = ((hash << 5) + hash + input.charCodeAt(i)) >>> 0;
  }
  return hash.toString(16);
}

/**
 * Copies a photo URI to the app's permanent documents directory so it
 * remains accessible even after the OS clears its cache/tmp directories.
 * Returns the stable destination URI plus whether the photo is safely
 * in permanent storage. On web there is nothing to copy, so it is
 * always considered ok.
 */
export async function copyToDocumentsDetailed(sourceUri: string): Promise<CopyPhotoResult> {
  if (Platform.OS === "web" || !sourceUri) return { uri: sourceUri, ok: true };
  try {
    const docDir = FileSystem.documentDirectory;
    if (!docDir) return { uri: sourceUri, ok: false };
    // Already in permanent storage — nothing to do.
    if (sourceUri.startsWith(docDir)) return { uri: sourceUri, ok: true };
    const filename = sourceUri.split("/").pop() ?? `photo_${Date.now()}.jpg`;
    const destUri = `${docDir}insp_${hashUri(sourceUri)}_${filename}`;
    const info = await FileSystem.getInfoAsync(destUri);
    if (!info.exists) {
      await FileSystem.copyAsync({ from: sourceUri, to: destUri });
    }
    return { uri: destUri, ok: true };
  } catch {
    return { uri: sourceUri, ok: false };
  }
}

/**
 * Copies an array of photo URIs to the documents directory in parallel.
 * Always resolves — failures fall back to the original URI and are
 * counted in failedCount.
 */
export async function copyAllToDocumentsDetailed(uris: string[]): Promise<CopyPhotosResult> {
  const results = await Promise.all(uris.map(copyToDocumentsDetailed));
  return {
    uris: results.map((r) => r.uri),
    failedCount: results.filter((r) => !r.ok).length,
  };
}

/**
 * Convenience wrapper returning just the URI. Prefer the detailed
 * variants when the caller should surface copy failures to the user.
 */
export async function copyToDocuments(sourceUri: string): Promise<string> {
  const { uri } = await copyToDocumentsDetailed(sourceUri);
  return uri;
}

/**
 * Convenience wrapper returning just the URIs.
 */
export async function copyAllToDocuments(uris: string[]): Promise<string[]> {
  const { uris: result } = await copyAllToDocumentsDetailed(uris);
  return result;
}

/**
 * Shows a warning that one or more photos could not be copied to
 * permanent storage. Copy failures can only happen on native (web
 * skips copying), where Alert.alert is fully supported.
 */
export function warnCopyFailures(failedCount: number): void {
  if (failedCount <= 0) return;
  Alert.alert(
    "Photo Backup Warning",
    failedCount === 1
      ? "1 photo could not be copied to permanent storage. It may be lost if the app closes — try removing and re-adding it."
      : `${failedCount} photos could not be copied to permanent storage. They may be lost if the app closes — try removing and re-adding them.`,
  );
}
