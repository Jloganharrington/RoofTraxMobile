/**
 * Email relay webhook client.
 *
 * The relay endpoint + auth token are NOT yet wired — Track A will provide the
 * real URL and token. Until then, `sendReportEmail` short-circuits with a
 * clear "not configured" error and never performs a network call.
 *
 * To wire the real endpoint, set EMAIL_RELAY_URL and EMAIL_RELAY_TOKEN below.
 */

// TODO(Track A): replace with the real relay endpoint URL when provided.
const EMAIL_RELAY_URL: string | null = null;
// TODO(Track A): replace with the real bearer token when provided.
const EMAIL_RELAY_TOKEN: string | null = null;

export interface SendReportPayload {
  to: string;
  subject: string;
  message: string;
  attachment: {
    filename: string;
    /** Base64-encoded PDF content (no data-URI prefix). */
    base64: string;
  } | null;
  meta: {
    inspectionId: string;
    address: string;
    sentAt: string;
  };
}

export interface SendReportResult {
  ok: boolean;
  error?: string;
}

export function isEmailRelayConfigured(): boolean {
  return EMAIL_RELAY_URL != null && EMAIL_RELAY_URL.length > 0;
}

export async function sendReportEmail(payload: SendReportPayload): Promise<SendReportResult> {
  if (!isEmailRelayConfigured()) {
    return {
      ok: false,
      error:
        "Email delivery isn't connected yet. The relay endpoint will be wired up shortly — nothing was sent.",
    };
  }

  try {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (EMAIL_RELAY_TOKEN) {
      headers.Authorization = `Bearer ${EMAIL_RELAY_TOKEN}`;
    }

    const res = await fetch(EMAIL_RELAY_URL as string, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      return { ok: false, error: `Email relay returned status ${res.status}.` };
    }
    return { ok: true };
  } catch (e) {
    const message = e instanceof Error ? e.message : "Unknown network error";
    return { ok: false, error: `Failed to reach the email relay: ${message}` };
  }
}
