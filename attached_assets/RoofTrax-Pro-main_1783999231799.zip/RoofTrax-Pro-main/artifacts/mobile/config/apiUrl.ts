function resolveApiBaseUrl(): string {
  const explicit = process.env.EXPO_PUBLIC_API_BASE_URL;
  if (explicit) return explicit.replace(/\/+$/, "");
  const replitDomain = process.env.EXPO_PUBLIC_DOMAIN;
  if (replitDomain) return `https://${replitDomain}`;
  return "http://localhost:80";
}

export const API_BASE_URL = resolveApiBaseUrl();
