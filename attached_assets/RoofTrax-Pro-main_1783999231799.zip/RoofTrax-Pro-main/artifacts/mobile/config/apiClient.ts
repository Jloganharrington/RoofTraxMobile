import { setBaseUrl } from "@workspace/api-client-react";

// This wiring didn't exist before this feature — the app had no server
// calls at all prior to the weather integration. `EXPO_PUBLIC_DOMAIN` is
// already exported by the Replit `dev` script (see package.json) but was
// previously unused; `EXPO_PUBLIC_API_BASE_URL` is a manual override for
// local dev against `pnpm --filter @workspace/api-server run dev`.
function resolveApiBaseUrl(): string {
  const explicit = process.env.EXPO_PUBLIC_API_BASE_URL;
  if (explicit) return explicit.replace(/\/+$/, "");

  const replitDomain = process.env.EXPO_PUBLIC_DOMAIN;
  if (replitDomain) return `https://${replitDomain}`;

  return "http://localhost:4000";
}

export function configureApiClient(): void {
  setBaseUrl(resolveApiBaseUrl());
}
