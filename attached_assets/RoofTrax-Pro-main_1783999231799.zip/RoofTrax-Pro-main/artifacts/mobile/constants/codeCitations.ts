export interface CodeCitation {
  id: string;
  code: string;
  section: string;
  title: string;
  description: string;
}

export const CODE_CITATIONS: CodeCitation[] = [
  {
    id: "ibc-1504-3",
    code: "IBC 2021",
    section: "§1504.3",
    title: "Wind Resistance — Steep Slope",
    description:
      "Roof coverings shall resist wind pressures per ASCE 7 and the manufacturer's installation requirements.",
  },
  {
    id: "ibc-1507-2",
    code: "IBC 2021",
    section: "§1507.2",
    title: "Asphalt Shingles — Application",
    description:
      "Asphalt shingles shall be fastened per manufacturer's instructions with a minimum of 4 fasteners per shingle strip.",
  },
  {
    id: "ibc-1507-3",
    code: "IBC 2021",
    section: "§1507.3",
    title: "Clay / Concrete Tile",
    description:
      "Tile shall be fastened per manufacturer specification; underlayment per §1507.3.3.",
  },
  {
    id: "ibc-1507-4",
    code: "IBC 2021",
    section: "§1507.4",
    title: "Metal Roof Panels",
    description:
      "Metal panels shall comply with ASTM A792 or ASTM A755 for coating thickness and base metal.",
  },
  {
    id: "ibc-1511",
    code: "IBC 2021",
    section: "§1511",
    title: "Reroofing Requirements",
    description:
      "Roof covering materials used in reroofing shall comply with the applicable requirements for new construction.",
  },
  {
    id: "irc-r905-2",
    code: "IRC 2021",
    section: "§R905.2",
    title: "Asphalt Shingles — Material & Installation",
    description:
      "ASTM D3462 compliant shingles required. Minimum 4 nails per strip shingle; 2% slope minimum.",
  },
  {
    id: "irc-r905-7",
    code: "IRC 2021",
    section: "§R905.7",
    title: "Wood Shingles",
    description:
      "Wood shingles shall conform to CSSB grading standards and be applied per the fastening table.",
  },
  {
    id: "irc-r905-8",
    code: "IRC 2021",
    section: "§R905.8",
    title: "Wood Shakes",
    description:
      "Wood shakes shall be #1 grade. Interlayment of felt is required for slopes 4:12 and greater.",
  },
  {
    id: "irc-r908",
    code: "IRC 2021",
    section: "§R908",
    title: "Reroofing — Residential",
    description:
      "Reroofing shall not exceed two layers of shingles. Underlayment per Table R908.4.",
  },
  {
    id: "nrca-steep",
    code: "NRCA",
    section: "Steep-Slope Manual",
    title: "Steep-Slope Roofing Guidelines",
    description:
      "NRCA best practices for steep-slope membrane, flashing, fastening, and ventilation.",
  },
  {
    id: "arma-good",
    code: "ARMA",
    section: "Good Roofing Practice",
    title: "Residential Asphalt Roofing Manual",
    description:
      "Manufacturer-agnostic standards for residential asphalt shingle application, including underlayment, valleys, and flashings.",
  },
  {
    id: "astm-d3462",
    code: "ASTM",
    section: "D3462",
    title: "Asphalt Shingles — Standard Specification",
    description:
      "Standard specification for asphalt shingles made from glass felt; minimum physical properties for tear strength and tensile.",
  },
  {
    id: "astm-d4586",
    code: "ASTM",
    section: "D4586",
    title: "Asphalt Roof Cement",
    description:
      "Standard specification for asphalt roof cement (non-fibered, glass fiber, and mineral fiber formulations).",
  },
  {
    id: "ul-2218",
    code: "UL",
    section: "2218",
    title: "Impact Resistance — Class IV Rating",
    description:
      "Class IV requires passing a 2-inch steel ball drop from 20 ft on both new and aged samples with no cracking.",
  },
  {
    id: "ul-790",
    code: "UL",
    section: "790",
    title: "Fire Classification — Class A / B / C",
    description:
      "Standard for fire resistance of roof covering materials. Class A offers highest resistance to severe fire exposure.",
  },
  {
    id: "fm-1-29",
    code: "FM Global",
    section: "DS 1-29",
    title: "Roof Deck Fastening",
    description:
      "Fastening schedule for roof deck panels to resist wind uplift per FM Global Data Sheet 1-29.",
  },
  {
    id: "smacna-arch",
    code: "SMACNA",
    section: "Arch. Sheet Metal Manual",
    title: "Flashing & Sheet Metal Standards",
    description:
      "SMACNA standards for metal flashings, valleys, drip edges, coping, and gutters.",
  },
  {
    id: "osha-1926-502",
    code: "OSHA",
    section: "29 CFR 1926.502",
    title: "Fall Protection Systems",
    description:
      "Requirements for fall protection equipment on roofing operations at 6 ft or more above a lower level.",
  },
];
