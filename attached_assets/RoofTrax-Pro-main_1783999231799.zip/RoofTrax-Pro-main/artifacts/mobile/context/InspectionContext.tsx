import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import type { SelectedStorm, WeatherEventsResult } from "@/utils/weatherTypes";

// ---------------------------------------------------------------------------
// Primitive types
// ---------------------------------------------------------------------------
export type InspectionStatus = "not_started" | "in_progress" | "report_ready";
export type DamageScope = "roof_only" | "siding_only" | "roof_and_siding";
export type AccessMethod = "drone" | "direct_access";
export type DamageType = "wind" | "wind_hail" | "hail" | "tree" | "water_ice";
export type AnnotationTool = "arrow" | "circle" | "rect" | "freehand" | "text";

// ---------------------------------------------------------------------------
// Shared severity (used by both roofing and siding models)
// ---------------------------------------------------------------------------
export type DamageSeverity = "minor" | "moderate" | "severe";

/** Minimum photos required before any damage instance may be marked complete. */
export const REQUIRED_PHOTOS_PER_DAMAGE = 2;

// ---------------------------------------------------------------------------
// Roofing dynamic model — slope / damage-instance types
// ---------------------------------------------------------------------------
export type SlopeOrientation =
  | "front"
  | "back"
  | "left"
  | "right"
  | "flat"
  | "garage"
  | "porch"
  | "other";

export type InstanceDamageType =
  | "hail"
  | "wind"
  | "wind_hail"
  | "tree"
  | "water_ice"
  | "other";

export type DeckingCondition = "solid" | "soft_spots" | "rot" | "delamination";

export interface DamageInstance {
  id: string;
  damageType: InstanceDamageType;
  severity: DamageSeverity;
  photos: string[];
  causationNote: string;
  deckingCondition: DeckingCondition | null;
  discontinuedProduct: boolean;
  discontinuedProductNote: string;
  codeCitationIds: string[];
  isComplete: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface RoofSlope {
  id: string;
  orientation: SlopeOrientation;
  label: string;
  /** Area in roofing squares (1 SQ = 100 sq ft). Used for estimate calculations. */
  squareFootage?: number;
  damageInstances: DamageInstance[];
  createdAt: string;
}

// ---------------------------------------------------------------------------
// Siding dynamic model — elevation / damage-instance types
// ---------------------------------------------------------------------------
export type SidingElevation = "front" | "back" | "left" | "right" | "other";

export type SidingDamageType =
  | "hail"
  | "wind"
  | "impact"
  | "water"
  | "other";

export interface SidingDamageInstance {
  id: string;
  damageType: SidingDamageType;
  severity: DamageSeverity;
  photos: string[];
  causationNote: string;
  isComplete: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SidingElevationEntry {
  id: string;
  elevation: SidingElevation;
  label: string;
  damageInstances: SidingDamageInstance[];
  createdAt: string;
}

// ---------------------------------------------------------------------------
// Annotation types (Phase 1 photo annotations)
// ---------------------------------------------------------------------------
export interface AnnotationPoint {
  x: number;
  y: number;
}

export interface Annotation {
  id: string;
  tool: AnnotationTool;
  color: string;
  strokeWidth: number;
  x1?: number;
  y1?: number;
  x2?: number;
  y2?: number;
  cx?: number;
  cy?: number;
  r?: number;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  points?: AnnotationPoint[];
  text?: string;
  fontSize?: number;
}

// ---------------------------------------------------------------------------
// Top-level inspection profile
// ---------------------------------------------------------------------------
export interface InspectionProfile {
  id: string;
  address: string;
  /** Customer contact email used when sending the report. */
  customerEmail?: string;
  /** Customer full name (required before Phase 2 forensic inspection). */
  customerName?: string;
  /** Customer phone number (required before Phase 2 forensic inspection). */
  customerPhone?: string;
  /** Claim / policy number (required before Phase 2 forensic inspection). */
  claimNumber?: string;
  /** Insurance carrier name (required before Phase 2 forensic inspection). */
  insuranceCarrier?: string;
  /** Adjuster full name (required before Phase 2 forensic inspection). */
  adjusterName?: string;
  /** Adjuster phone or email (required before Phase 2 forensic inspection). */
  adjusterContact?: string;
  /** Date of loss (required before Phase 2 forensic inspection). */
  dateOfLoss?: string;
  createdAt: string;
  updatedAt: string;
  status: InspectionStatus;
  frontPhoto?: string;
  damageScope?: DamageScope;
  damageType?: DamageType;
  accessMethod?: AccessMethod;
  damagePhotos: string[];
  reportUri?: string;
  photoAnnotations?: Record<string, Annotation[]>;
  weatherEvents?: WeatherEventsResult;
  selectedStorm?: SelectedStorm | null;
  slopes?: RoofSlope[];
  sidingElevations?: SidingElevationEntry[];
}

// ---------------------------------------------------------------------------
// Context interface
// ---------------------------------------------------------------------------
interface InspectionContextType {
  profiles: InspectionProfile[];
  createProfile: (address: string) => InspectionProfile;
  updateProfile: (id: string, updates: Partial<InspectionProfile>) => void;
  deleteProfile: (id: string) => void;
  getProfile: (id: string) => InspectionProfile | undefined;
  getProfileNow: (id: string) => InspectionProfile | undefined;
  // Roofing slope helpers
  addSlope: (id: string, data: { orientation: SlopeOrientation; label: string }) => RoofSlope;
  updateSlope: (
    id: string,
    slopeId: string,
    updates: { orientation?: SlopeOrientation; label?: string; squareFootage?: number },
  ) => void;
  deleteSlope: (id: string, slopeId: string) => void;
  addDamageInstance: (
    id: string,
    slopeId: string,
    data: Omit<DamageInstance, "id" | "createdAt" | "updatedAt">,
  ) => DamageInstance;
  updateDamageInstance: (
    id: string,
    slopeId: string,
    instanceId: string,
    updates: Partial<Omit<DamageInstance, "id" | "createdAt">>,
  ) => void;
  deleteDamageInstance: (id: string, slopeId: string, instanceId: string) => void;
  // Siding elevation helpers
  addElevation: (id: string, data: { elevation: SidingElevation; label: string }) => SidingElevationEntry;
  updateElevation: (
    id: string,
    elevationId: string,
    updates: { elevation?: SidingElevation; label?: string },
  ) => void;
  deleteElevation: (id: string, elevationId: string) => void;
  addSidingDamage: (
    id: string,
    elevationId: string,
    data: Omit<SidingDamageInstance, "id" | "createdAt" | "updatedAt">,
  ) => SidingDamageInstance;
  updateSidingDamage: (
    id: string,
    elevationId: string,
    instanceId: string,
    updates: Partial<Omit<SidingDamageInstance, "id" | "createdAt">>,
  ) => void;
  deleteSidingDamage: (id: string, elevationId: string, instanceId: string) => void;
}

/**
 * Phase 2 (forensic inspection) requires a complete customer profile and
 * claim details before any roof/siding documentation can begin.
 */
export function isForensicIntakeComplete(p: InspectionProfile | undefined): boolean {
  if (!p) return false;
  return Boolean(
    p.customerName?.trim() &&
      p.customerPhone?.trim() &&
      p.customerEmail?.trim() &&
      p.claimNumber?.trim() &&
      p.insuranceCarrier?.trim() &&
      p.adjusterName?.trim() &&
      p.adjusterContact?.trim() &&
      p.dateOfLoss?.trim(),
  );
}

const InspectionContext = createContext<InspectionContextType | null>(null);
const STORAGE_KEY = "@inspections_v1";

function genId(): string {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------
export function InspectionProvider({ children }: { children: React.ReactNode }) {
  const [profiles, setProfiles] = useState<InspectionProfile[]>([]);
  const profilesRef = useRef<InspectionProfile[]>([]);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((data) => {
      if (data) {
        try {
          const parsed: InspectionProfile[] = JSON.parse(data);
          profilesRef.current = parsed;
          setProfiles(parsed);
        } catch {
          setProfiles([]);
        }
      }
    });
  }, []);

  const persist = useCallback(async (updated: InspectionProfile[]) => {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }, []);

  // ---- Profile CRUD --------------------------------------------------------

  const createProfile = useCallback(
    (address: string): InspectionProfile => {
      const id = genId();
      const now = new Date().toISOString();
      const profile: InspectionProfile = {
        id,
        address,
        createdAt: now,
        updatedAt: now,
        status: "not_started",
        damagePhotos: [],
      };
      setProfiles((prev) => {
        const updated = [profile, ...prev];
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
      return profile;
    },
    [persist],
  );

  const updateProfile = useCallback(
    (id: string, updates: Partial<InspectionProfile>) => {
      setProfiles((prev) => {
        const updated = prev.map((p) =>
          p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p,
        );
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  const deleteProfile = useCallback(
    (id: string) => {
      setProfiles((prev) => {
        const updated = prev.filter((p) => p.id !== id);
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  const getProfile = useCallback((id: string) => profiles.find((p) => p.id === id), [profiles]);
  const getProfileNow = useCallback((id: string) => profilesRef.current.find((p) => p.id === id), []);

  // ---- Roofing slope helpers -----------------------------------------------

  const addSlope = useCallback(
    (id: string, data: { orientation: SlopeOrientation; label: string }): RoofSlope => {
      const slope: RoofSlope = {
        id: genId(),
        orientation: data.orientation,
        label: data.label,
        damageInstances: [],
        createdAt: new Date().toISOString(),
      };
      setProfiles((prev) => {
        const updated = prev.map((p) =>
          p.id !== id
            ? p
            : { ...p, slopes: [...(p.slopes ?? []), slope], updatedAt: new Date().toISOString() },
        );
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
      return slope;
    },
    [persist],
  );

  const updateSlope = useCallback(
    (id: string, slopeId: string, updates: { orientation?: SlopeOrientation; label?: string; squareFootage?: number }) => {
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          const slopes = (p.slopes ?? []).map((s) =>
            s.id !== slopeId ? s : { ...s, ...updates },
          );
          return { ...p, slopes, updatedAt: new Date().toISOString() };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  const deleteSlope = useCallback(
    (id: string, slopeId: string) => {
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          return {
            ...p,
            slopes: (p.slopes ?? []).filter((s) => s.id !== slopeId),
            updatedAt: new Date().toISOString(),
          };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  const addDamageInstance = useCallback(
    (
      id: string,
      slopeId: string,
      data: Omit<DamageInstance, "id" | "createdAt" | "updatedAt">,
    ): DamageInstance => {
      const now = new Date().toISOString();
      const instance: DamageInstance = { ...data, id: genId(), createdAt: now, updatedAt: now };
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          const slopes = (p.slopes ?? []).map((s) =>
            s.id !== slopeId ? s : { ...s, damageInstances: [...s.damageInstances, instance] },
          );
          return { ...p, slopes, updatedAt: now };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
      return instance;
    },
    [persist],
  );

  const updateDamageInstance = useCallback(
    (
      id: string,
      slopeId: string,
      instanceId: string,
      updates: Partial<Omit<DamageInstance, "id" | "createdAt">>,
    ) => {
      const now = new Date().toISOString();
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          const slopes = (p.slopes ?? []).map((s) => {
            if (s.id !== slopeId) return s;
            const damageInstances = s.damageInstances.map((di) =>
              di.id !== instanceId ? di : { ...di, ...updates, updatedAt: now },
            );
            return { ...s, damageInstances };
          });
          return { ...p, slopes, updatedAt: now };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  const deleteDamageInstance = useCallback(
    (id: string, slopeId: string, instanceId: string) => {
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          const slopes = (p.slopes ?? []).map((s) => {
            if (s.id !== slopeId) return s;
            return { ...s, damageInstances: s.damageInstances.filter((di) => di.id !== instanceId) };
          });
          return { ...p, slopes, updatedAt: new Date().toISOString() };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  // ---- Siding elevation helpers --------------------------------------------

  const addElevation = useCallback(
    (id: string, data: { elevation: SidingElevation; label: string }): SidingElevationEntry => {
      const entry: SidingElevationEntry = {
        id: genId(),
        elevation: data.elevation,
        label: data.label,
        damageInstances: [],
        createdAt: new Date().toISOString(),
      };
      setProfiles((prev) => {
        const updated = prev.map((p) =>
          p.id !== id
            ? p
            : {
                ...p,
                sidingElevations: [...(p.sidingElevations ?? []), entry],
                updatedAt: new Date().toISOString(),
              },
        );
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
      return entry;
    },
    [persist],
  );

  const updateElevation = useCallback(
    (id: string, elevationId: string, updates: { elevation?: SidingElevation; label?: string }) => {
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          const sidingElevations = (p.sidingElevations ?? []).map((e) =>
            e.id !== elevationId ? e : { ...e, ...updates },
          );
          return { ...p, sidingElevations, updatedAt: new Date().toISOString() };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  const deleteElevation = useCallback(
    (id: string, elevationId: string) => {
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          return {
            ...p,
            sidingElevations: (p.sidingElevations ?? []).filter((e) => e.id !== elevationId),
            updatedAt: new Date().toISOString(),
          };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  const addSidingDamage = useCallback(
    (
      id: string,
      elevationId: string,
      data: Omit<SidingDamageInstance, "id" | "createdAt" | "updatedAt">,
    ): SidingDamageInstance => {
      const now = new Date().toISOString();
      const instance: SidingDamageInstance = { ...data, id: genId(), createdAt: now, updatedAt: now };
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          const sidingElevations = (p.sidingElevations ?? []).map((e) =>
            e.id !== elevationId
              ? e
              : { ...e, damageInstances: [...e.damageInstances, instance] },
          );
          return { ...p, sidingElevations, updatedAt: now };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
      return instance;
    },
    [persist],
  );

  const updateSidingDamage = useCallback(
    (
      id: string,
      elevationId: string,
      instanceId: string,
      updates: Partial<Omit<SidingDamageInstance, "id" | "createdAt">>,
    ) => {
      const now = new Date().toISOString();
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          const sidingElevations = (p.sidingElevations ?? []).map((e) => {
            if (e.id !== elevationId) return e;
            const damageInstances = e.damageInstances.map((di) =>
              di.id !== instanceId ? di : { ...di, ...updates, updatedAt: now },
            );
            return { ...e, damageInstances };
          });
          return { ...p, sidingElevations, updatedAt: now };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  const deleteSidingDamage = useCallback(
    (id: string, elevationId: string, instanceId: string) => {
      setProfiles((prev) => {
        const updated = prev.map((p) => {
          if (p.id !== id) return p;
          const sidingElevations = (p.sidingElevations ?? []).map((e) => {
            if (e.id !== elevationId) return e;
            return {
              ...e,
              damageInstances: e.damageInstances.filter((di) => di.id !== instanceId),
            };
          });
          return { ...p, sidingElevations, updatedAt: new Date().toISOString() };
        });
        profilesRef.current = updated;
        persist(updated);
        return updated;
      });
    },
    [persist],
  );

  return (
    <InspectionContext.Provider
      value={{
        profiles,
        createProfile,
        updateProfile,
        deleteProfile,
        getProfile,
        getProfileNow,
        addSlope,
        updateSlope,
        deleteSlope,
        addDamageInstance,
        updateDamageInstance,
        deleteDamageInstance,
        addElevation,
        updateElevation,
        deleteElevation,
        addSidingDamage,
        updateSidingDamage,
        deleteSidingDamage,
      }}
    >
      {children}
    </InspectionContext.Provider>
  );
}

export function useInspections() {
  const ctx = useContext(InspectionContext);
  if (!ctx) throw new Error("useInspections must be used within InspectionProvider");
  return ctx;
}
