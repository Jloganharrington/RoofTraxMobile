import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

export interface AppSettings {
  companyLogo?: string;
  companyName: string;
  userName: string;
  /** Basic price per roofing square used for slope estimate calculations. */
  pricePerSq?: number;
  /** Basic price per siding square used for siding estimate calculations. */
  pricePerSidingSq?: number;
}

interface SettingsContextType {
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => Promise<void>;
}

const SettingsContext = createContext<SettingsContextType | null>(null);
const SETTINGS_KEY = "@app_settings_v1";

const DEFAULT_SETTINGS: AppSettings = {
  companyName: "My Company",
  userName: "Field Inspector",
};

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    AsyncStorage.getItem(SETTINGS_KEY).then((data) => {
      if (data) {
        try {
          setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(data) });
        } catch {
          setSettings(DEFAULT_SETTINGS);
        }
      }
    });
  }, []);

  const updateSettings = useCallback(async (updates: Partial<AppSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...updates };
      AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  return (
    <SettingsContext.Provider value={{ settings, updateSettings }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error("useSettings must be used within SettingsProvider");
  return ctx;
}
